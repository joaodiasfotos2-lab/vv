// Amigáveis da IA (2026-10-12, pedido do utilizador: "a IA também organiza amigáveis para melhorar
// o entrosamento; entre 3 a 6 na pré-época se não tiver Elite Cup; o comportamento do treinador é
// diferente, é um jogo para rodar jogadores e fazer experiências").
//
// Decisões confirmadas por ele:
//   - Os clubes de IA jogam amigáveis entre si na pré-época (simulados nos bastidores com o motor
//     real: condição, lesões, entrosamento e coesão mudam de facto): 3 a 6 por clube; 1 a 2 se
//     estiverem na Elite Cup.
//   - Também te convidam a ti na pré-época (convites a aceitar ou recusar no Calendário).
//   - Em qualquer amigável, o treinador de IA roda o plantel (menos titulares), experimenta o
//     sistema alternativo, dá minutos a recém-chegados e jovens e poupa lesionados e cansados.
//   - Do teu lado, o adjunto sugere a rotação no relatório pré-jogo do amigável.
//
// Estado em state.calAmig: iaPlano { epoca, jogos[], feitos, recentes[] } e convites[].

const AMIG_IA_MIN = 3, AMIG_IA_MAX = 6;
const AMIG_IA_EC_MIN = 1, AMIG_IA_EC_MAX = 2;
const AMIG_IA_REP_DIF = 30;                 // diferença máxima de reputação preferida entre parceiros
const AMIG_NOVO_DIAS = 60;                  // "recém-chegado": menos de 60 dias no clube
const AMIG_CONVITE_PROB = 0.06;             // probabilidade diária de a IA te convidar (pré-época)
const AMIG_CONVITE_MAX_ATIVOS = 2, AMIG_CONVITE_MAX_EPOCA = 4;

function amigRandInt(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
function amigNaEliteCup(id) {
  const e = state.eliteCup && state.eliteCup.edicao;
  return !!(e && e.epoca === state.season && Array.isArray(e.participantes) && e.participantes.includes(id));
}
function amigDatasEliteCup(id) {
  const e = state.eliteCup && state.eliteCup.edicao, out = [];
  if (!e || e.epoca !== state.season) return out;
  Object.keys(e.jogos || {}).forEach(f => (e.jogos[f] || []).forEach(j => { if (j.date && (j.home === id || j.away === id)) out.push(isoDate(j.date)); }));
  return out;
}
function amigPrimeiraJornada(team) {
  try {
    const cid = competitionIdForTeam(team.id), c = cid && state.competitions[cid];
    const r = c && c.fixtures && c.fixtures[0];
    return r && r.date ? isoDate(r.date) : null;
  } catch (e) { return null; }
}
function amigIAElegiveis() {
  return Object.values(state.teams).filter(t => t && t.id !== state.userTeamId && !isUserControlledTeam(t) && !t.equipaPrincipalId && !t.nuvemEuropeia && !t.selecaoNacional &&
    Array.isArray(t.players) && t.players.length >= 5 && amigPrimeiraJornada(t));
}
function amigRecemChegado(team, p) {
  const b = typeof ensureBalneario === "function" ? ensureBalneario(team) : null;
  const t = b && b.presenca && b.presenca[p.id];
  return !!t && balnearioAgoMs() - t < AMIG_NOVO_DIAS * 86400000;
}

// ---------------------------------------------------------------- Plano dos jogos entre clubes de IA
function amigIAJogosDe(plano, id) { return plano.jogos.filter(g => g.home === id || g.away === id); }
function amigIAPlanear() {
  const c = calEnsure();
  if (c.iaPlano && c.iaPlano.epoca === state.season) return;
  if (state.currentRound > 0 || state.seasonOver || state.playoffActive) return;     // só na pré-época
  const hoje = calHoje();
  const plano = { epoca: state.season, jogos: [], feitos: 0, recentes: [], seq: 0 };
  c.iaPlano = plano;
  const porPais = {};
  amigIAElegiveis().forEach(t => { const k = teamCountry(t); (porPais[k] = porPais[k] || []).push(t); });
  Object.values(porPais).forEach(lista => {
    const meta = {}, fim = {}, ecDatas = {};
    lista.forEach(t => {
      const ec = amigNaEliteCup(t.id);
      meta[t.id] = ec ? amigRandInt(AMIG_IA_EC_MIN, AMIG_IA_EC_MAX) : amigRandInt(AMIG_IA_MIN, AMIG_IA_MAX);
      let f = calIsoAdd(amigPrimeiraJornada(t), -3);
      ecDatas[t.id] = amigDatasEliteCup(t.id);
      if (ec) {
        const primeira = ecDatas[t.id].slice().sort()[0];
        const lim = primeira ? calIsoAdd(primeira, -3) : calIsoAdd(hoje, 18);
        if (lim < f) f = lim;
      }
      fim[t.id] = f;
    });
    const livre = (t, iso) => {
      if (amigIAJogosDe(plano, t.id).some(g => Math.abs(calDiff(g.date, iso)) < 2)) return false;
      if (ecDatas[t.id].some(d => Math.abs(calDiff(d, iso)) <= 2)) return false;
      return true;
    };
    for (let tentativa = 0; tentativa < 60; tentativa++) {
      const pend = lista.filter(t => amigIAJogosDe(plano, t.id).length < meta[t.id]);
      if (pend.length < 2) break;
      pend.sort(() => Math.random() - 0.5);
      let avancou = false;
      for (const a of pend) {
        if (amigIAJogosDe(plano, a.id).length >= meta[a.id]) continue;
        const ra = a.reputacaoClube || 50;
        const relax = tentativa > 25;
        const parceiros = lista.filter(b => b.id !== a.id && amigIAJogosDe(plano, b.id).length < meta[b.id] &&
          !plano.jogos.some(g => (g.home === a.id && g.away === b.id) || (g.home === b.id && g.away === a.id)) &&
          (relax || Math.abs((b.reputacaoClube || 50) - ra) <= AMIG_IA_REP_DIF)).sort(() => Math.random() - 0.5);
        for (const b of parceiros) {
          const lim = fim[a.id] < fim[b.id] ? fim[a.id] : fim[b.id];
          const ini = calIsoAdd(hoje, 3);
          const span = calDiff(lim, ini);
          if (span < 0) continue;
          let data = null;
          for (let k = 0; k < 12 && !data; k++) { const d = calIsoAdd(ini, amigRandInt(0, span)); if (livre(a, d) && livre(b, d)) data = d; }
          if (!data) continue;
          const casa = Math.random() < 0.5;
          plano.seq++;
          plano.jogos.push({ id: `ia-${state.season}-${plano.seq}`, date: data, home: casa ? a.id : b.id, away: casa ? b.id : a.id, played: false });
          avancou = true; break;
        }
      }
      if (!avancou && tentativa > 40) break;
    }
    // Segunda passagem: quem ficou abaixo do mínimo (3, ou 1 na Elite Cup) arranja parceiro entre
    // os clubes que ainda não atingiram o máximo, sem preferência de reputação.
    lista.forEach(a => {
      const ec = amigNaEliteCup(a.id), min = ec ? AMIG_IA_EC_MIN : AMIG_IA_MIN;
      for (let k = 0; k < 30 && amigIAJogosDe(plano, a.id).length < min; k++) {
        const b = lista.filter(x => x.id !== a.id && amigIAJogosDe(plano, x.id).length < (amigNaEliteCup(x.id) ? AMIG_IA_EC_MAX : AMIG_IA_MAX) &&
          !plano.jogos.some(g => (g.home === a.id && g.away === x.id) || (g.home === x.id && g.away === a.id)))
          .sort(() => Math.random() - 0.5)[0];
        if (!b) break;
        const lim = fim[a.id] < fim[b.id] ? fim[a.id] : fim[b.id], ini = calIsoAdd(hoje, 3), span = calDiff(lim, ini);
        if (span < 0) break;
        let data = null;
        for (let j = 0; j < 20 && !data; j++) { const d = calIsoAdd(ini, amigRandInt(0, span)); if (livre(a, d) && livre(b, d)) data = d; }
        if (!data) continue;
        const casa = Math.random() < 0.5;
        plano.seq++;
        plano.jogos.push({ id: `ia-${state.season}-${plano.seq}`, date: data, home: casa ? a.id : b.id, away: casa ? b.id : a.id, played: false });
      }
    });
  });
  plano.jogos.sort((x, y) => x.date < y.date ? -1 : 1);
}
function amigIASimular(g) {
  const home = state.teams[g.home], away = state.teams[g.away];
  g.played = true;
  if (!home || !away) return;
  const anterior = state.pendingAmigavel;
  state.pendingAmigavel = true;
  try {
    var addH = ensureMinimumSquad(home), addA = ensureMinimumSquad(away);
    const r = simulateMatchToCompletion(g.home, g.away, false, false, null);
    removeProvisionalPlayers(home, addH); removeProvisionalPlayers(away, addA);
    g.homeScore = r.home; g.awayScore = r.away;
    const resH = r.home > r.away ? "V" : r.home < r.away ? "D" : "E", resA = resH === "V" ? "D" : resH === "D" ? "V" : "E";
    amigIAEfeitos(home, resH); amigIAEfeitos(away, resA);
  } catch (e) { g.erro = true; }
  finally { state.pendingAmigavel = anterior; }
}
function amigIADiario() {
  const c = state.calAmig;
  if (!c) return;
  amigIAPlanear();
  const plano = c.iaPlano;
  if (!plano || plano.epoca !== state.season) return;
  const hoje = calHoje();
  const hojeJogos = plano.jogos.filter(g => !g.played && g.date <= hoje);
  hojeJogos.forEach(g => {
    amigIASimular(g);
    plano.feitos++;
    plano.recentes.unshift({ date: g.date, home: g.home, away: g.away, hs: g.homeScore, as: g.awayScore });
  });
  if (plano.recentes.length > 30) plano.recentes.length = 30;
  if (hojeJogos.length) plano.jogos = plano.jogos.filter(g => !g.played);
}
// Entrosamento e coesão de um clube de IA depois de um amigável (igual ao do utilizador).
function amigIAEfeitos(team, res) {
  if (!team) return;
  const sis = team.sistema || "3-1";
  if (sistemaOk(sis)) famAdd(team, sis, 1.0);
  const b = typeof ensureBalneario === "function" ? ensureBalneario(team) : null;
  if (b) {
    syncBalnearioPresenca(team);
    b.coesao = clamp(b.coesao + (res === "V" ? 0.9 : res === "E" ? 0.6 : 0.3), 3, 99);
    Object.keys(b.presenca).forEach(pid => { if (balnearioAgoMs() - b.presenca[pid] < 60 * 86400000) b.presenca[pid] -= 10 * 86400000; });
  }
}

// ---------------------------------------------------------------- Comportamento do treinador de IA
// Chamados por newMatchState quando o jogo é de preparação (state.pendingAmigavel).
function amigExperimentarIA(team) {
  if (!team || isUserControlledTeam(team)) return;
  const alt = (team.sistema || "3-1") === "3-1" ? "2-2" : "3-1";
  if (alt !== team.sistema && Math.random() < 0.4) team.sistema = alt;
}
// Troca 1 a 3 titulares de campo (e muitas vezes o guarda-redes) por suplentes: recém-chegados e
// jovens primeiro; quem está cansado fica sempre de fora; lesionados e suspensos nunca jogam.
function amigRodarIA(team, lu) {
  if (!team || !lu || isUserControlledTeam(team)) return;
  const disp = p => playerAvailableForMatch(p) && (p.condicao == null || p.condicao >= 60);
  const novo = p => amigRecemChegado(team, p) ? 1 : 0;
  const jovem = p => (p.age || 30) <= 21 ? 1 : 0;
  if (lu.gr) {
    const grs = team.players.filter(p => p.pos === "GR" && disp(p) && p.id !== lu.gr.id).sort((a, b) => overall(b) - overall(a));
    const cansado = lu.gr.condicao != null && lu.gr.condicao < 65;
    if (grs.length && (cansado || Math.random() < 0.6)) lu.gr = grs[0];
  }
  const noRink = new Set(lu.outfield.map(p => p.id));
  const pool = team.players.filter(p => p.pos === "J" && disp(p) && !noRink.has(p.id));
  const cansados = lu.outfield.filter(p => p.condicao != null && p.condicao < 70).length;
  const r = Math.random();
  const alvo = Math.min(3, Math.max(r < 0.25 ? 1 : r < 0.85 ? 2 : 3, cansados));
  const ordem = lu.outfield.map((p, i) => ({ p, i, cans: p.condicao != null && p.condicao < 70 ? 1 : 0 }))
    .sort((a, b) => (b.cans - a.cans) || (overall(b.p) - overall(a.p)));
  let feitas = 0;
  for (const o of ordem) {
    if (feitas >= alvo) break;
    const rank = (a, b) => (novo(b) - novo(a)) || (jovem(b) - jovem(a)) || (overall(b) - overall(a));
    let cand = pool.filter(q => q.linha === o.p.linha).sort(rank)[0];
    if (!cand) {   // sem suplente da mesma linha: aceita outra, desde que fiquem um avançado e um defesa/médio em pista
      const resto = lu.outfield.filter((_, k) => k !== o.i);
      cand = pool.filter(q => [q].concat(resto).some(x => x.linha === "Avancado") && [q].concat(resto).some(x => x.linha !== "Avancado")).sort(rank)[0];
    }
    if (!cand) continue;
    lu.outfield[o.i] = cand; pool.splice(pool.indexOf(cand), 1); feitas++;
  }
}

// ---------------------------------------------------------------- Convites da IA ao utilizador
function amigConvitesAtivos() { return calEnsure().convites ? calEnsure().convites.filter(x => x.estado === "pendente") : []; }
function amigIAConvidarUtilizador() {
  const c = calEnsure();
  if (!Array.isArray(c.convites)) c.convites = [];
  const ps = state.preSeason;
  if (!ps || ps.epoca !== state.season || !ps.aberta || state.currentRound > 0 || state.seasonOver) return;
  const hoje = calHoje();
  const doEpoca = c.convites.filter(x => x.epoca === state.season).length;
  if (amigConvitesAtivos().length >= AMIG_CONVITE_MAX_ATIVOS || doEpoca >= AMIG_CONVITE_MAX_EPOCA) return;
  if (Math.random() >= AMIG_CONVITE_PROB) return;
  const me = myTeam(); if (!me) return;
  const rm = me.reputacaoClube || 50;
  const jaTem = new Set(c.convites.filter(x => x.epoca === state.season).map(x => x.oppId));
  c.jogos.forEach(g => { if (!g.cancelled) jaTem.add(g.oppId); });
  c.pedidos.forEach(p => { if (p.estado === "pendente") jaTem.add(p.oppId); });
  let cand = calOpcoesAdversario().filter(t => !jaTem.has(t.id) && Math.abs((t.reputacaoClube || 50) - rm) <= 35);
  cand = cand.filter(t => !(amigNaEliteCup(t.id) && Math.random() < 0.6));
  if (!cand.length) return;
  const opp = cand[Math.floor(Math.random() * cand.length)];
  const datas = [];
  for (let k = 4; k < 40; k++) { const d = calIsoAdd(hoje, k); if (calDataValida(d, { antecedencia: 3 }).ok && !calAdvOcupado(opp.id, d)) datas.push(d); }
  if (!datas.length) return;
  const date = datas[Math.floor(Math.random() * datas.length)];
  const casa = Math.random() < 0.5;   // casa = jogas em tua casa
  const cv = { id: calNovoId("conv"), epoca: state.season, oppId: opp.id, date, casa, estado: "pendente", criado: hoje, expira: calIsoAdd(date, -2) };
  c.convites.push(cv);
  pushNews(state.currentDate, `🤝 ${teamLinkHtml(opp.id)} convida-te para um jogo de preparação a ${calDataLonga(date)} (${casa ? "em tua casa" : "em casa deles"}). Responde no separador Calendário, em "Convites recebidos".`, "sistema", "Convite para amigável", { teamId: opp.id, autoAdvanceStop: true });
}
function amigConviteResponder(id, aceitar) {
  const c = calEnsure();
  const cv = (c.convites || []).find(x => x.id === id);
  if (!cv || cv.estado !== "pendente") return { ok: false, reason: "Este convite já não está ativo." };
  const me = myTeam(), opp = state.teams[cv.oppId];
  if (!aceitar) { cv.estado = "recusado"; return { ok: true }; }
  const v = calDataValida(cv.date, { antecedencia: 1, ignorarId: cv.id });
  if (!v.ok) { cv.estado = "expirado"; return { ok: false, reason: `Já não dá para aceitar: ${v.reason}` }; }
  const g = {
    id: calNovoId("amig"), date: cv.date, home: cv.casa ? me.id : opp.id, away: cv.casa ? opp.id : me.id, oppId: opp.id, casa: cv.casa,
    played: false, cancelled: false, homeScore: 0, awayScore: 0, custo: preSeasonFriendlyCost(cv.casa), amigavel: true, origem: "cal", convite: true,
  };
  c.jogos.push(g); c.jogos.sort((a, b) => a.date < b.date ? -1 : 1);
  cv.estado = "aceite";
  pushNews(state.currentDate, `🤝 Aceitaste o convite de ${teamLinkHtml(opp.id)}: jogo de preparação ${cv.casa ? "em casa" : "fora"}, a ${calDataLonga(cv.date)}.`, "sistema", "Amigável confirmado", { teamId: opp.id });
  return { ok: true, jogo: g };
}
function amigConvitesDiario() {
  const c = state.calAmig; if (!c) return;
  const hoje = calHoje();
  (c.convites || []).forEach(x => { if (x.estado === "pendente" && x.expira <= hoje) x.estado = "expirado"; });
  amigIAConvidarUtilizador();
}

// ---------------------------------------------------------------- Sugestão do adjunto (teu lado)
function amigSugestaoRotacao(team) {
  if (!team) return null;
  const disp = p => playerAvailableForMatch(p);
  const titulares = team.players.filter(p => p.pos === "J" && p.titular && disp(p));
  const suplentes = team.players.filter(p => p.pos === "J" && !p.titular && disp(p));
  const poupar = titulares.filter(p => (p.condicao != null && p.condicao < 80) || (typeof cargaValor === "function" && cargaValor(p) >= 50))
    .sort((a, b) => (a.condicao != null ? a.condicao : 100) - (b.condicao != null ? b.condicao : 100)).slice(0, 3);
  const testar = suplentes.map(p => ({ p, novo: amigRecemChegado(team, p), jovem: (p.age || 30) <= 21 }))
    .filter(x => x.novo || x.jovem).sort((a, b) => (b.novo - a.novo) || (overall(b.p) - overall(a.p))).slice(0, 3);
  const grs = team.players.filter(p => p.pos === "GR" && disp(p)).sort((a, b) => overall(b) - overall(a));
  const grSup = grs.length > 1 ? grs.find(p => !p.titular) || grs[1] : null;
  const sisAtual = sistemaOk(team.sistema) ? team.sistema : "3-1";
  const sisAlt = SISTEMAS_TAC.filter(s => s !== sisAtual).sort((a, b) => famOf(team, a) - famOf(team, b))[0];
  return { poupar, testar, grSup, sisAlt, sisAtual, fAlt: Math.round(famOf(team, sisAlt)), fOutro: Math.round(famOf(team, sisAtual)) };
}
function amigSecaoRotacaoHtml(team) {
  const s = amigSugestaoRotacao(team);
  if (!s) return null;
  const nome = p => playerLinkHtml(team.id, p);
  const linhas = [
    ["Poupar", s.poupar.length ? s.poupar.map(p => `${nome(p)} (condição ${Math.round(p.condicao != null ? p.condicao : 100)}%)`).join(", ") : "ninguém em risco; podes poupar quem quiseres"],
    ["Dar minutos", s.testar.length ? s.testar.map(x => `${nome(x.p)} (${x.novo ? "recém-chegado" : "jovem"})`).join(", ") : "sem recém-chegados ou jovens no banco"],
    ["Guarda-redes", s.grSup ? `dá minutos a ${nome(s.grSup)}` : "só tens um guarda-redes disponível"],
    ["Sistema", `experimenta o <b>${s.sisAlt}</b>, o menos rodado (familiaridade ${s.fAlt}, contra ${s.fOutro} no ${s.sisAtual})`],
  ];
  return { icone: "🔄", titulo: "Rotação sugerida para este amigável", cheia: true, linhas };
}
