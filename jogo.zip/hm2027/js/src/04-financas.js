  // ============================= 04-financas.js =============================
  // Finanças
  // Finances
  // =================================================================
  // Sistema numérico de reputação: as duas tabelas abaixo (FINANCE_BY_REPUTATION e
  // ECONOMIC_CALIBRATION.reputation) eram categóricas — 4 valores fixos, um "degrau" por
  // categoria antiga. Substituídas por pontos de ancoragem (reputação -> valor) interpolados
  // linearmente por reputationLerp (01-nucleo.js), nos mesmos 4 pontos de reputação legados
  // (55/70/85/95 — ver REPUTATION_POINTS). Qualquer clube sem reputação explícita nova (a
  // generalidade da 2ª/3ª Divisão) cai exatamente num destes 4 pontos ou perto deles, pelo que a
  // calibração financeira já validada não muda; só os clubes com reputação explícita nova entre
  // dois pontos (secção 6/15.4 do documento) passam a ter um valor financeiro intermédio, em vez
  // de saltar de categoria para categoria.
  const FINANCE_REPUTATION_ANCHORS = {
    saldo:      [[55,180000],[70,340000],[85,600000],[95,900000]],
    sponsor:    [[55,12000], [70,24000], [85,40000], [95,60000]],
    commercial: [[55,4000],  [70,7000],  [85,11000], [95,16000]],
    wageBudget: [[55,22000], [70,34000], [85,50000], [95,70000]],
    capacity:   [[55,1100],  [70,1600],  [85,2200],  [95,3000]],
    homeCost:   [[55,2000],  [70,3000],  [85,4500],  [95,6000]],
  };
  function financeByReputation(rep){
    const out = {};
    for(const key in FINANCE_REPUTATION_ANCHORS) out[key] = reputationLerp(rep, FINANCE_REPUTATION_ANCHORS[key]);
    return out;
  }
  // Pedido do utilizador (competições europeias, 2026-09-12): uma deslocação a um jogo europeu
  // NOUTRO PAÍS custa uma ordem de grandeza mais do que a deslocação doméstica genérica (1500€,
  // ou 7000€ no caso especial da ilha) — equipa mais staff (à volta de 15 pessoas), avião, hotel
  // (2 noites) e autocarro para os transfers. Fica fora dos perfis por reputação/divisão, tal
  // como a deslocação doméstica já fica hoje — é um custo logístico, não um reflexo da força do
  // clube. Ver processMatchFinances (opts.internacional) e europaCountryOf (07g-europa.js).
  const EUROPA_CUSTO_DESLOCACAO_INTERNACIONAL = 14000;
  // Bónus mensal de patrocínio por participação europeia essa época (pedido do utilizador: "jogos
  // em casa... podem gerar mais e melhores patrocínios nas épocas em que se qualificam") — uma
  // percentagem do patrocínio mensal já calibrado do próprio clube (nunca um valor fixo, para
  // escalar com o tamanho real do clube), tanto maior quanto mais alta a prova disputada essa
  // época (ed.participantes, 07g-europa.js — o nível mais alto atingido essa época).
  const EUROPA_SPONSOR_BONUS_PCT = { champions:0.18, cup:0.12, trophy:0.07, qualificacao:0.03 };
  const EUROPA_SPONSOR_BONUS_LABEL = { champions:"WSE Champions League", cup:"WSE Cup", trophy:"WSE Trophy", qualificacao:"Ronda de Qualificação Europeia" };
  const ECONOMIC_CALIBRATION_REPUTATION_ANCHORS = {
    cap:       [[55,1.16], [70,1.10], [85,1.02], [95,.94]],
    structure: [[55,.46],  [70,.78],  [85,1.18], [95,1.68]],
  };
  function economicCalibrationReputationFactor(rep){
    return { cap: reputationLerp(rep, ECONOMIC_CALIBRATION_REPUTATION_ANCHORS.cap), structure: reputationLerp(rep, ECONOMIC_CALIBRATION_REPUTATION_ANCHORS.structure) };
  }
  const TRAINING_MONTHLY_COST = { "Excelentes":22000, "Muito boas":14000, "Boas":8000, "Razoáveis":4000 };
  // Investimento em infraestrutura, por pedido à direção (2026-09-05): condições de treino e
  // capacidade do pavilhão passam a poder subir através de um pedido formal à direção, em vez de
  // ficarem fixas desde a génese do clube. Ordem ascendente explícita — TRAINING_MONTHLY_COST é um
  // objeto e não garante esta ordem.
  const TRAINING_LEVELS = ["Razoáveis","Boas","Muito boas","Excelentes"];
  const DIRECAO_INVESTIMENTO_CONFIG = Object.freeze({
    cooldownDias:240,          // ~8 meses entre pedidos do mesmo tipo (aprovados ou recusados)
    respostaMinDias:14,        // a direção nunca responde em menos de duas semanas
    respostaMaxDias:30,
    treinoMesesCusto:30,       // custo = 30 meses do agravamento do custo mensal de treino
    pavilhaoPassoFrac:.12,     // cada investimento aprovado soma ~12% à capacidade atual
    pavilhaoCustoPorLugar:150,
    scoutingMesesCusto:18,     // custo = 18 meses do agravamento do encargo mensal de scouting
    medicoMesesCusto:18,       // custo = 18 meses do agravamento do encargo mensal do departamento médico
    reservaMesesSobrevivencia:16, // mesma regra dos 16 meses usada no orçamento de transferências
    atencaoMinTaxaObjetivos:.5    // com saúde "atenção", só aprova se a última época cumpriu ≥50% dos objetivos
  });
  // Calibração económica, roadmap Fase 2. Parâmetros centralizados para ajuste na Fase 3.
  const ECONOMIC_CALIBRATION=Object.freeze({version:3,wageTarget:.56,wageAlert:.64,wageHardLimit:.73,reserveMonths:4,division:{placard:{floor:.82,structure:1},"2div":{floor:.92,structure:.44},"3div":{floor:.98,structure:.14}},structureBase:{placard:15500,"2div":6500,"3div":1800},freeSquadSize:22,extraPlayerCost:725,promotionConvergence:.84,acceptance:{healthyOrAttentionMin:.60,criticalMax:.15,bankruptcyMax:.05,topFourWealthMax:.62,maxConsecutiveBigClubGrowth:4}});

  // Correção: 0,34 mantinha a 3ª Divisão demasiado perto da 2ª (a mesma ordem de grandeza) —
  // baixado para refletir uma realidade verdadeiramente amadora (equipas de bairro, sem
  // patrocínios relevantes nem orçamento de transferências que se note), bem distinta da 2ª
  // Divisão (semiprofissional).
  // Correção (calibração financeira, ajuste de receitas — revertida): chegou a subir-se para 0,30
  // e depois 0,37 para compensar um plantel mínimo viável que, ao salário mínimo de 450€/jogador,
  // já excedia sozinho o orçamento salarial da 3ª Divisão. Mas essa subida partia de uma premissa
  // errada: tratava o piso de 450€ como fixo. Não é — só os clubes da 3ª Divisão a lutar pela
  // subida gastam esse valor; a generalidade gasta entre 200€ e 450€ por jogador (informação do
  // utilizador). A correção certa é do lado do custo, não da receita: normalizeInitialWageBill
  // ganhou um piso próprio mais baixo para a 3ª Divisão (200€, ver abaixo), pelo que este
  // multiplicador volta ao valor original de 0,25 — a 3ª Divisão mantém-se claramente a mais
  // pobre, como é realista.
  // Recalibração salarial por divisão (2026-09-05): o corte no custo salarial da 3ª Divisão
  // (ver DIVISION_SALARY_PROFILE em 01-nucleo.js) tornou as receitas antigas desproporcionadas —
  // com o multiplicador em 0,25 e o novo custo salarial, TODOS os clubes da 3ª Divisão acabavam
  // "saudáveis" ao fim de 20 épocas (saldo mediano ≈888 mil€, mínimo ≈609 mil€, matriz de
  // calibração), quando a 2ª Divisão continua a ter uma parte em risco. Baixado para 0,10 —
  // valor escolhido por experimentação com a matriz de calibração até devolver uma distribuição
  // parecida em forma à da 2ª Divisão (maioria saudável, mas com clubes genuinamente em
  // dificuldade), em vez de acumulação irrealista generalizada.
  // "ok-liga" (Espanha, 1ª divisão) e "serie-a1" (Itália, 1ª divisão) tratadas ao mesmo nível do
  // Placard — cada uma é a divisão de topo do seu próprio país, não uma divisão inferior
  // portuguesa. A diferença de reputação/nível económico entre países já fica capturada por
  // reputacaoCompeticao e pelos perfis próprios (DIVISION_SALARY_PROFILE, HOME_COST_DIVISION_RANGES).
  const DIVISION_FINANCE_MULT={placard:1,"ok-liga":1,"serie-a1":1,"2div":.62,"ok-liga-plata":.62,"3div":.10};
  const DIVISION_OPERATING_COST_MULT={placard:1,"2div":.58,"ok-liga-plata":.58,"3div":.12};
  // Correção (calibração financeira, proposta P1): este multiplicador dependia só da divisão —
  // um clube de reputação "Local" preso no Placard pagava exatamente o mesmo custo de treino que
  // o Benfica, quando o custo de estrutura (monthlyStructureCost) já tinha há muito um desconto
  // por reputação para o mesmo efeito. Passa a aplicar também clubFinancialStructureFactor.
  // A raiz quadrada suaviza o efeito face ao custo de estrutura: o treino é uma fatia menor do
  // orçamento, por isso o ajuste por reputação é mais comedido nos dois sentidos.
  function divisionOperatingCost(team,base){return Math.max(100,Math.round(base*(DIVISION_OPERATING_COST_MULT[team.divisaoAtual]||.6)*Math.sqrt(clubFinancialStructureFactor(team))));}
  function monthlyTrainingCost(team){return divisionOperatingCost(team,TRAINING_MONTHLY_COST[team.condicoesTreino]||8000);}

  // ============================= Fase 14: perfis financeiros reais =============================
  // Perfis próprios para os clubes com identidade financeira real e reconhecível; os restantes
  // usam um perfil genérico derivado da divisão, reputação, massa adepta e capacidade financeira.
  // Correção (calibração financeira, proposta P2): as quotas de sócios do Benfica/Sporting/FC
  // Porto estavam entre 2,7× e 3× o que a fórmula genérica daria a um clube "Classe Mundial" no
  // Placard (o patrocínio real, esse, já estava bem calibrado) — um duplo benefício em cima da já
  // vantajosa reputação máxima. Baixadas para cerca de 1,3× o valor genérico. O Barcelos e os
  // clubes com patrocínio real abaixo do genérico (Valongo, Sanjoanense, HC Turquel) mantêm-se: o
  // seu lado dos custos passou a ser corrigido em clubFinancialStructureFactor.
  const CLUB_FINANCE_PROFILES = {
    benfica:      { sponsorNome:"Betano",        sponsorValorAnual:960000, quotasMensais:19000, apoioMunicipalMensal:4000, percSocios:0.55, capacidade:3200, ticket:5, objetivoDesportivo:"Vencer o campeonato" },
    sporting:     { sponsorNome:"TAP",           sponsorValorAnual:900000, quotasMensais:18500, apoioMunicipalMensal:4000, percSocios:0.55, capacidade:3000, ticket:5, objetivoDesportivo:"Vencer o campeonato" },
    porto:        { sponsorNome:"Super Bock",    sponsorValorAnual:880000, quotasMensais:18000, apoioMunicipalMensal:4500, percSocios:0.52, capacidade:2800, ticket:5, objetivoDesportivo:"Vencer o campeonato" },
    barcelos:     { sponsorNome:"Adufe",         sponsorValorAnual:520000, quotasMensais:22000, apoioMunicipalMensal:6000, percSocios:0.45, capacidade:2000, ticket:5, objetivoDesportivo:"Lutar pelo título" },
    valongo:      { sponsorNome:"Câmara Municipal de Valongo", sponsorValorAnual:180000, quotasMensais:9000, apoioMunicipalMensal:9000, percSocios:0.35, capacidade:1200, ticket:5, objetivoDesportivo:"Manter-se no Placard" },
    sanjoanense:  { sponsorNome:"Município de Vila do Conde",  sponsorValorAnual:150000, quotasMensais:7000, apoioMunicipalMensal:7500, percSocios:0.40, capacidade:900,  ticket:5, objetivoDesportivo:"Evitar a descida" },
    "hc-turquel": { sponsorNome:"Junta de Freguesia de Turquel", sponsorValorAnual:60000, quotasMensais:3000, apoioMunicipalMensal:4000, percSocios:0.30, capacidade:600,  ticket:3, objetivoDesportivo:"Consolidar na 2.ª Divisão" },
  };

  // ============================= Identidade + Familiaridade tática (Fase 1) =============================
  // Identidade: a filosofia histórica/estratégica de cada clube — sistema principal e
  // secundário, pressão e mentalidade preferenciais. É persistente e serve de âncora estável
  // para a IA (que só se desvia dela por razões concretas: lesões, suspensões, resultado,
  // adversário ou mudança relevante na composição do plantel — tudo já capturado dentro de
  // systemFitScore). Perfis reais para os 7 clubes com identidade financeira própria; os
  // restantes usam um perfil genérico derivado da capacidade financeira do clube.
  const CLUB_TACTICAL_IDENTITY = {
    sporting:     { principal:"2-2", secundario:"3-1", pressao:"alta",  mentalidade:"ofensivo" },
    benfica:      { principal:"3-1", secundario:"2-2", pressao:"alta",  mentalidade:"ofensivo" },
    porto:        { principal:"3-1", secundario:"2-2", pressao:"media", mentalidade:"equilibrado" },
    barcelos:     { principal:"3-1", secundario:"2-2", pressao:"media", mentalidade:"equilibrado" },
    valongo:      { principal:"3-1", secundario:"2-2", pressao:"baixa", mentalidade:"defensivo" },
    sanjoanense:  { principal:"3-1", secundario:"2-2", pressao:"baixa", mentalidade:"defensivo" },
    "hc-turquel": { principal:"3-1", secundario:"2-2", pressao:"baixa", mentalidade:"defensivo" },
  };
  function genericTacticalIdentity(team){
    const cap = team.capacidadeFinanceira!=null ? team.capacidadeFinanceira : normalizeClubReputation(team.reputacao, team);
    const principal = cap>=60 ? "2-2" : "3-1";
    const secundario = principal==="2-2" ? "3-1" : "2-2";
    const pressao = cap>=70 ? "alta" : cap>=40 ? "media" : "baixa";
    const mentalidade = cap>=70 ? "ofensivo" : cap>=40 ? "equilibrado" : "defensivo";
    return { principal, secundario, pressao, mentalidade };
  }
  // Corre uma única vez por clube (guardado por identidadeSistemaPrincipal já definido) — na
  // criação de uma carreira nova ou na migração de um save antigo sem estes campos.
  function initTacticalIdentity(team){
    if(team.identidadeSistemaPrincipal) return;
    const identity = CLUB_TACTICAL_IDENTITY[team.id] || genericTacticalIdentity(team);
    team.identidadeSistemaPrincipal = identity.principal;
    team.identidadeSistemaSecundario = identity.secundario;
    team.identidadePressaoPreferencial = identity.pressao;
    team.identidadeMentalidadePreferencial = identity.mentalidade;
    team.sistema = identity.principal;
    team.mentalidade = identity.mentalidade;
    team.pressao = identity.pressao;
    // Familiaridade inicial: sistema principal entre 75-90, secundário entre 40-60.
    const rngHigh = () => roundDecimal(75 + Math.random()*15);
    const rngLow = () => roundDecimal(40 + Math.random()*20);
    team.familiaridade31 = identity.principal==="3-1" ? rngHigh() : rngLow();
    team.familiaridade22 = identity.principal==="2-2" ? rngHigh() : rngLow();
    team.familiaridade121 = rngLow();
    team.treinoTaticoEscolhido = null;
  }
  // Impacto da familiaridade no jogo: 80+ dá um bónus (até +8% a 100), <50 penaliza (até -12%
  // a 0), 50-79 é neutro — cobre coletivamente "organização, circulação, cobertura, pressão
  // coordenada" (bónus) ou "perdas de bola, erros posicionais, menor eficácia" (penalização).
  function familiaridadeFactor(team, sistema){
    const fam = famOf(team, sistema);
    if(fam>=80) return 1 + clamp((fam-80)/20,0,1)*0.08;
    if(fam<50) return 1 - clamp((50-fam)/50,0,1)*0.12;
    return 1;
  }
  // Treino tático semanal: decisão sempre manual do utilizador (state.treinoTaticoEscolhido);
  // a IA reforça automaticamente o seu sistema principal de identidade.
  function chooseAiTacticalTraining(team){ return team.identidadeSistemaPrincipal || team.sistema || "3-1"; }
  function applyWeeklyTacticalTraining(){
    if(!state.currentDate) return;
    if(state.lastTacticalTrainingDate){
      const diffDays = (state.currentDate - new Date(state.lastTacticalTrainingDate)) / 86400000;
      if(diffDays < 7) return;
    }
    Object.values(state.teams).forEach(team=>{
      if(team.familiaridade31==null || team.familiaridade22==null) return;
      const choice = team.id===state.userTeamId ? team.treinoTaticoEscolhido : chooseAiTacticalTraining(team);
      if(sistemaOk(choice)){ famAdd(team, choice, 0.5); SISTEMAS_TAC.forEach(s=>{ if(s!==choice) famAdd(team, s, -0.1); }); }
    });
    state.lastTacticalTrainingDate = isoDate(state.currentDate);
  }

  function genericObjetivoDesportivo(team){
    const rep = normalizeClubReputation(team.reputacao, team);
    if(rep>=90) return "Lutar pelo título";
    if(rep>=75) return "Terminar entre os 6 primeiros";
    if(rep>=55) return "Terminar na 1.ª metade da tabela";
    // 0.2.12: a 3.ª Divisão não tem descida — o objetivo mínimo não pode ser "manutenção".
    if(team.divisaoAtual==="3div") return "Terminar entre os 10 primeiros";
    return "Assegurar a manutenção";
  }
  // Correção (bug real, reportado pelo utilizador): o objetivo desportivo da direção
  // (financeiro.sponsorObjetivo) era calculado uma única vez, no arranque da carreira
  // (initClubFinance), e nunca mais era atualizado — mesmo com a reputação do clube a evoluir,
  // época após época, para cima ou para baixo. Um clube que caísse para reputação de "luta pela
  // manutenção" continuava, para sempre, com o objetivo antigo de "terminar na 1.ª metade",
  // por exemplo. Chamada a cada época (ver updateReputations, em 08-evolucao-jogadores.js) para
  // todos os clubes cuja reputação foi recalculada nessa época. Só se aplica aos clubes sem
  // perfil fixo em CLUB_FINANCE_PROFILES — os poucos clubes com objetivo narrativo próprio
  // (Benfica, Sporting, FC Porto, etc.) mantêm sempre o seu objetivo fixo, nunca recalculado
  // pela fórmula genérica.
  function refreshSponsorObjetivo(team){
    if(!team || !team.financeiro || team.equipaPrincipalId) return;
    if(CLUB_FINANCE_PROFILES[team.id]) return;
    team.financeiro.sponsorObjetivo = genericObjetivoDesportivo(team);
  }
  // Clássicos e rivalidades regionais que aumentam claramente a assistência.
  const DERBY_PAIRS = new Set(["benfica|sporting","benfica|porto","porto|sporting","sl-benfica-b|sporting-cp-b","fc-porto-b|ad-valongo-b",
      // OK Liga (Espanha) — rivalidades conhecidas e estáveis, sem ligação à época corrente;
      // lista de melhor esforço, fácil de ajustar mais tarde só editando estes dados.
      "fc-barcelona|hc-liceo","hc-liceo|ce-noia","cp-vilafranca|cp-calafell","ch-lloret|shum-macanet","igualada-hc|cp-vilafranca"]
    .flatMap(k=>{const [a,b]=k.split("|");return [a+"|"+b,b+"|"+a];}));
  function isDerby(aId,bId){ return (typeof derbyNivel==="function") ? derbyNivel(aId,bId)>0 : DERBY_PAIRS.has(aId+"|"+bId); }

  // ============================= Fase 17: assistência realista, jogo a jogo =============================
  // Pedido do utilizador: a assistência de um mesmo clube deve poder ser muito diferente de jogo
  // para jogo (60 espetadores num jogo sem interesse, pavilhão esgotado num derby ou jogo
  // decisivo) — não uma fração quase fixa da capacidade do pavilhão, como acontecia antes. Nasce
  // uma "Base de Adeptos" persistente por clube (o ponto de partida realista para um jogo comum,
  // sem qualquer interesse especial) multiplicada por vários fatores independentes (interesse do
  // adversário, contexto competitivo, forma recente, rivalidade, tipo de competição e
  // variabilidade aleatória), com a capacidade do pavilhão como teto absoluto.
  // Correção de escala: os números absolutos do pedido original do utilizador ("2.000 a 3.000+
  // para grandes jogos", etc.) foram pensados para pavilhões maiores do que os que este motor
  // gera (capacidade máxima real ronda os 3.000-3.300 lugares mesmo para os clubes de reputação
  // máxima — ver FINANCE_REPUTATION_ANCHORS.capacity). Usar esses números tal e qual fazia a
  // "base" ficar praticamente colada à capacidade do pavilhão de muitos clubes — qualquer fator
  // multiplicativo (interesse do adversário, forma, etc.) esgotava o pavilhão em quase todos os
  // jogos, o contrário do realismo pedido ("60 espectadores num jogo sem interesse... pavilhão
  // esgotado num derby"). A base passa a ser uma FRAÇÃO da capacidade real de cada clube — mantém
  // a mesma forma pedida (clubes pequenos claramente mais vazios do que os históricos/grandes),
  // mas garante que um jogo comum fica sempre bem abaixo da lotação, reservando o esgotado para
  // combinações genuinamente especiais (adversário forte, derby, contexto decisivo, sorte).
  const CLUB_BASE_ADEPTOS_FRACTION_OVERRIDE = {
    benfica:[.35,.55], sporting:[.35,.55], porto:[.35,.55], barcelos:[.30,.45],
    valongo:[.25,.40], sanjoanense:[.22,.35], "hc-turquel":[.20,.32],
  };
  const BASE_ADEPTOS_FRACTION_RANGES = {
    placard: [[40,.12,.22],[60,.20,.32],[85,.28,.42],[101,.35,.55]],
    "2div":  [[40,.10,.18],[60,.16,.26],[85,.22,.34],[101,.28,.40]],
    "3div":  [[40,.10,.16],[60,.14,.22],[85,.18,.28],[101,.22,.32]],
  };
  function computeBaseAdeptos(team, capacity){
    const cap=Math.max(1,Math.round(capacity||(team.financeiro&&team.financeiro.capacidadePavilhao)||0));
    const override=CLUB_BASE_ADEPTOS_FRACTION_OVERRIDE[team.id];
    if(override) return Math.max(10,Math.round(cap*(override[0]+Math.random()*(override[1]-override[0]))));
    const rep=normalizeClubReputation(team.reputacao, team);
    const table=BASE_ADEPTOS_FRACTION_RANGES[team.divisaoAtual]||BASE_ADEPTOS_FRACTION_RANGES["2div"];
    const tier=table.find(t=>rep<t[0])||table[table.length-1];
    return Math.max(10,Math.round(cap*(tier[1]+Math.random()*(tier[2]-tier[1]))));
  }
  function competitionOfTeam(team){
    return Object.values(state.competitions).find(c=>Array.isArray(c.teamIds)&&c.teamIds.includes(team.id));
  }
  // Posição/contexto do clube na SUA própria competição — usado tanto para saber se o próprio
  // jogo pesa (luta pelo título/subida/manutenção, jornadas decisivas) como para saber se o
  // ADVERSÁRIO é, ele próprio, candidato a algo (jogos assim atraem mais público mesmo que o
  // adversário não tenha grande nome).
  function standingsContext(team){
    const comp=competitionOfTeam(team);
    if(!comp||!Array.isArray(comp.teamIds)||comp.teamIds.length<3) return null;
    let standings;
    try{ standings=standingsForCompetition(comp.id); }catch(e){ return null; }
    const idx=standings.findIndex(t=>t.id===team.id);
    if(idx<0) return null;
    const total=standings.length, position=idx+1;
    const leaderPts=standings[0].stats.Pts, ourPts=standings[idx].stats.Pts;
    const totalRounds=Array.isArray(comp.fixtures)?comp.fixtures.length:0, roundsPlayed=comp.currentRound||0;
    return {
      total, position,
      isTitleContender: position<=3 && (leaderPts-ourPts)<=6,
      // Correção (OK Liga, 2026-09-06): só excluía o Placard — mas a OK Liga é igualmente uma
      // 1ª divisão sem escalão acima para onde subir (sem OK Liga Plata em v1). Generaliza-se
      // usando PLAYOFF_DIVISION_CONFIG (07-playoff.js) como a definição canónica de "divisão de
      // topo" — exatamente as divisões com playoff próprio.
      isPromotionContender: !PLAYOFF_DIVISION_CONFIG[team.divisaoAtual] && position<=Math.min(4,total),
      isRelegationBattle: position>=total-2,
      isDecisive: totalRounds>0 && roundsPlayed>=totalRounds-3,
    };
  }
  // Fator de interesse do adversário: adversários mais fortes ou em disputa por algo atraem mais
  // público, mesmo sem serem os "três grandes".
  function matchOpponentInterestFactor(away){
    const rep=normalizeClubReputation(away.reputacao, away);
    const ctx=standingsContext(away);
    const isRaceContender = !!ctx && (ctx.isTitleContender||ctx.isPromotionContender);
    let range;
    if(rep>=90) range=[50,150];
    else if(rep>=80) range=[30,80];
    else if(isRaceContender) range=[20,50];
    else if(rep>=55) range=[10,25];
    else range=[0,10];
    return 1+(range[0]+Math.random()*(range[1]-range[0]))/100;
  }
  // Fator competitivo: luta pelo título, pela subida ou pela manutenção, reforçado nas últimas
  // jornadas decisivas da época.
  function matchCompetitiveContextFactor(home){
    const ctx=standingsContext(home);
    if(!ctx) return 1;
    let range=null;
    if(ctx.isTitleContender) range=[20,100];
    else if(ctx.isPromotionContender) range=[20,80];
    else if(ctx.isRelegationBattle) range=[10,60];
    if(ctx.isDecisive) range = range ? [range[0]+10,range[1]+50] : [30,150];
    if(!range) return 1;
    return 1+(range[0]+Math.random()*(range[1]-range[0]))/100;
  }
  // Fator de rivalidade: um derby atrai muito mais público do que a qualidade dos adversários,
  // por si só, indicaria.
  function matchRivalryFactor(homeId,awayId){
    if(!isDerby(homeId,awayId)) return 1;
    // 0.2.4: Clássicos (3 grandes) e Jogos Grandes (grande vs Barcelos/Oliveirense) escalam com a intensidade e a febre do jogo.
    const k=(typeof derbyAtendimentoMult==="function")?derbyAtendimentoMult(homeId,awayId):1;
    return 1+((50+Math.random()*150)/100)*k;
  }
  // Fator de forma recente (mantém-se a fórmula já calibrada antes desta correção).
  function matchFormFactor(home){
    const form=(home.recentResults||[]).slice(-5), wins=form.filter(x=>x==="V").length;
    return .9+wins*.035;
  }

  // Correção (pedido do utilizador, com valores de referência reais do hóquei em patins
  // português): a fórmula anterior de homeCost (anexada aos anchors genéricos de reputação,
  // ver FINANCE_REPUTATION_ANCHORS.homeCost acima) produzia valores muito acima do que o
  // utilizador confirmou ser realista por divisão — chegava aos 7.000-8.000€/jogo para um clube
  // grande do Placard (o dobro do teto real de 3.000€) e ficava perto de 1.000-1.200€/jogo até
  // na 2ª/3ª Divisão (2x a 4x acima dos 500-900€/250-500€ reais). Substituído por um valor
  // diretamente ancorado no intervalo real por divisão, com a reputação a decidir só a posição
  // dentro desse intervalo (clubes mais fracos perto do mínimo, mais fortes perto do máximo) — a
  // oscilação ±15% por jogo (ver processMatchFinances) fica por cima deste valor de referência.
  // OK Liga (2026-09-06): sem entrada própria, caía no valor por omissão de computeHomeCostReference
  // ("2div") para uma 1ª divisão estrangeira — escalado a -15%, o mesmo diferencial de reputação de
  // liga indicado pelo utilizador (ver reputacaoCompeticao, 02-estado.js).
  // Serie A1 (2026-09-06, italiana): mesmo raciocínio, escalado -15% sobre a OK Liga (0.85 x 0.85).
  const HOME_COST_DIVISION_RANGES = { placard:[1500,3000], "ok-liga":[1275,2550], "serie-a1":[1084,2168], "2div":[500,900], "3div":[250,500] };
  function computeHomeCostReference(team){
    const range=HOME_COST_DIVISION_RANGES[team.divisaoAtual]||HOME_COST_DIVISION_RANGES["2div"];
    const rep=normalizeClubReputation(team.reputacao, team);
    const posFactor=clamp((rep-40)/55,0,1);
    return Math.round(range[0]+(range[1]-range[0])*posFactor);
  }
  function syncClubStrategicProfile(t){if(t.reputacaoClube==null)t.reputacaoClube=t.reputacaoPontos||50;if(t.desempenhoRecente==null)t.desempenhoRecente=50;if(t.capacidadeFinanceira==null)t.capacidadeFinanceira=t.reputacaoClube;if(t.massaAdepta==null)t.massaAdepta=t.reputacaoClube;}
  // Correção (auditoria pedida pelo utilizador, 2026-09-12): esta função só olhava para
  // state.competitions (ligas domésticas) — um clube em prova europeia (Champions/Cup/Trophy/
  // Qualificação, que nunca entram em state.competitions, ver 07g-europa.js) nunca via essa
  // participação refletida em clubAppeal (mercado de transferências). Passa a usar o valor MAIS
  // ALTO entre o prestígio doméstico e o europeu, quando o clube participa na Europa essa época.
  function competitionPrestigeForTeam(t){
    const c=Object.values(state.competitions).find(x=>x.teamIds.includes(t.id));
    const domestico = c?(c.reputacaoCompeticao||60):(t.divisaoAtual==="3div"?35:60);
    const europeu = (typeof europaCompetitionPrestigeForTeam==="function") ? europaCompetitionPrestigeForTeam(t.id) : null;
    return europeu!=null ? Math.max(domestico, europeu) : domestico;
  }
  function financeConfig(team){
    syncClubStrategicProfile(team);
    const b=financeByReputation(team.reputacao);
    const d=DIVISION_FINANCE_MULT[team.divisaoAtual]||.6, f=.72+team.capacidadeFinanceira/250, a=.78+team.massaAdepta/300;
    const profile=CLUB_FINANCE_PROFILES[team.id];
    if(profile){
      return {
        saldo: Math.round(b.saldo*f*d),
        sponsor: Math.round(profile.sponsorValorAnual/12), sponsorNome:profile.sponsorNome, sponsorValorAnual:profile.sponsorValorAnual,
        objetivoDesportivo: profile.objetivoDesportivo,
        quotas: profile.quotasMensais, apoioMunicipal: profile.apoioMunicipalMensal, percSocios: profile.percSocios,
        commercial: Math.round(b.commercial*d*a), wageBudget: Math.round(b.wageBudget*d*f),
        capacity: profile.capacidade, ticket: profile.ticket,
        homeCost: computeHomeCostReference(team),
      };
    }
    // Generalizado (Serie A1, 2026-09-06): usa PLAYOFF_DIVISION_CONFIG como definição canónica de
    // "divisão de topo de um país" (Placard/OK Liga/Serie A1), em vez de listar cada país à mão —
    // um país novo só precisa da sua entrada em PLAYOFF_DIVISION_CONFIG (07-playoff.js).
    const ticketBase = PLAYOFF_DIVISION_CONFIG[team.divisaoAtual] ? 5 : 3;
    const sponsorMensal = Math.round(b.sponsor*d*f);
    // Ajuste manual pontual (ver saldoInicialManual/patrocinioAnualManual, 02-estado.js): só o
    // patrocínio final apresentado/pago muda — quotas continuam derivadas do patrocínio GENÉRICO
    // (sponsorMensal), para o ajuste não se propagar em cascata a números que o utilizador não
    // pediu para mudar.
    const sponsorMensalFinal = team.patrocinioAnualManual!=null ? Math.round(team.patrocinioAnualManual/12) : sponsorMensal;
    // Correção: o "saldo" (dinheiro em caixa) nunca era multiplicado por d (o fator de
    // divisão) — só as receitas mensais (patrocínio, comercial, etc.) eram. Isto fazia com que
    // um clube "Local" da 3ª Divisão começasse com exatamente o mesmo saldo que um clube "Local"
    // da 2ª Divisão, apesar de DIVISION_FINANCE_MULT já prever uma diferença clara entre as
    // duas (0,62 vs 0,34) — a diferença nunca chegava a aplicar-se ao dinheiro em caixa em si.
    return { ...b, saldo: team.saldoInicialManual!=null ? team.saldoInicialManual : Math.round(b.saldo*f*d),
      sponsor:sponsorMensalFinal, sponsorNome:`Patrocinador Principal do ${team.name}`, sponsorValorAnual:sponsorMensalFinal*12,
      objetivoDesportivo: genericObjetivoDesportivo(team),
      // Correção (calibração financeira, ajuste de receitas): o apoio municipal genérico era
      // mais baixo no Placard (3.500€) do que na 2ª/3ª Divisão (6.000€) — o contrário do que faz
      // sentido para um clube pequeno preso no escalão principal, que devia ter pelo menos o
      // mesmo apoio da autarquia que teria num escalão inferior.
      quotas: Math.round(sponsorMensal*0.22), apoioMunicipal: Math.round(6000*d),
      percSocios: clamp(0.22+team.massaAdepta/250,0.15,0.5),
      commercial:Math.round(b.commercial*d*a), wageBudget:Math.round(b.wageBudget*d*f),
      capacity:Math.round(b.capacity*a), ticket:ticketBase,
      homeCost:computeHomeCostReference(team) };
  }
  // Fase 1 do roadmap: adapta o perfil financeiro quando um clube muda de divisão.
  function adaptClubFinanceToDivision(team,fromDivision,toDivision,reason="mudanca-divisao"){
    if(!team||!fromDivision||!toDivision||fromDivision===toDivision||team.equipaPrincipalId)return false;
    initClubFinance(team);
    const f=team.financeiro,seasonKey=seasonLabel(state.season),key=`${team.id}:${seasonKey}:${fromDivision}>${toDivision}`;
    if(!Array.isArray(team.historicoMudancasDivisao))team.historicoMudancasDivisao=[];
    if(!Array.isArray(f.adaptacoesDivisaoAplicadas))f.adaptacoesDivisaoAplicadas=[];
    if(f.adaptacoesDivisaoAplicadas.includes(key))return false;
    const oldMult=DIVISION_FINANCE_MULT[fromDivision]||.6,newMult=DIVISION_FINANCE_MULT[toDivision]||.6,promoted=newMult>oldMult,baseRatio=newMult/Math.max(.01,oldMult);
    const incomeRatio=promoted?baseRatio:(.30+.70*baseRatio),wageRatio=promoted?Math.min(baseRatio,1.65):(.20+.80*baseRatio);
    const old={patrocinio:f.receitaMensalPatrocinio||0,comercial:f.receitaMensalComercial||0,quotas:f.receitaMensalQuotas||0,apoio:f.receitaMensalApoioMunicipal||0,limiteSalarial:f.limiteSalarial||0,limiteCredito:f.limiteCredito||0,orcamentoTransferencias:f.orcamentoTransferencias||0};
    f.receitaMensalPatrocinio=Math.max(0,Math.round(old.patrocinio*incomeRatio));f.receitaMensalComercial=Math.max(0,Math.round(old.comercial*incomeRatio));
    f.receitaMensalQuotas=Math.max(0,Math.round(old.quotas*incomeRatio));f.receitaMensalApoioMunicipal=Math.max(0,Math.round(old.apoio*incomeRatio));f.sponsorValorAnual=f.receitaMensalPatrocinio*12;
    patrocinioEscalar(team,incomeRatio);
    f.limiteSalarial=Math.max(500,Math.round(old.limiteSalarial*wageRatio));
    const annualRecurring=(f.receitaMensalPatrocinio+f.receitaMensalComercial+f.receitaMensalQuotas+f.receitaMensalApoioMunicipal)*12;
    f.limiteCredito=Math.max(10000,Math.round(annualRecurring*(promoted?.18:.14)));
    const reserve=Math.max(monthlyWageBill(team)*3,10000),affordable=Math.max(0,(f.saldo||0)-reserve);
    f.orcamentoTransferencias=Math.max(0,Math.round(Math.min(affordable,promoted?annualRecurring*.10:annualRecurring*.035)));
    team.planoFinanceiroMudancaDivisao={key,epoca:seasonKey,tipo:promoted?"promocao":"descida",divisaoOrigem:fromDivision,divisaoDestino:toDivision,reservaMinima:reserve,prioridade:promoted?"reforco-seletivo":"reducao-salarial",ativo:true,convergenciaPendente:!promoted,aplicadoEm:isoDate(state.currentDate||new Date())};
    const event={key,epoca:seasonKey,data:isoDate(state.currentDate||new Date()),tipo:promoted?"promocao":"descida",motivo:reason,divisaoOrigem:fromDivision,divisaoDestino:toDivision,valoresAntes:old,valoresDepois:{patrocinio:f.receitaMensalPatrocinio,comercial:f.receitaMensalComercial,quotas:f.receitaMensalQuotas,apoio:f.receitaMensalApoioMunicipal,limiteSalarial:f.limiteSalarial,limiteCredito:f.limiteCredito,orcamentoTransferencias:f.orcamentoTransferencias}};
    team.historicoMudancasDivisao.push(event);f.adaptacoesDivisaoAplicadas.push(key);f.adaptacoesDivisaoAplicadas=f.adaptacoesDivisaoAplicadas.slice(-20);
    addFinanceMovement(team,"receita","Mudança de divisão",promoted?"Adaptação financeira após promoção":"Adaptação financeira após descida",0,state.currentDate);return true;
  }

  // ============================= Fase 2: gestão financeira avançada =============================
  function normalizeFinancePhase2(team){
    const f=team.financeiro;if(!f)return;
    if((f.modeloFinanceiroVersao||0)<2){
      const c=financeConfig(team);
      f.receitaMensalPatrocinio=c.sponsor;f.receitaMensalComercial=c.commercial;
      f.receitaMensalQuotas=c.quotas;f.receitaMensalApoioMunicipal=c.apoioMunicipal;
      f.limiteSalarial=Math.max(f.limiteSalarial||0,c.wageBudget);
      f.limiteCredito=Math.max(f.limiteCredito||0,Math.round((c.sponsorValorAnual||c.sponsor*12)*.18));
      f.modeloFinanceiroVersao=2;
    }
    // Fase 17 (assistência realista): jogos guardados antes desta correção não têm "Base de
    // Adeptos" — calcula-se uma vez, de forma estável, e fica persistente dali em diante.
    if(f.baseAdeptos==null) f.baseAdeptos=computeBaseAdeptos(team, f.capacidadePavilhao);
    f.divida=Math.max(0,Number(f.divida)||0);
    f.creditoUtilizado=Math.max(0,Number(f.creditoUtilizado)||0);
    f.limiteCredito=Math.max(10000,Number(f.limiteCredito)||Math.round((f.sponsorValorAnual||120000)*.18));
    f.taxaJuroAnual=Number(f.taxaJuroAnual)||(team.divisaoAtual==="3div"?.045:.08);
    f.encargosFinanceirosEpoca=Math.max(0,Number(f.encargosFinanceirosEpoca)||0);
    f.receitaPatrocinioAntecipada=Math.max(0,Number(f.receitaPatrocinioAntecipada)||0);
    f.corteFormacao=clamp(Number(f.corteFormacao)||0,0,.5);
    f.corteEstrutura=clamp(Number(f.corteEstrutura)||0,0,.3);
    f.planoRecuperacao=f.planoRecuperacao||null;
    f.historicoEstados=Array.isArray(f.historicoEstados)?f.historicoEstados:[];
    f.historicoEpocas=Array.isArray(f.historicoEpocas)?f.historicoEpocas:[];
    f.orcamentoPrevisto=f.orcamentoPrevisto||{
      receitaMensal:(f.receitaMensalPatrocinio||0)+(f.receitaMensalQuotas||0)+(f.receitaMensalApoioMunicipal||0)+(f.receitaMensalComercial||0),
      despesaMensal:(f.limiteSalarial||0)+monthlyTrainingCost(team)
    };
    f.ultimoEstadoFinanceiro=f.ultimoEstadoFinanceiro||null;
    // Fase 1: estado formal e persistente da crise; migrações começam em valores neutros.
    f.estadoCriseFinanceira=["normal","critica","insolvencia","falencia"].includes(f.estadoCriseFinanceira)?f.estadoCriseFinanceira:"normal";
    f.mesesCriticosConsecutivos=Math.max(0,parseInt(f.mesesCriticosConsecutivos,10)||0);
    f.mesesInsolventeConsecutivos=Math.max(0,parseInt(f.mesesInsolventeConsecutivos,10)||0);
    f.mesesRecuperacaoConsecutivos=Math.max(0,parseInt(f.mesesRecuperacaoConsecutivos,10)||0);
    f.ultimoProcessamentoCriseMensal=typeof f.ultimoProcessamentoCriseMensal==="string"?f.ultimoProcessamentoCriseMensal:null;
    f.elegivelFalencia=!!f.elegivelFalencia;
    f.historicoCriseFinanceira=Array.isArray(f.historicoCriseFinanceira)?f.historicoCriseFinanceira:[];
    f.calibracaoEconomica=f.calibracaoEconomica&&typeof f.calibracaoEconomica==="object"?f.calibracaoEconomica:{versao:ECONOMIC_CALIBRATION.version,mesesProcessados:0,historicoEstrutura:[]};f.calibracaoEconomica.versao=ECONOMIC_CALIBRATION.version;f.calibracaoEconomica.historicoEstrutura=Array.isArray(f.calibracaoEconomica.historicoEstrutura)?f.calibracaoEconomica.historicoEstrutura:[];f.calibracaoEconomica.historicoResultado=Array.isArray(f.calibracaoEconomica.historicoResultado)?f.calibracaoEconomica.historicoResultado:[];
    f.restricoesInsolvencia=!!f.restricoesInsolvencia;f.intervencaoDirecao=f.intervencaoDirecao||null;f.ultimaAdvertenciaEmitida=!!f.ultimaAdvertenciaEmitida;f.orcamentoTransferenciasPreIntervencao=Math.max(0,Number(f.orcamentoTransferenciasPreIntervencao)||0);f.limiteSalarialPreIntervencao=Math.max(0,Number(f.limiteSalarialPreIntervencao)||0);f.jogadoresColocadosMercadoCrise=Array.isArray(f.jogadoresColocadosMercadoCrise)?f.jogadoresColocadosMercadoCrise:[];f.administracaoFinanceira=!!f.administracaoFinanceira;f.recapitalizacoesCrise=Math.max(0,parseInt(f.recapitalizacoesCrise,10)||0);
  }
  function economicCalibrationState(team){initClubFinance(team);const f=team.financeiro;f.calibracaoEconomica=f.calibracaoEconomica&&typeof f.calibracaoEconomica==="object"?f.calibracaoEconomica:{versao:ECONOMIC_CALIBRATION.version,mesesProcessados:0,historicoEstrutura:[]};f.calibracaoEconomica.versao=ECONOMIC_CALIBRATION.version;f.calibracaoEconomica.historicoEstrutura=Array.isArray(f.calibracaoEconomica.historicoEstrutura)?f.calibracaoEconomica.historicoEstrutura:[];f.calibracaoEconomica.historicoResultado=Array.isArray(f.calibracaoEconomica.historicoResultado)?f.calibracaoEconomica.historicoResultado:[];return f.calibracaoEconomica;}
  // Orçamento de transferências (2026-09-05): a direção revê o orçamento a cada 3 meses
  // processados (calibration.mesesProcessados), tendo em conta a condição financeira real do
  // clube — nunca deixando gastar todo o saldo (teto de 20%, pedido explícito do utilizador) e
  // protegendo uma reserva de sobrevivência de 16 meses quando o resultado mensal médio (média
  // dos últimos 3 meses) é negativo. Corre para todos os clubes, humano e IA, simetricamente.
  // Reserva de sobrevivência: partilhada entre o orçamento de transferências (16 meses) e os
  // pedidos de investimento em infraestrutura (mesma regra, mesmo número de meses) — nunca deixar
  // o clube comprometer o dinheiro de que precisa para aguentar N meses ao ritmo atual, sempre que
  // o resultado mensal médio (últimos 3 meses processados) é negativo.
  function financeSurvivalReserve(team,meses){
    const calibration=economicCalibrationState(team);
    const hist=calibration.historicoResultado.slice(-3);
    const avgNet=hist.length?hist.reduce((a,x)=>a+(Number(x.valor)||0),0)/hist.length:financeProjection(team).net;
    return avgNet<0?(meses||16)*Math.abs(avgNet):0;
  }
  function recalculateTransferBudget(team,date){
    initClubFinance(team);const f=team.financeiro,calibration=economicCalibrationState(team);
    const reservaSobrevivencia=financeSurvivalReserve(team,16);
    const teto=Math.max(0,(f.saldo||0)*.2);
    const orcamento=Math.max(0,Math.min(teto,(f.saldo||0)-reservaSobrevivencia));
    f.orcamentoTransferencias=Math.round(orcamento);
    calibration.ultimaRevisaoOrcamentoTransferencias=date?crisisMonthKey(date):(calibration.ultimaRevisaoOrcamentoTransferencias||null);
    return f.orcamentoTransferencias;
  }
  function saturatedCommercialFactor(team){const r=economicCalibrationReputationFactor(team.reputacao),p=clamp(Number(team.reputacaoPontos)||50,0,100),top=p>=85;return Math.min(r.cap,top?.9+Math.max(0,100-p)*.0025:1);}
  // Correção (calibração financeira, proposta P1/P2): o multiplicador de custo por reputação
  // (ECONOMIC_CALIBRATION.reputation[...].structure) usava sempre o mesmo valor para todos os
  // clubes da mesma reputação — incluindo os 7 com perfil financeiro real (CLUB_FINANCE_PROFILES).
  // Isto penalizava duplamente clubes como o Valongo ou o Sanjoanense: reputação desportiva
  // "Internacional"/"Nacional" (mérito real, mantido) mas patrocínio real de câmara municipal
  // muito abaixo do que essa reputação implicaria — ficavam com custos de clube grande e receita
  // de clube pequeno. Este fator ajusta o custo à capacidade financeira REAL do clube quando esta
  // existe, sem alterar a reputação (que continua a valer para tudo o resto: prestígio, IA, etc.).
  function clubFinancialStructureFactor(team){
    const r=economicCalibrationReputationFactor(team.reputacao);
    const profile=CLUB_FINANCE_PROFILES[team.id];
    if(!profile||!profile.sponsorValorAnual)return r.structure;
    const b=financeByReputation(team.reputacao);
    const d=DIVISION_FINANCE_MULT[team.divisaoAtual]||.6;
    const capRef=team.capacidadeFinanceira!=null?team.capacidadeFinanceira:normalizeClubReputation(team.reputacao, team);
    const f=.72+capRef/250;
    const genericSponsorAnnual=Math.round(b.sponsor*d*f)*12;
    // O teto fica em 1 (nunca sobe acima do multiplicador normal da reputação): o objetivo é
    // aliviar quem está abaixo do genérico, não penalizar ainda mais quem já está acima — essa
    // correção (Benfica/Sporting/FC Porto) é feita só do lado da receita, em CLUB_FINANCE_PROFILES.
    const realRatio=clamp(profile.sponsorValorAnual/Math.max(1,genericSponsorAnnual),0.55,1);
    return r.structure*realRatio;
  }
  function calibratedRecurringIncomeParts(team){initClubFinance(team);const f=team.financeiro,d=ECONOMIC_CALIBRATION.division[team.divisaoAtual]||ECONOMIC_CALIBRATION.division["2div"],sat=saturatedCommercialFactor(team),transition=team.planoFinanceiroMudancaDivisao?.ativo&&team.planoFinanceiroMudancaDivisao.tipo==="promocao"?ECONOMIC_CALIBRATION.promotionConvergence:1;return{patrocinio:Math.round((f.receitaMensalPatrocinio||0)*Math.max(d.floor,sat)*transition),quotas:Math.round((f.receitaMensalQuotas||0)*Math.max(d.floor,.96)*transition),apoio:Math.round(f.receitaMensalApoioMunicipal||0),comercial:Math.round((f.receitaMensalComercial||0)*Math.max(d.floor,sat)*transition)};}
  function monthlyStructureCost(team){initClubFinance(team);const f=team.financeiro,d=ECONOMIC_CALIBRATION.division[team.divisaoAtual]||ECONOMIC_CALIBRATION.division["2div"],cf=clubFinancialStructureFactor(team),players=clubSquads(team).reduce((a,t)=>a+(t.players||[]).length,0),excess=Math.max(0,players-ECONOMIC_CALIBRATION.freeSquadSize),training={"Excelentes":1.35,"Muito boas":1.12,"Boas":.94,"Razoáveis":.78}[team.condicoesTreino]||1,wages=monthlyWageBill(team)*(.1+cf*.035),institution=.78+clamp(Number(team.capacidadeFinanceira)||50,5,99)/230;return Math.max(250,Math.round(((ECONOMIC_CALIBRATION.structureBase[team.divisaoAtual]||7200)*cf*training*institution+wages+excess*ECONOMIC_CALIBRATION.extraPlayerCost*d.structure)*(1-(f.corteEstrutura||0))));}
  function economicPolicy(team,extraSalary=0,fee=0){initClubFinance(team);const f=team.financeiro,x=calibratedRecurringIncomeParts(team),income=Object.values(x).reduce((a,v)=>a+v,0),wages=monthlyWageBill(team)+Math.max(0,extraSalary),ratio=wages/Math.max(1,income),reserve=Math.max(income*ECONOMIC_CALIBRATION.reserveMonths,monthlyStructureCost(team)*3,15000),available=Math.max(0,(f.saldo||0)-reserve);return{income,wages,ratio,reserve,available,canIncreaseWages:ratio<=ECONOMIC_CALIBRATION.wageHardLimit&&financialState(team).level<3,canPayFee:fee<=Math.min(available,f.orcamentoTransferencias||0),alert:ratio>ECONOMIC_CALIBRATION.wageAlert};}
  function calibrationSeededRandom(seed){let h=2166136261;for(let i=0;i<String(seed).length;i++){h^=String(seed).charCodeAt(i);h=Math.imul(h,16777619);}return()=>{h+=0x6D2B79F5;let t=h;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
  // Correção (calibração financeira, proposta P6): esta função só olhava para a dívida (limitada
  // ao teto da linha de crédito no simulador), nunca para o saldo — um clube podia ter -7,4M€ de
  // saldo e continuar classificado "risco" para sempre, porque a sua "dívida" formal ficava
  // sempre pequena. Passa a considerar também o saldo (em proporção à receita anual).
  function calibrationFinancialState(balance,debt,annualIncome){const income=Math.max(1,annualIncome),ratio=debt/income,balanceRatio=balance/income;if(balanceRatio>=.18&&ratio<.18)return"saudavel";if(balanceRatio>=0&&ratio<.38)return"atencao";if(balanceRatio>=-.5&&ratio<.65)return"risco";if(balanceRatio>=-1.5&&ratio<.95)return"grave";return"critica";}
  function buildCalibrationModels(){return Object.values(state.teams).filter(t=>!t.equipaPrincipalId).map(team=>{initClubFinance(team);const f=team.financeiro,parts=calibratedRecurringIncomeParts(team);return{id:team.id,name:team.name,division:team.divisaoAtual,reputation:team.reputacao,balance:Number(f.saldo)||0,debt:(Number(f.divida)||0)+(Number(f.creditoUtilizado)||0),credit:Number(f.limiteCredito)||0,monthlyIncome:Object.values(parts).reduce((a,v)=>a+v,0),monthlyWages:monthlyWageBill(team),monthlyStructure:monthlyStructureCost(team),monthlyTraining:monthlyTrainingCost(team),monthlyScouting:monthlyScoutingCost(team),ticket:financeConfig(team).ticket,capacity:financeConfig(team).capacity,homeCost:financeConfig(team).homeCost,annual:[]};});}
  // Correção (calibração financeira, proposta P6, extensão): o simulador corria 20 épocas
  // seguidas sem qualquer intervenção — nem o corte automático de despesa da IA (proposta P4),
  // nem a administração financeira que já existe no jogo real (placeAiClubUnderAdministration,
  // acionada sempre que um clube fica insolvente). Um cenário de 20 anos sem nenhum dos dois
  // nunca acontece a sério, e exagerava artificialmente a gravidade. Passa a espelhar os dois de
  // forma simplificada, ano a ano, com a mesma lógica e ordem de grandeza da versão real.
  function runCalibrationScenario(definition){const rng=calibrationSeededRandom(definition.seed),models=buildCalibrationModels().map(x=>({...x,annual:[],severeStreak:0,structureCutFactor:1})),seasons=definition.seasons||20;for(let season=1;season<=seasons;season++){for(const m of models){let income=m.monthlyIncome*(definition.incomeMultiplier||1),wages=m.monthlyWages*(definition.wageMultiplier||1),structure=m.monthlyStructure*m.structureCutFactor,training=m.monthlyTraining*m.structureCutFactor,annualIncome=0,annualExpense=0;for(let month=0;month<12;month++){const active=month>=2&&month<=10,home=active?2:0,attendance=m.capacity*(m.division==="placard"?.60:m.division==="2div"?.43:.27)*(0.92+rng()*.16),gate=home*attendance*m.ticket,monthlyRevenue=income+gate,monthlyCost=wages+structure+training+m.monthlyScouting+home*m.homeCost+Math.max(0,m.debt)*.08/12;annualIncome+=monthlyRevenue;annualExpense+=monthlyCost;m.balance+=monthlyRevenue-monthlyCost;if(m.balance<0){const draw=Math.min(-m.balance,Math.max(0,m.credit-m.debt));m.debt+=draw;m.balance+=draw;}}const stateId=calibrationFinancialState(m.balance,m.debt,annualIncome);
      // Espelho simplificado da proposta P4 (política financeira automática da IA): o corte de
      // estrutura (25%, o mesmo teto de corte-estrutura em financeAction) liga/desliga com o
      // estado do clube, tal como o toggle real — sem isto, um clube que melhora nunca reverte o
      // corte, e um clube em dificuldade só cortaria despesa muitos anos depois de já ser tarde.
      m.structureCutFactor=(stateId==="risco"||stateId==="grave"||stateId==="critica")?.75:1;
      if(stateId==="grave"||stateId==="critica")m.severeStreak++;else m.severeStreak=0;
      // Espelho simplificado de placeAiClubUnderAdministration (já existe no jogo real): dois
      // anos seguidos em dificuldade grave, mesmo após o corte de despesa, acionam uma
      // recapitalização — nenhum clube IA fica ao abandono 20 épocas seguidas no jogo a sério.
      if(m.severeStreak>=2){m.balance=Math.max(m.balance,Math.max(25000,m.monthlyWages*2));m.debt=Math.round(m.debt*.65);m.severeStreak=0;}
      m.annual.push({season,balance:Math.round(m.balance),debt:Math.round(m.debt),income:Math.round(annualIncome),expense:Math.round(annualExpense),result:Math.round(annualIncome-annualExpense),state:stateId});}}
    const final=models.map(m=>({...m.annual.at(-1),id:m.id,name:m.name,division:m.division,reputation:m.reputation})),counts={saudavel:0,atencao:0,risco:0,grave:0,critica:0};final.forEach(x=>counts[x.state]++);const positive=final.reduce((a,x)=>a+Math.max(0,x.balance),0),rank=final.slice().sort((a,b)=>b.balance-a.balance),topShare=positive?rank.slice(0,4).reduce((a,x)=>a+Math.max(0,x.balance),0)/positive:0;return{id:definition.id,label:definition.label,seed:definition.seed,seasons,counts,healthyOrAttention:(counts.saudavel+counts.atencao)/Math.max(1,final.length),critical:counts.critica/Math.max(1,final.length),topFourWealthShare:Number(topShare.toFixed(4)),clubs:models.map(m=>({id:m.id,name:m.name,division:m.division,reputation:m.reputation,annual:m.annual}))};}
  function runPhaseThreeCalibrationMatrix(){const scenarios=[{id:"base-20",label:"20 épocas automáticas",seed:"hm27-base",seasons:20},{id:"mercado-ativo",label:"Mercado muito ativo",seed:"hm27-market",seasons:20,incomeMultiplier:1.03,wageMultiplier:1.06},{id:"sem-vendas",label:"Sem vendas de jogadores",seed:"hm27-no-sales",seasons:20,incomeMultiplier:.98},{id:"grande-sem-titulos",label:"Grande sem títulos",seed:"hm27-big-no-titles",seasons:10,incomeMultiplier:.94},{id:"clube-endividado",label:"Clube endividado",seed:"hm27-debt",seasons:10,wageMultiplier:1.08},{id:"promovido",label:"Clube promovido",seed:"hm27-promoted",seasons:10,incomeMultiplier:.84},{id:"despromovido",label:"Clube despromovido",seed:"hm27-relegated",seasons:10,incomeMultiplier:.88,wageMultiplier:1.04}],results=scenarios.map(runCalibrationScenario),a=ECONOMIC_CALIBRATION.acceptance,base=results[0],checks=[{id:"saudaveis",pass:base.healthyOrAttention>=a.healthyOrAttentionMin,value:base.healthyOrAttention,target:a.healthyOrAttentionMin},{id:"criticos",pass:base.critical<=a.criticalMax,value:base.critical,target:a.criticalMax},{id:"concentracao",pass:base.topFourWealthShare<=a.topFourWealthMax,value:base.topFourWealthShare,target:a.topFourWealthMax}];const report={schema:"hm2027-calibration-validation",version:1,calibrationVersion:ECONOMIC_CALIBRATION.version,generatedAt:new Date().toISOString(),season:state.season,acceptance:a,passed:checks.every(x=>x.pass),checks,scenarios:results};state.calibrationValidationReport=report;state.calibrationValidationHistory=Array.isArray(state.calibrationValidationHistory)?state.calibrationValidationHistory:[];state.calibrationValidationHistory.push({generatedAt:report.generatedAt,season:state.season,calibrationVersion:report.calibrationVersion,passed:report.passed,checks:report.checks});if(state.calibrationValidationHistory.length>20)state.calibrationValidationHistory=state.calibrationValidationHistory.slice(-20);return report;}
  function validatePhaseThreeSaveFidelity(){const before=runPhaseThreeCalibrationMatrix(),built=buildSaveObject(),migrated=migrateSaveObject(JSON.parse(JSON.stringify(built)));assertDiagnostic(migrated.calibrationValidationReport&&migrated.calibrationValidationReport.calibrationVersion===ECONOMIC_CALIBRATION.version,"Relatório de calibração perdido no save");assertDiagnostic(Array.isArray(migrated.calibrationValidationHistory)&&migrated.calibrationValidationHistory.length,"Histórico de calibração perdido");return `${before.scenarios.length} cenários e ${migrated.calibrationValidationHistory.length} validações preservadas`;}
  function financeRecurringIncome(team){const x=calibratedRecurringIncomeParts(team);return Math.max(1,Object.values(x).reduce((a,v)=>a+v,0));}
  function financeFixedCosts(team){
    initClubFinance(team);const f=team.financeiro;
    const training=monthlyTrainingCost(team)*(1-(f.corteEstrutura||0));
    const formation=Math.round(financeRecurringIncome(team)*(team.divisaoAtual==="3div"?.02:.035)*(1-(f.corteFormacao||0)));
    return monthlyWageBill(team)+training+formation+monthlyStructureCost(team);
  }
  // 0.4.5 — Dia de jogo na projecção: a projecção só via receitas recorrentes (patrocínio, quotas,
  // apoio, comercial) e custos fixos, por isso quase todos os clubes pareciam deficitários antes de
  // a bilheteira entrar. Passa a contar, por mês: jogos em casa (jornadas da liga em casa ÷ meses de
  // época) com a assistência média (a real, se já houver jogos; senão uma estimativa sem sorte face a
  // um adversário mediano), bilhetes pagos ao preço normal, bar, merchandising por jogo e camarotes,
  // menos o custo de organização; e as deslocações dos jogos fora.
  function financeMatchdayEstimate(team){
    const zero={homePerMonth:0,gate:0,extras:0,homeCost:0,awayCost:0,net:0,attendance:0};
    try{
      initClubFinance(team);const f=team.financeiro;
      const comp=Object.values(state.competitions||{}).find(c=>c.teamIds&&c.teamIds.includes(team.id));
      if(!comp||!comp.fixtures||!comp.fixtures.length)return zero;
      const MESES=8,jogosCasa=comp.fixtures.length/2,homePerMonth=jogosCasa/MESES;
      const rivais=comp.teamIds.filter(id=>id!==team.id&&state.teams[id]).map(id=>state.teams[id]).sort((a,b)=>(a.reputacao||0)-(b.reputacao||0));
      const opp=rivais[Math.floor(rivais.length/2)];
      if(!opp)return zero;
      let attendance;
      if((f.jogosCasa||0)>=4&&f.mediaAssistencia>0)attendance=f.mediaAssistencia;
      else{const r=Math.random;try{Math.random=()=>0.5;attendance=matchAttendance(team,opp,{});}finally{Math.random=r;}}
      const percSocios=f.percSocios!=null?f.percSocios:0.3,pagos=attendance*(1-percSocios);
      const cfg=financeConfig(team);
      let preco=f.precoBilhete||cfg.ticket||0;try{preco=pavilhaoPreco(team,"normal");}catch(e){}
      let gate=pagos*preco;
      if(normalizeClubReputation(team.reputacao,team)>=85)gate*=0.95;
      let extras=0;
      try{
        const p=pavilhaoEnsure(team);
        if(p){
          extras+=attendance*PAV_BAR_GASTO*PAV_BAR_NIVEL_MULT[p.bar]*(1-PAV_BAR_CUSTO);
          extras+=Math.max(0,f.receitaMensalComercial||0)*12*PAV_MERCH_FRAC/PAV_MERCH_JOGOS;
          if(p.vip&&p.vip.lugares>0){const ref=pavTicketRef(team)*PAV_VIP_PRECO_MULT;extras+=p.vip.lugares*0.5*(p.vip.preco!=null?p.vip.preco:ref);}
        }
      }catch(e){}
      const homeCost=cfg.homeCost||0;
      let viagem=0;
      try{
        const v=viagemInfo(opp,team,null);
        viagem=v.tier<3&&team.divisaoAtual==="3div"?Math.round(v.custo*DIVISION_OPERATING_COST_MULT["3div"]/10)*10:v.custo;
        if(v.tier===2)viagem*=0.3;
      }catch(e){}
      const net=homePerMonth*(gate+extras-homeCost)-homePerMonth*viagem;
      return {homePerMonth,gate:homePerMonth*gate,extras:homePerMonth*extras,homeCost:homePerMonth*homeCost,awayCost:homePerMonth*viagem,net,attendance:Math.round(attendance)};
    }catch(e){return zero;}
  }
  function financeProjection(team){
    initClubFinance(team);const f=team.financeiro;
    const income=financeRecurringIncome(team),costs=financeFixedCosts(team),matchday=financeMatchdayEstimate(team);
    const interest=(f.divida+f.creditoUtilizado)*(f.taxaJuroAnual||.08)/12;
    const net=income+matchday.net-costs-interest;
    const runway=net<0?Math.max(0,f.saldo/Math.abs(net)):99;
    const monthsLeft=8;
    return {income,costs,interest,net,matchday,runway,endBalance:f.saldo+net*monthsLeft,endDebt:Math.max(0,f.divida-Math.max(0,net)*monthsLeft*.25)};
  }
  function financialState(team){
    initClubFinance(team);const f=team.financeiro,p=financeProjection(team);
    const debtRatio=(f.divida+f.creditoUtilizado)/Math.max(1,p.income*12);
    const wageRatio=monthlyWageBill(team)/Math.max(1,p.income);
    let id="saudavel",label="Saudável",level=0;
    if(debtRatio>1||wageRatio>1.25||(p.runway<1&&p.net<0)){id="critica";label="Situação crítica";level=4;}
    else if(debtRatio>.55||wageRatio>1.1||(p.runway<2&&p.net<0)){id="grave";label="Dificuldade grave";level=3;}
    else if(debtRatio>.25||wageRatio>1||p.endBalance<0){id="risco";label="Risco";level=2;}
    else if(debtRatio>0||wageRatio>.8||p.net<0){id="atencao";label="Atenção";level=1;}
    return {id,label,level,debtRatio,wageRatio,projection:p};
  }
  function syncFinancialState(team,date){
    const f=team.financeiro,st=financialState(team),key=`${(date||state.currentDate||new Date()).getFullYear()}-${String((date||state.currentDate||new Date()).getMonth()+1).padStart(2,"0")}`;
    if(f.ultimoEstadoFinanceiro!==st.id){f.historicoEstados.unshift({date:key,estado:st.id,label:st.label});f.historicoEstados=f.historicoEstados.slice(0,36);f.ultimoEstadoFinanceiro=st.id;}
    if(st.level>=2&&(!f.planoRecuperacao||f.planoRecuperacao.estado!=="ativo")){ // 2026-10-16: depois de um plano cumprido, uma nova crise volta a ter plano
      f.planoRecuperacao={inicio:key,prazoMeses:6,dividaInicial:f.divida+f.creditoUtilizado,metaDivida:Math.round((f.divida+f.creditoUtilizado)*.7),metaReducaoMensal:Math.max(0,Math.ceil(-st.projection.net/100)*100),estado:"ativo"};
    }
    if(f.planoRecuperacao&&f.planoRecuperacao.estado==="ativo"&&(f.divida+f.creditoUtilizado)<=f.planoRecuperacao.metaDivida&&st.projection.net>=0)f.planoRecuperacao.estado="cumprido";
    return st;
  }
  // Fase 1: máquina mensal da crise. Só o fecho financeiro chama esta função.
  function crisisMonthKey(date){
    const d=date instanceof Date?date:new Date(date||state.currentDate||Date.now());
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;
  }
  function recordFinancialCrisisEvent(team,date,type,from,to,details){
    const f=team.financeiro;
    f.historicoCriseFinanceira.unshift({id:`${team.id}:${crisisMonthKey(date)}:${type}`,date:crisisMonthKey(date),type,from:from||null,to:to||from||null,details:details||null,saldo:Math.round(f.saldo||0),divida:Math.round((f.divida||0)+(f.creditoUtilizado||0))});
    f.historicoCriseFinanceira=f.historicoCriseFinanceira.slice(0,120);
  }
  function insolvencyRestrictionsActive(t){initClubFinance(t);return t.financeiro.estadoCriseFinanceira==="insolvencia"&&t.financeiro.restricoesInsolvencia;}
  function crisisSpendingBlock(t,k,v,p){if(!insolvencyRestrictionsActive(t))return null;if(k==="aumento-salarial"&&p&&Number(v)<=Number(p.contrato?.salarioMensal||0))return null;return "Intervenção financeira ativa: esta operação está bloqueada até existir recuperação estrutural.";}
  function activateInsolvencyIntervention(t,d){initClubFinance(t);const f=t.financeiro;if(f.restricoesInsolvencia)return false;const debt=(f.divida||0)+(f.creditoUtilizado||0);f.orcamentoTransferenciasPreIntervencao=f.orcamentoTransferencias||0;f.limiteSalarialPreIntervencao=f.limiteSalarial||0;f.restricoesInsolvencia=true;f.orcamentoTransferencias=0;f.corteFormacao=Math.max(f.corteFormacao||0,.35);f.corteEstrutura=Math.max(f.corteEstrutura||0,.25);f.limiteSalarial=Math.min(f.limiteSalarial||Infinity,Math.max(4500,Math.round(financeRecurringIncome(t)*.72/100)*100));f.intervencaoDirecao={inicio:crisisMonthKey(d),prazoMeses:3,mesesDecorridos:0,estado:"ativa",metas:{saldoMinimo:0,resultadoEstruturalMinimo:0,dividaMaxima:Math.round(debt*.75),tetoSalarial:f.limiteSalarial}};const list=t.players.filter(p=>!p.emprestimo&&!p.__provisional&&canReleasePlayerFromTeam(t,p).ok).sort((a,b)=>(b.contrato?.salarioMensal||0)-(a.contrato?.salarioMensal||0)).slice(0,2);list.forEach(p=>p.transferivel=true);f.jogadoresColocadosMercadoCrise=list.map(p=>p.id);recordFinancialCrisisEvent(t,d,"intervencao-direcao","insolvencia","insolvencia","Plano final de recuperação de três meses aplicado.");return true;}
  function removeInsolvencyIntervention(t,d){const f=t.financeiro;if(!f.restricoesInsolvencia)return false;f.restricoesInsolvencia=false;f.administracaoFinanceira=false;/* 2026-10-16: um clube da IA recuperado pode voltar a ser recapitalizado numa crise futura */if(f.intervencaoDirecao)f.intervencaoDirecao={...f.intervencaoDirecao,estado:"cumprida",fim:crisisMonthKey(d)};f.orcamentoTransferencias=Math.min(f.orcamentoTransferenciasPreIntervencao||0,Math.max(0,(f.saldo||0)*.2));if(f.limiteSalarialPreIntervencao)f.limiteSalarial=Math.max(f.limiteSalarial,f.limiteSalarialPreIntervencao);f.corteFormacao=0;f.corteEstrutura=0;f.ultimaAdvertenciaEmitida=false;return true;}
  // Fases 3/4: fecho terminal da crise, snapshot e tratamento não terminal da IA.
  function careerSnapshot(team,date){
    const matches=Object.values(state.competitions||{}).flatMap(c=>(c.fixtures||[]).flat()).filter(m=>m.played&&(m.home===team.id||m.away===team.id));
    return {clubId:team.id,clubName:team.name,managerName:state.managerName||"Treinador",date:new Date(date||state.currentDate||Date.now()).toISOString(),season:state.season,matches:matches.length,wins:matches.filter(m=>(m.home===team.id&&m.homeScore>m.awayScore)||(m.away===team.id&&m.awayScore>m.homeScore)).length,draws:matches.filter(m=>m.homeScore===m.awayScore).length,losses:matches.filter(m=>(m.home===team.id&&m.homeScore<m.awayScore)||(m.away===team.id&&m.awayScore<m.homeScore)).length,finances:{saldo:Math.round(team.financeiro.saldo||0),divida:Math.round((team.financeiro.divida||0)+(team.financeiro.creditoUtilizado||0))},crisisHistory:JSON.parse(JSON.stringify(team.financeiro.historicoCriseFinanceira||[]))};
  }
  function placeAiClubUnderAdministration(team,date){
    initClubFinance(team);const f=team.financeiro;if(f.administracaoFinanceira)return false;
    f.administracaoFinanceira=true;f.recapitalizacoesCrise=(f.recapitalizacoesCrise||0)+1;f.elegivelFalencia=false;f.mesesInsolventeConsecutivos=0;f.estadoCriseFinanceira="insolvencia";f.saldo=Math.max(f.saldo||0,Math.max(25000,monthlyWageBill(team)*2));f.orcamentoTransferencias=0;f.restricoesInsolvencia=true;f.creditoUtilizado=0;f.divida=Math.max(0,Math.round((f.divida||0)*.65));recordFinancialCrisisEvent(team,date,"administracao-financeira","insolvencia","insolvencia","Recapitalização controlada para proteger o calendário e as competições.");return true;
  }
  function declareClubBankruptcy(team,date){
    initClubFinance(team);const f=team.financeiro;if(!f.elegivelFalencia||f.estadoCriseFinanceira==="falencia")return false;
    if(!isUserControlledTeam(team))return placeAiClubUnderAdministration(team,date);
    f.estadoCriseFinanceira="falencia";f.restricoesInsolvencia=true;recordFinancialCrisisEvent(team,date,"falencia","insolvencia","falencia","Falência definitiva após incumprimento do plano final de recuperação.");state.gameOver=true;state.gameOverReason="falencia";state.gameOverAt=new Date(date||state.currentDate||Date.now());state.gameOverSnapshot=careerSnapshot(team,state.gameOverAt);setTimeout(()=>{try{saveGame();}catch(error){console.error(error);}if(typeof showGameOverModal==="function")showGameOverModal();},0);return true;
  }
  function processFinancialCrisisMonthly(team,date){
    initClubFinance(team); const f=team.financeiro,key=crisisMonthKey(date);
    if(f.ultimoProcessamentoCriseMensal===key||f.estadoCriseFinanceira==="falencia")return false;
    const st=financialState(team),previous=f.estadoCriseFinanceira;
    const recovered=st.level<=1&&st.projection.net>=0&&(f.saldo||0)>=0;
    if(previous==="insolvencia"){
      activateInsolvencyIntervention(team,date);if(f.intervencaoDirecao)f.intervencaoDirecao.mesesDecorridos=f.mesesInsolventeConsecutivos;
      if(recovered){
        f.mesesRecuperacaoConsecutivos++;
        if(f.mesesRecuperacaoConsecutivos>=2){f.estadoCriseFinanceira="normal";f.mesesCriticosConsecutivos=0;f.mesesInsolventeConsecutivos=0;f.mesesRecuperacaoConsecutivos=0;f.elegivelFalencia=false;recordFinancialCrisisEvent(team,date,"recuperacao","insolvencia","normal","Recuperação estrutural confirmada em dois fechos mensais consecutivos.");removeInsolvencyIntervention(team,date);}
      }else{
        f.mesesRecuperacaoConsecutivos=0;f.mesesInsolventeConsecutivos++;
        if(f.mesesInsolventeConsecutivos>=2&&!f.ultimaAdvertenciaEmitida){f.ultimaAdvertenciaEmitida=true;recordFinancialCrisisEvent(team,date,"ultima-advertencia","insolvencia","insolvencia","Último mês do plano final de recuperação.");}
        if(f.mesesInsolventeConsecutivos>=3&&!f.elegivelFalencia){f.elegivelFalencia=true;recordFinancialCrisisEvent(team,date,"elegibilidade-falencia","insolvencia","insolvencia","Prazo de insolvência atingido; a declaração fica reservada para a Fase 3.");}
      }
    }else if(st.id==="critica"){
      f.mesesCriticosConsecutivos++;f.mesesRecuperacaoConsecutivos=0;
      if(previous!=="critica"){f.estadoCriseFinanceira="critica";recordFinancialCrisisEvent(team,date,"entrada-critica",previous,"critica","Situação crítica confirmada no fecho mensal.");}
      if(f.mesesCriticosConsecutivos>=2){f.estadoCriseFinanceira="insolvencia";f.mesesInsolventeConsecutivos=0;f.mesesRecuperacaoConsecutivos=0;f.elegivelFalencia=false;activateInsolvencyIntervention(team,date);recordFinancialCrisisEvent(team,date,"entrada-insolvencia","critica","insolvencia","Dois fechos mensais críticos consecutivos.");}
    }else{
      if(previous==="critica")recordFinancialCrisisEvent(team,date,"saida-critica","critica","normal","Os critérios de situação crítica deixaram de se verificar.");
      f.estadoCriseFinanceira="normal";f.mesesCriticosConsecutivos=0;f.mesesInsolventeConsecutivos=0;f.mesesRecuperacaoConsecutivos=0;f.elegivelFalencia=false;
    }
    f.ultimoProcessamentoCriseMensal=key;if(f.elegivelFalencia)declareClubBankruptcy(team,date);return true;
  }
  function financeAction(team,action,value){
    if(state.gameOver)return{ok:false,reason:"A carreira terminou por falência."};
    initClubFinance(team);const f=team.financeiro,st=financialState(team);value=Math.max(0,Math.round(Number(value)||0));
    if(action==="credito"){const b=crisisSpendingBlock(team,"credito",value);if(b)return{ok:false,reason:b};
      const available=Math.max(0,f.limiteCredito-f.creditoUtilizado),amount=Math.min(value||available,available);
      if(!amount)return{ok:false,reason:"A linha de crédito não tem disponibilidade."};
      f.creditoUtilizado+=amount;f.saldo+=amount;f.movimentos.unshift({date:new Date(state.currentDate).toISOString(),type:"receita",category:"Financiamento",description:"Utilização da linha de crédito",value:amount});
    }else if(action==="emprestimo"){
      {const b=crisisSpendingBlock(team,"emprestimo",value);if(b)return{ok:false,reason:b};} // 2026-10-16: o aviso de intervenção diz que novos empréstimos estão bloqueados
      if(st.level>=4)return{ok:false,reason:"A banca recusou novo empréstimo devido à situação crítica."};
      const max=Math.round(financeRecurringIncome(team)*6),amount=Math.min(value||max,max);
      f.divida+=amount;f.saldo+=amount;f.taxaJuroAnual=Math.max(f.taxaJuroAnual,st.level>=3?.13:st.level>=2?.105:.075);f.movimentos.unshift({date:new Date(state.currentDate).toISOString(),type:"receita",category:"Financiamento",description:"Empréstimo bancário",value:amount});
    }else if(action==="antecipar"){
      const remaining=Math.max(0,(f.sponsorValorAnual||0)*.35-f.receitaPatrocinioAntecipada),gross=Math.min(value||remaining,remaining),net=Math.round(gross*.92);
      if(!gross)return{ok:false,reason:"Não existem mais receitas de patrocínio disponíveis para antecipar."};
      f.receitaPatrocinioAntecipada+=gross;f.saldo+=net;const corteMensal=Math.min(f.receitaMensalPatrocinio,Math.round(gross/12));f.receitaMensalPatrocinio=Math.max(0,f.receitaMensalPatrocinio-corteMensal);
      // 2026-10-16: o corte dura 12 meses — depois repõe-se a receita mensal e o limite de 35% (ver processMonthlyFinances).
      {const dFim=new Date(state.currentDate);dFim.setMonth(dFim.getMonth()+12);if(!Array.isArray(f.antecipacoesPatrocinio))f.antecipacoesPatrocinio=[];f.antecipacoesPatrocinio.push({fim:`${dFim.getFullYear()}-${String(dFim.getMonth()+1).padStart(2,"0")}`,mensal:corteMensal,bruto:gross});}f.movimentos.unshift({date:new Date(state.currentDate).toISOString(),type:"receita",category:"Financiamento",description:"Adiantamento de patrocínio, líquido de comissão",value:net});
    }else if(action==="amortizar"){
      const total=f.divida+f.creditoUtilizado,amount=Math.min(value||Math.min(f.saldo,total),f.saldo,total);if(!amount)return{ok:false,reason:"Não existe saldo ou dívida para amortizar."};
      let rest=amount,payCredit=Math.min(rest,f.creditoUtilizado);f.creditoUtilizado-=payCredit;rest-=payCredit;f.divida=Math.max(0,f.divida-rest);f.saldo-=amount;f.movimentos.unshift({date:new Date(state.currentDate).toISOString(),type:"despesa",category:"Dívida",description:"Amortização voluntária",value:amount});
    }else if(action==="corte-formacao")f.corteFormacao=f.corteFormacao>=.5?0:.5;
    else if(action==="corte-estrutura")f.corteEstrutura=f.corteEstrutura>=.25?0:.25;
    else if(action==="bilhete")f.precoBilhete=clamp(value,1,15);
    syncFinancialState(team,state.currentDate);return{ok:true};
  }
  function initClubFinance(team){
    if(team.financeiro){ normalizeFinancePhase2(team); ensureFinanceAudit(team.financeiro); return; }
    // Equipas B não têm finanças próprias — são um custo (linha de despesa) do clube principal.
    // Em vez de duplicar toda a lógica financeira, a equipa B partilha o MESMO objeto financeiro
    // do clube principal: qualquer receita ou despesa dos jogos/salários da B soma-se
    // diretamente ao saldo, orçamento e massa salarial do clube principal — exatamente como um
    // custo (ou eventual receita pontual) da equipa A, nunca um orçamento autónomo.
    if(team.equipaPrincipalId){
      const parent = state.teams[team.equipaPrincipalId];
      if(parent){
        if(!parent.financeiro) initClubFinance(parent);
        team.financeiro = parent.financeiro;
        return;
      }
    }
    const c=financeConfig(team);
    // Orçamento inicial de transferências (2026-09-17, pedido do utilizador: "parece-me que os
    // saldos iniciais sao muito altos e, por isso, os orçamentos para transferencias tambem...
    // ou se baixam os saldos ou a direcção tem de baixar o orçamento de transferencias atendendo
    // à prespectiva financeira a longo prazo" — alternativa aceite pelo utilizador). Antes, era
    // sempre 20% fixo do saldo inicial (Math.round(c.saldo*.2)) — proporcional a uma tabela de
    // saldos por reputação já calibrada e reutilizada noutros sítios (FINANCE_REPUTATION_ANCHORS),
    // que este ponto não altera. A mesma filosofia já usada na recalibração pós-subida/descida de
    // divisão (adaptClubFinanceToDivision, mais acima: uma fração pequena da RECEITA RECORRENTE
    // ANUAL, não do saldo em caixa) passa a aplicar-se também aqui — teto de 15% do saldo, ou 6%
    // da receita recorrente anual, o que for menor.
    const annualRecurringInitial=(c.sponsor+c.commercial+c.quotas+c.apoioMunicipal)*12;
    team.financeiro={ saldo:c.saldo, saldoInicialEpoca:c.saldo, receitasEpoca:0, despesasEpoca:0,
      receitaMensalPatrocinio:c.sponsor, receitaMensalComercial:c.commercial,
      receitaMensalQuotas:c.quotas, receitaMensalApoioMunicipal:c.apoioMunicipal,
      sponsorNome:c.sponsorNome, sponsorValorAnual:c.sponsorValorAnual, sponsorObjetivo:c.objetivoDesportivo,
      percSocios:c.percSocios, mediaSocios:0, mediaBilhetesPagos:0,
      ultimoProcessamentoMensal:null,
      movimentos:[], divida:0, limiteSalarial:c.wageBudget, orcamentoTransferencias:Math.max(0,Math.round(Math.min(c.saldo*.15,annualRecurringInitial*.06))),
      capacidadePavilhao:c.capacity, precoBilhete:c.ticket, mediaAssistencia:0, jogosCasa:0, alerta:"",
      baseAdeptos:computeBaseAdeptos(team, c.capacity) };
    normalizeFinancePhase2(team);ensureFinanceAudit(team.financeiro);
  }

  // ============================= Fase 16: normalização da massa salarial inicial =============================
  // Os salários de cada jogador são gerados individualmente a partir do OVR (ver generateContract
  // em 01-nucleo.js), sem qualquer relação com o limite salarial do clube — o que produzia
  // plantéis (sobretudo os provisórios da 2ª Divisão) a nascer com 150-290% do limite, antes de
  // qualquer contratação. Esta normalização corre uma única vez, na criação de uma carreira nova
  // (chooseClub), e só reduz salários — nunca os aumenta artificialmente.
  function initialWageTargetRatio(team){
    // Taxa-alvo contínua (55%-82%): clubes financeiramente mais frágeis (capacidadeFinanceira
    // baixa) ocupam uma fatia maior do limite salarial; clubes mais robustos ficam com mais
    // margem para reforçar o plantel, renovar e aguentar imprevistos.
    const cap = team.capacidadeFinanceira!=null ? team.capacidadeFinanceira : normalizeClubReputation(team.reputacao, team);
    return clamp(0.76 - (clamp(cap,0,99)/99)*0.18, 0.55, 0.82);
  }
  function normalizeInitialWageBill(team){
    initClubFinance(team);
    const budget = team.financeiro.limiteSalarial;
    if(String(team.id||"").startsWith("selecaoNacional-")) return;
    const players = team.players.filter(p=>p.contrato);
    const currentTotal = players.reduce((s,p)=>s+p.contrato.salarioMensal,0);
    if(!budget || currentTotal<=0) return;
    const targetTotal = budget*initialWageTargetRatio(team);
    if(currentTotal<=targetTotal) return; // já está numa margem saudável — não mexe
    // Correção (calibração financeira, ajuste de receitas — informação do utilizador): os 450€
    // de generateContract são um valor real, mas só para clubes da 3ª Divisão a lutar pela
    // subida; a generalidade paga entre 200€ e 450€. Ao aplicar sempre o mesmo piso de 450€
    // também aqui, esta normalização ficava impedida de comprimir os plantéis mais fracos para
    // esse intervalo mais realista — todos os jogadores da 3ª Divisão acabavam presos exatamente
    // nos 450€, sem qualquer variação. O piso desce para 200€ só na 3ª Divisão.
    const piso = team.divisaoAtual==="3div" ? 200 : 450;
    // 0.2.9: quem não recebe nada (amadores da 3.ª Divisão) continua a 0 — o piso só vale para quem já é pago.
    const roundTo=v=>v<=0?0:Math.max(piso,Math.round(v/50)*50);
    const factor = targetTotal/currentTotal;
    players.forEach(p=>{ p.contrato.salarioMensal = roundTo(p.contrato.salarioMensal*factor); });
    // O piso de 450€ e o arredondamento a 50€ podem deixar o total um pouco acima do alvo —
    // uma segunda passagem reduz só quem ainda está acima do piso, proporcionalmente.
    let guard=0, total=players.reduce((s,p)=>s+p.contrato.salarioMensal,0);
    while(total>targetTotal*1.03 && guard<6){
      const above = players.filter(p=>p.contrato.salarioMensal>piso); // 2026-10-16: na 3.ª Divisão o piso é 200, não 450
      if(!above.length) break;
      const aboveTotal = above.reduce((s,p)=>s+p.contrato.salarioMensal,0);
      const f2 = Math.max(0, 1-(total-targetTotal)/aboveTotal);
      above.forEach(p=>{ p.contrato.salarioMensal = roundTo(p.contrato.salarioMensal*f2); });
      total = players.reduce((s,p)=>s+p.contrato.salarioMensal,0);
      guard++;
    }
  }
  // Calibração económica Fase 1: medição não-invasiva e persistente.
  function ensureFinanceAudit(f){if(!f)return f;f.historicoAnual=Array.isArray(f.historicoAnual)?f.historicoAnual:[];f.auditoriaEpoca=f.auditoriaEpoca||{receitas:{},despesas:{}};f.auditoriaEpoca.receitas=f.auditoriaEpoca.receitas||{};f.auditoriaEpoca.despesas=f.auditoriaEpoca.despesas||{};f.saldoInicialEpoca=Number.isFinite(+f.saldoInicialEpoca)?+f.saldoInicialEpoca:(+f.saldo||0);f.dividaInicialEpoca=Number.isFinite(+f.dividaInicialEpoca)?+f.dividaInicialEpoca:(+f.divida||0)+(+f.creditoUtilizado||0);f.estadoCriseInicioEpoca=f.estadoCriseInicioEpoca||f.estadoCriseFinanceira||"normal";return f;}
  function financeAuditCategory(c){c=String(c||"Outras").toLowerCase();for(const [k,v] of [["patrocinio",["patroc"]],["quotas",["quota"]],["apoioMunicipal",["municip"]],["comercial",["comercial","bar e rest","merch","camarote"]],["bilheteira",["bilhet"]],["premios",["prémio","premio"]],["transferencias",["transfer","venda"]],["salarios",["salár","salar"]],["treino",["treino"]],["formacao",["formaç","formac"]],["organizacao",["organiza"]],["encargosFinanceiros",["juro","crédito","credito"]],["rescisoes",["rescis"]],["estrutura",["estrutura"]]])if(v.some(x=>c.includes(x)))return k;return"outras";}
  function financeAuditSum(x){return Object.values(x||{}).reduce((a,v)=>a+(+v||0),0);}
  function financeSeasonAudit(team,epoca){initClubFinance(team);const f=ensureFinanceAudit(team.financeiro),r={...f.auditoriaEpoca.receitas},d={...f.auditoriaEpoca.despesas},rr=(r.patrocinio||0)+(r.quotas||0)+(r.apoioMunicipal||0)+(r.comercial||0),tr=(r.transferencias||0)-(d.transferencias||0),dop=financeAuditSum(d)-(d.transferencias||0),w=monthlyWageBill(team);return{epoca:epoca||seasonLabel(state.season),saldoInicial:Math.round(f.saldoInicialEpoca||0),saldoFinal:Math.round(f.saldo||0),dividaInicial:Math.round(f.dividaInicialEpoca||0),dividaFinal:Math.round((f.divida||0)+(f.creditoUtilizado||0)),receitas:r,despesas:d,receitaRecorrente:Math.round(rr),receitaExtraordinaria:Math.round(financeAuditSum(r)-rr),despesaOperacional:Math.round(dop),resultadoOperacional:Math.round(financeAuditSum(r)-(r.transferencias||0)-dop),resultadoTransferencias:Math.round(tr),resultadoLiquido:Math.round(financeAuditSum(r)-financeAuditSum(d)),massaSalarialMensal:Math.round(w),massaSalarialAnual:Math.round(w*12),racioSalarial:rr?+(w*12/rr).toFixed(4):null,valorPlantel:Math.round(clubSquads(team).flatMap(x=>x.players||[]).reduce((a,p)=>a+(+p.valor||0),0)),estadoInicial:f.estadoCriseInicioEpoca,estadoFinal:financialState(team).id};}
  function closeFinanceAuditSeason(team,epoca){team=financialOwnerTeam(team);const f=ensureFinanceAudit(team.financeiro),x=financeSeasonAudit(team,epoca),i=f.historicoAnual.findIndex(v=>v&&v.epoca===x.epoca);if(i<0)f.historicoAnual.push(x);else f.historicoAnual[i]=x;if(f.historicoAnual.length>40)f.historicoAnual=f.historicoAnual.slice(-40);f.saldoInicialEpoca=f.saldo;f.dividaInicialEpoca=(f.divida||0)+(f.creditoUtilizado||0);f.estadoCriseInicioEpoca=x.estadoFinal;f.auditoriaEpoca={receitas:{},despesas:{}};return x;}
  function buildFinanceBaselineReport(){const rows=Object.values(state.teams).filter(t=>!t.equipaPrincipalId).map(t=>({id:t.id,nome:t.name,divisao:t.divisaoAtual,reputacao:t.reputacao,...financeSeasonAudit(t)})),med=a=>{a=a.slice().sort((x,y)=>x-y);return a.length?(a[(a.length-1)>>1]+a[a.length>>1])/2:0},divisoes={};for(const z of new Set(rows.map(r=>r.divisao))){const a=rows.filter(r=>r.divisao===z),v=k=>a.map(x=>+x[k]||0);divisoes[z]={clubes:a.length,receitaMedia:Math.round(v("receitaRecorrente").reduce((x,y)=>x+y,0)/a.length),receitaMediana:Math.round(med(v("receitaRecorrente"))),despesaMedia:Math.round(v("despesaOperacional").reduce((x,y)=>x+y,0)/a.length),resultadoMedio:Math.round(v("resultadoLiquido").reduce((x,y)=>x+y,0)/a.length),clubesComPrejuizo:a.filter(x=>x.resultadoLiquido<0).length,racioSalarialMedio:+(v("racioSalarial").reduce((x,y)=>x+y,0)/a.length).toFixed(4)};}const rank=rows.slice().sort((a,b)=>b.saldoFinal-a.saldoFinal),total=rows.reduce((a,x)=>a+Math.max(0,x.saldoFinal),0),ids=new Set(["benfica","sporting","porto","barcelos"]);return{geradoEm:new Date().toISOString(),epoca:state.season,divisoes,riqueza:{quatroMaisRicos:rank.slice(0,4),concentracao:total?+(rank.slice(0,4).reduce((a,x)=>a+Math.max(0,x.saldoFinal),0)/total).toFixed(4):0,diferenca:rank.length?rank[0].saldoFinal-rank.at(-1).saldoFinal:0},grandes:rows.filter(x=>ids.has(x.id)),clubes:rows};}
  function addFinanceMovement(team, type, category, description, value, date){
    initClubFinance(team); const f=ensureFinanceAudit(team.financeiro); const amount=Math.max(0,Math.round(value));
    if(type==="receita"){ f.saldo+=amount; f.receitasEpoca+=amount; }
    else { f.saldo-=amount; f.despesasEpoca+=amount; }
    const auditSide=type==="receita"?f.auditoriaEpoca.receitas:f.auditoriaEpoca.despesas,auditKey=financeAuditCategory(category);auditSide[auditKey]=(auditSide[auditKey]||0)+amount;
    f.movimentos.unshift({ date:(date||state.currentDate||new Date()).toISOString(), type, category, description, value:amount });
    if(f.movimentos.length>100) f.movimentos.length=100;
    // Fase 15: saldo negativo acumula dívida em vez de ficar apenas registado como alerta.
    if(f.saldo<0){ f.divida=(f.divida||0)+(-f.saldo); f.saldo=0; }
    const st=syncFinancialState(financialOwnerTeam(team),date||state.currentDate||new Date());
    f.alerta=st.level>=2?`${st.label}: dívida total ${fmtMoney((f.divida||0)+(f.creditoUtilizado||0))} e resultado mensal previsto de ${fmtMoney(st.projection.net)}.`:f.saldo<50000?"Atenção: tesouraria abaixo de 50.000 €.":"";
  }
  // Correção (auditoria, bug crítico #3): como a equipa B partilha o mesmo objeto financeiro
  // do clube principal, calcular a massa salarial só a partir de team.players ignorava sempre
  // o custo de um dos dois plantéis. Passa a agregar sempre a equipa principal e a sua equipa B
  // (quando existe) — o custo salarial total sai sempre do mesmo orçamento partilhado.
  function financialOwnerTeam(team){ return team.equipaPrincipalId ? state.teams[team.equipaPrincipalId] : team; }
  function clubSquads(team){
    const parent = financialOwnerTeam(team);
    const squads = [parent];
    if(parent.equipaBId && state.teams[parent.equipaBId]) squads.push(state.teams[parent.equipaBId]);
    return squads;
  }
  // 0.4.18: índice (em cache) dos jogadores emprestados. Antes, cada chamada percorria todos os
  // jogadores de todas as equipas (milhares) e era chamada milhares de vezes na pré-época
  // (aiRecruitmentFinanciallySafe → financialState). O índice só guarda as referências aos jogadores
  // com empréstimo; os valores (dono, parte do salário) são lidos de novo a cada cálculo, por isso
  // fim/alteração de empréstimos e de salários reflectem-se de imediato. Reconstrói-se quando muda o
  // dia, o estado ou é criado um empréstimo (invalidateLoanIndex).
  function invalidateLoanIndex(){_loanIdx.list=null;}
  function loanedPlayersIndex(){
    const d=String(state.currentDate);
    if(_loanIdx.list&&_loanIdx.st===state&&_loanIdx.date===d) return _loanIdx.list;
    const list=[];
    Object.values(state.teams).forEach(t=>{ if(String(t.id||"").startsWith("selecaoNacional-")) return; (t.players||[]).forEach(p=>{ if(p.emprestimo) list.push(p); }); });
    _loanIdx={st:state,date:d,list};
    return list;
  }
  function monthlyWageBill(team){
    const squads = clubSquads(team);
    const squadIds = new Set(squads.map(s=>s.id));
    let incoming=0;
    squads.forEach(squad=>{
      incoming += squad.players.reduce((sum,p)=>sum+(p.contrato?.salarioMensal||0)*(p.emprestimo?p.emprestimo.salaryShare/100:1),0);
    });
    let outgoing=0;
    loanedPlayersIndex().forEach(p=>{const l=p.emprestimo;if(l&&squadIds.has(l.ownerId))outgoing+=(p.contrato?.salarioMensal||0)*(1-l.salaryShare/100);});
    return Math.round(incoming+outgoing);
  }
  // Custo de alojamento de jogadores deslocados (2026-09-06, pedido do utilizador): "para além de
  // ter de se pagar casa, tem de ser um custo para além do salário e um jogador com reputação
  // maior vai pedir uma casa mais cara." Recorrente por época (mensal, como o salário), pago pelo
  // clube onde o jogador joga atualmente, escalado pela reputação pessoal do jogador
  // (reputacaoJogador, 0-100) — nunca pelo OVR, é sobre fama/exigência, não qualidade técnica.
  const DISPLACEMENT_HOUSING_BASE = 350, DISPLACEMENT_HOUSING_MAX_BONUS = 2200;
  function playerHousingCost(player){
    const rep = clamp(player.reputacaoJogador||0, 0, 100);
    return Math.round((DISPLACEMENT_HOUSING_BASE + DISPLACEMENT_HOUSING_MAX_BONUS*(rep/100))/10)*10;
  }
  function monthlyHousingBill(team){
    let total=0;
    clubSquads(team).forEach(squad=>{ squad.players.forEach(p=>{ if(isPlayerDisplaced(p,squad)) total+=playerHousingCost(p); }); });
    return Math.round(total);
  }
  function wageToBudgetRatio(team){ initClubFinance(team); return team.financeiro.limiteSalarial ? monthlyWageBill(team)/team.financeiro.limiteSalarial : 0; }
  function wageHealthTier(ratio){ return ratio<=0.6?"saudavel":ratio<=0.75?"atencao":"risco"; }
  function wageHealthLabel(tier){ return {saudavel:"Saudável",atencao:"Atenção",risco:"Risco"}[tier]||tier; }
  // Fase 13: impacto do papel prometido (Titular/Rotação/Desenvolvimento) na satisfação, quando
  // a utilização real (jogos como titular) se afasta do que foi combinado no contrato.
  function applyRolePromiseSatisfaction(team){
    const gamesSoFar = Math.max(1, state.currentRound||1);
    team.players.forEach(p=>{
      if(!p.contrato || !p.contrato.papel) return;
      const usageRatio = clamp((p.season.jogosTitular||0)/gamesSoFar, 0, 1);
      const expected = p.contrato.papel==="Titular" ? 0.6 : p.contrato.papel==="Rotacao" ? 0.25 : 0.05;
      const gap = usageRatio-expected;
      let delta=0;
      if(gap<-0.25) delta=-1.2; else if(gap<-0.1) delta=-0.5; else if(gap>0.15) delta=0.3;
      if(delta) p.satisfacao=clamp((p.satisfacao!=null?p.satisfacao:70)+delta,0,100);
    });
  }
  // Proposta P4 (calibração financeira): equivalente automático, para clubes IA, dos botões
  // "Reduzir formação"/"Reduzir estrutura" que já existem em financeAction só para o utilizador.
  // Liga os cortes ao teto já definido (25%/50%) quando o clube está em risco (nível ≥2) e acima
  // do alerta salarial, e desliga-os quando a operação volta a ser saudável — o mesmo
  // comportamento de toggle que financeAction já usa, só que decidido pela IA em vez de um clique.
  function applyAiFinancialPolicy(team,date){
    if(isUserControlledTeam(team))return;
    initClubFinance(team);const f=team.financeiro,st=financialState(team);
    if(st.level>=2&&economicPolicy(team).alert){
      if(!f.corteEstrutura)f.corteEstrutura=0.25;
      if(!f.corteFormacao)f.corteFormacao=0.5;
    }else if(st.level<=1&&st.projection.net>=0){
      if(f.corteEstrutura)f.corteEstrutura=0;
      if(f.corteFormacao)f.corteFormacao=0;
    }
  }
  // Correção (auditoria, bug crítico #3): a equipa B, ao partilhar o objeto financeiro do
  // clube principal, ficava marcada como "já processada este mês" assim que o clube principal
  // era processado primeiro (mesmo objeto, mesmo campo ultimoProcessamentoMensal) — o efeito
  // real era o custo salarial da equipa B nunca chegar a ser descontado, nem uma única vez. As
  // equipas B deixam de ser processadas como entidade financeira independente; o seu custo
  // entra sempre através do clube principal (monthlyWageBill já agrega os dois plantéis).
  function processMonthlyFinances(date){
    const monthKey=`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}`;
    patrocinioMensal(date);
    pavilhaoMensal(date);
    arbitroMensal(date);
    satMensal(date);
    Object.values(state.teams).forEach(team=>{
      if(team.equipaPrincipalId) return;
      initClubFinance(team); const f=team.financeiro;
      if(f.ultimoProcessamentoMensal===monthKey) return;
      // 2026-10-16: fim de uma antecipação de patrocínio — repõe a receita mensal cortada e o limite disponível.
      if(Array.isArray(f.antecipacoesPatrocinio)&&f.antecipacoesPatrocinio.length){
        f.antecipacoesPatrocinio=f.antecipacoesPatrocinio.filter(a=>{
          if(a.fim>monthKey) return true;
          f.receitaMensalPatrocinio=(f.receitaMensalPatrocinio||0)+(a.mensal||0);
          f.receitaPatrocinioAntecipada=Math.max(0,(f.receitaPatrocinioAntecipada||0)-(a.bruto||0));
          return false;
        });
      }
      const calibratedIncome=calibratedRecurringIncomeParts(team),calibration=economicCalibrationState(team);
      patrocinioPagarMensal(team,calibratedIncome.patrocinio,date);
      // Pedido do utilizador: jogos em casa europeus "podem gerar mais e melhores patrocínios nas
      // épocas em que se qualificam" — bónus mensal, percentagem do patrocínio já calibrado do
      // próprio clube (nunca um valor fixo), enquanto o clube participa numa prova europeia essa
      // época (ed.participantes, nível mais alto atingido — ver 07g-europa.js).
      const europaTier = (state.europa && state.europa.edicao && state.europa.edicao.participantes) ? state.europa.edicao.participantes[team.id] : null;
      const europaPct = europaTier && EUROPA_SPONSOR_BONUS_PCT[europaTier];
      if(europaPct){
        const bonusEuropa = Math.round(calibratedIncome.patrocinio*europaPct);
        if(bonusEuropa>0) addFinanceMovement(team,"receita","Patrocínio",`Prémio de patrocínio por participação europeia (${EUROPA_SPONSOR_BONUS_LABEL[europaTier]})`,bonusEuropa,date);
      }
      updateAdeptosMonthly(team);
      addFinanceMovement(team,"receita","Quotas de sócios","Quotas mensais dos sócios",adeptosQuotaIncome(team,calibratedIncome.quotas),date);
      addFinanceMovement(team,"receita","Apoio municipal","Subsídio mensal da autarquia",calibratedIncome.apoio,date);
      addFinanceMovement(team,"receita","Comercial","Merchandising e publicidade",calibratedIncome.comercial,date);
      const debtTotal=(f.divida||0)+(f.creditoUtilizado||0);
      if(debtTotal>0){
        // Correção (calibração financeira, proposta P3): dois travões à dívida. (a) O juro
        // baixa a metade enquanto o clube está sob intervenção da direção ou com um plano de
        // recuperação ativo — sem isto, o juro continuava a acumular ao ritmo normal mesmo
        // durante o próprio plano desenhado para o recuperar. (b) A amortização automática
        // deixa de depender do saldo acumulado (que, uma vez negativo, nunca mais permitia
        // amortizar nada) e passa a usar o excedente operacional deste mês — assim que a
        // exploração corrente do clube fica positiva, começa logo a reduzir dívida, mesmo que o
        // saldo histórico continue negativo.
        const emRecuperacao=!!((f.intervencaoDirecao&&f.intervencaoDirecao.estado==="ativa")||(f.planoRecuperacao&&f.planoRecuperacao.estado==="ativo")); // 2026-10-16: uma intervenção já "cumprida" deixava os juros a metade para sempre
        const taxaEfetiva=(f.taxaJuroAnual||.08)*(emRecuperacao?.5:1);
        const interest=Math.max(1,Math.round(debtTotal*taxaEfetiva/12));
        f.encargosFinanceirosEpoca+=interest;addFinanceMovement(team,"despesa","Juros","Encargos mensais da dívida e crédito",interest,date);
        const operatingSurplus=Math.max(0,financeRecurringIncome(team)-financeFixedCosts(team));
        const amort=Math.min(operatingSurplus,Math.round(financeRecurringIncome(team)*(financialState(team).level>=3?.08:.04)),debtTotal);
        if(amort>0){let rest=amort,pay=Math.min(rest,f.creditoUtilizado);f.creditoUtilizado-=pay;rest-=pay;f.divida=Math.max(0,f.divida-rest);f.saldo-=amort;f.despesasEpoca+=amort;f.movimentos.unshift({date:new Date(date).toISOString(),type:"despesa",category:"Dívida",description:"Amortização automática",value:amort});}
      }
      // Correção (calibração financeira, proposta P4): política financeira automática para
      // clubes não controlados pelo utilizador — um clube IA em risco (nível ≥2) e acima do
      // alerta salarial corta despesa sozinho, tal como um gestor prudente faria, em vez de só
      // reagir depois de já estar insolvente (o mecanismo de administração financeira mantém-se
      // como rede de segurança final, sem alteração).
      applyAiFinancialPolicy(team,date);
      addFinanceMovement(team,"despesa","Salários",`Massa salarial mensal do plantel${team.equipaBId?" (equipa A + equipa B)":""}`,monthlyWageBill(team),date);
      const housingBill=monthlyHousingBill(team);
      if(housingBill>0) addFinanceMovement(team,"despesa","Alojamento","Alojamento de jogador(es) deslocado(s) do país de origem",housingBill,date);
      addFinanceMovement(team,"despesa","Infraestruturas",`Manutenção das condições de treino: ${team.condicoesTreino}`,Math.round(monthlyTrainingCost(team)*(1-(f.corteEstrutura||0))),date);
      addFinanceMovement(team,"despesa","Formação",`Investimento mensal na formação${f.corteFormacao?" (reduzido)":""}`,Math.round(financeRecurringIncome(team)*(team.divisaoAtual==="3div"?.02:.035)*(1-(f.corteFormacao||0))),date);
      const structureCost=monthlyStructureCost(team);addFinanceMovement(team,"despesa","Estrutura","Custos profissionais, administrativos e de dimensão do plantel",structureCost,date);calibration.mesesProcessados=(calibration.mesesProcessados||0)+1;calibration.ultimoCustoEstrutura=structureCost;calibration.historicoEstrutura.push({mes:monthKey,valor:structureCost});if(calibration.historicoEstrutura.length>24)calibration.historicoEstrutura=calibration.historicoEstrutura.slice(-24);
      // Painel de scouting (2026-09-05): todos os clubes — humano e IA — pagam um encargo
      // recorrente básico de scouting, simetricamente (pedido explícito do utilizador). Só o
      // utilizador humano paga também, à parte, o custo pontual de um relatório detalhado sobre
      // um jogador específico (requestScoutingReport) — a IA não precisa de nevoeiro, só do custo.
      addFinanceMovement(team,"despesa","Scouting","Encargos mensais do departamento de scouting",monthlyScoutingCost(team),date);
      addFinanceMovement(team,"despesa","Departamento médico","Encargos mensais do departamento médico e fisioterapia",monthlyMedicalCost(team),date);
      syncAiMedicalLevel(team);
      const netSnapshot=financeProjection(team).net;
      calibration.historicoResultado.push({mes:monthKey,valor:Math.round(netSnapshot)});
      if(calibration.historicoResultado.length>24)calibration.historicoResultado=calibration.historicoResultado.slice(-24);
      if(calibration.mesesProcessados%3===0 && !f.restricoesInsolvencia)recalculateTransferBudget(team,date);
      maybeAiRequestDirectionInvestment(team,date);
      syncFinancialState(team,date);
      processFinancialCrisisMonthly(team,date);
      applyRolePromiseSatisfaction(team);
      updateBalnearioMonthly(team);
      persMensal(team);
      if(team.equipaBId && state.teams[team.equipaBId]) applyRolePromiseSatisfaction(state.teams[team.equipaBId]);
      f.ultimoProcessamentoMensal=monthKey;
      if(isUserControlledTeam(team)) grafFinSerieRegistar(team,monthKey);
    });
  }
  function matchAttendance(home,away,opts){
    opts=opts||{};
    initClubFinance(home);
    const f=home.financeiro;
    if(f.baseAdeptos==null) f.baseAdeptos=computeBaseAdeptos(home, f.capacidadePavilhao);
    const base=f.baseAdeptos;
    const oppFactor=matchOpponentInterestFactor(away);
    const contextFactor=matchCompetitiveContextFactor(home);
    const formFactor=matchFormFactor(home);
    const rivalryFactor=matchRivalryFactor(home.id,away.id);
    // Pedido do utilizador: "jogos em casa têm melhor assistência" nas competições europeias —
    // um "jogo grande" decisivo (playoff) continua a valer o bónus máximo (1.25), mas mesmo um
    // jogo europeu normal (fase de grupos, ou uma mão não decisiva) já tem mais público do que um
    // jogo doméstico equivalente ("noite europeia").
    const competitionFactor=opts.playoff ? 1.25 : (opts.europa ? 1.15 : 1);
    const randomFactor=.85+Math.random()*.3;
    // Conselho de Disciplina (08k): um jogo à porta fechada não tem público. Televisão (08m): parte do público fica a ver em casa.
    if(disciplinaPortaFechada(home)) return 0;
    const tvFactor=tvJogoTransmitido(home.id,away.id)?0.92:1;
    const raw=base*oppFactor*contextFactor*formFactor*rivalryFactor*competitionFactor*randomFactor*adeptosAttendanceFactor(home)*tvFactor*pavilhaoAtendimentoMult(home,away,opts);   // preços, qualidade e pavilhão alternativo (08o)
    const capEfetiva=pavilhaoCapacidade(home);
    const floor=Math.min(capEfetiva,Math.max(10,Math.round(base*.35)));
    // 0.2.4: lotação esgotada garantida nos Clássicos; nos Jogos Grandes pelo menos 88% do pavilhão.
    const piso=(typeof derbyPisoAtendimento==="function")?derbyPisoAtendimento(home.id,away.id,capEfetiva):0;
    return Math.round(clamp(Math.max(raw,piso),floor,capEfetiva));
  }
  function processMatchFinances(homeId,awayId,date,opts){
    const home=state.teams[homeId], away=state.teams[awayId]; initClubFinance(home); initClubFinance(away);
    // Correção (pedido do utilizador, 2026-09-17: assistência fixa): quando o jogo foi ao vivo,
    // opts.attendance já traz o valor único calculado no início do jogo (newMatchState), o mesmo
    // que o ecrã ao vivo mostrou — evita um segundo sorteio independente aqui. Jogos simulados em
    // bloco pela IA (sem opts.attendance) continuam a calcular um valor fresco, sem qualquer
    // problema de "mudar durante o jogo" porque nunca são mostrados a decorrer.
    const attendance=(opts&&opts.attendance!=null)?opts.attendance:matchAttendance(home,away,opts); const cfg=financeConfig(home);
    const esgotado = attendance>=pavilhaoCapacidade(home);
    // Assistência total separada entre sócios (já pagam quota mensal, não geram bilheteira) e
    // bilhetes pagos (fonte de receita de bilheteira).
    const percSocios = home.financeiro.percSocios!=null ? home.financeiro.percSocios : 0.3;
    const socios = Math.round(attendance*percSocios);
    const pagos = attendance-socios;
    const derbyTxt = (isDerby(home.id,away.id) ? " · Clássico" : (opts&&opts.playoff ? " · Playoff" : "")) + (esgotado ? " · Lotação esgotada" : "");
    const bil=pavilhaoBilheteira(home,away,pagos,opts); const bilheteiraTotal=bil.total;
    // Proposta P5 (calibração financeira): fundo de solidariedade. 5% da bilheteira dos clubes
    // "Classe Mundial"/"Internacional" em casa é retido para um fundo comum, redistribuído no
    // fecho da época pelos clubes em dificuldade (ver distributeSolidarityFund) — o único
    // mecanismo genuinamente redistributivo desta calibração; os restantes só corrigem
    // assimetrias na fórmula.
    const solidario=(normalizeClubReputation(home.reputacao, home)>=85)?Math.round(bilheteiraTotal*0.05):0;
    if(solidario>0)state.fundoSolidariedadeEpoca=(state.fundoSolidariedadeEpoca||0)+solidario;
    addFinanceMovement(home,"receita","Bilheteira",`${home.name} vs ${away.name}${derbyTxt} · ${pagos} bilhetes pagos${bil.visitantes?` (${bil.visitantes} visitantes)`:""} + ${socios} sócios${solidario?` (5% para o fundo de solidariedade)`:""}`,bilheteiraTotal-solidario,date);
    { const extra=pavilhaoReceitasExtra(home,away,attendance,opts,date,esgotado)||{}; pavilhaoAposJogo(home,away,attendance,{bilheteira:bilheteiraTotal-solidario,visitantes:bil.visitantes,bar:extra.bar,merch:extra.merch,vip:extra.vip}); }
    // Pedido do utilizador: o custo de organização de um jogo não devia ser sempre exatamente o
    // mesmo valor de referência do clube — varia um pouco de jogo para jogo (±15%), tal como a
    // assistência, para maior realismo (arbitragem, segurança, logística nunca custam exatamente
    // o mesmo de jornada para jornada).
    addFinanceMovement(home,"despesa","Organização",`Organização do jogo frente ao ${away.name}`,Math.round(cfg.homeCost*(.85+Math.random()*.3)),date);
    // Viagens (2026-10-12): o custo depende da zona geográfica das duas equipas (ver
    // 08j-viagens.js) — mesma zona, outra zona, ilhas ou estrangeiro. Os jogos europeus noutro
    // país mantêm o valor internacional (equipa e staff, avião, hotel e autocarro).
    const viagem = viagemInfo(home, away, opts);
    // 0.2.9: as tabelas de viagem (700/1.500/7.000 €) são de clubes profissionais. Na 3.ª Divisão (receitas ~2.000 €/mês)
    // escalam-se pelo fator de custos operacionais da divisão (0,12). Além disso, as deslocações às ilhas têm apoio do
    // Estado/região (informação do utilizador): 70% do custo regressa como receita "Apoio às deslocações" (sem apoio,
    // o GD Estreito, na Madeira, ia à falência em 3 meses só com viagens).
    const custoDeslocacao = viagem.tier<3 && away.divisaoAtual==="3div" ? Math.round(viagem.custo*DIVISION_OPERATING_COST_MULT["3div"]/10)*10 : viagem.custo;
    const deslocacaoTxt = viagem.tier===3 ? `Deslocação internacional ao recinto do ${home.name} (equipa e staff, avião + hotel + autocarro)`
      : `${viagemTexto(viagem)} ao recinto do ${home.name}`;
    addFinanceMovement(away,"despesa","Deslocação",deslocacaoTxt,custoDeslocacao,date);
    if(viagem.tier===2) addFinanceMovement(away,"receita","Apoio municipal","Apoio do Estado às deslocações às ilhas",Math.round(custoDeslocacao*0.7),date);
    const jc=home.financeiro.jogosCasa;
    home.financeiro.mediaAssistencia=Math.round((home.financeiro.mediaAssistencia*jc+attendance)/(jc+1));
    home.financeiro.mediaSocios=Math.round(((home.financeiro.mediaSocios||0)*jc+socios)/(jc+1));
    home.financeiro.mediaBilhetesPagos=Math.round(((home.financeiro.mediaBilhetesPagos||0)*jc+pagos)/(jc+1));
    home.financeiro.jogosCasa++;
  }
  // Correção (auditoria): esta função usava sortedStandings(), que depende de qual competição
  // estava a ser VISUALIZADA no ecrã (state.viewedCompetitionId) — os prémios de fim de época
  // podiam ser atribuídos à tabela errada consoante o separador que estivesse aberto. Passa a
  // percorrer explicitamente as três competições, com uma escala de prémios própria por divisão.
  function awardSeasonFinances(){
    const PRIZE_SCALE = {
      placard: [150000,90000,60000,45000,30000,25000,20000,15000],
      "2div": [40000,25000,18000,14000,10000,8000,6000,5000],
      "3div": [15000,10000,7000,5500,4000,3000,2200,1600],
    };
    Object.values(state.competitions).forEach(comp=>{
      const table = standingsForCompetition(comp.id);
      const prizes = PRIZE_SCALE[comp.divisionId] || PRIZE_SCALE["2div"];
      const floor = Math.round((prizes[prizes.length-1]||5000)*0.6);
      table.forEach((team,i)=>addFinanceMovement(team,"receita","Prémio de competição",`Classificação final: ${i+1}.º lugar (${competitionLabel(comp.id)})`,prizes[i]||floor,state.currentDate));
    });
  }
  // Proposta P5 (calibração financeira): distribui o fundo de solidariedade acumulado durante a
  // época (5% da bilheteira em casa dos clubes "Classe Mundial"/"Internacional", ver
  // processMatchFinances) em partes iguais pelos clubes em estado "risco" ou "grave" no fecho da
  // época. Sem clubes elegíveis, o fundo simplesmente não é distribuído nesta época (não
  // transporta para a seguinte, para manter o mecanismo simples e prever­sível).
  function distributeSolidarityFund(){
    const fundo=Math.round(state.fundoSolidariedadeEpoca||0);
    state.fundoSolidariedadeEpoca=0;
    if(fundo<=0)return;
    const elegiveis=Object.values(state.teams).filter(t=>!t.equipaPrincipalId&&financialState(t).level>=2);
    if(!elegiveis.length)return;
    const parte=Math.round(fundo/elegiveis.length);
    if(parte<=0)return;
    elegiveis.forEach(team=>addFinanceMovement(team,"receita","Fundo de solidariedade",`Parte do fundo de solidariedade da época (${elegiveis.length} clubes elegíveis)`,parte,state.currentDate));
  }
  function fmtMoney(v){ return new Intl.NumberFormat("pt-PT",{style:"currency",currency:"EUR",maximumFractionDigits:0}).format(v||0); }
  function financeCategoryTotals(team,period){
    initClubFinance(team);const rows=team.financeiro.movimentos||[],filtered=period?rows.filter(m=>String(m.date||"").slice(0,7)===period):rows;
    const result={receita:{},despesa:{}};
    filtered.forEach(m=>{const type=m.type==="receita"?"receita":"despesa",cat=m.category||"Outros";result[type][cat]=(result[type][cat]||0)+(m.value||0);});
    return result;
  }
  function financeRecommendations(team){
    const f=team.financeiro,st=financialState(team),p=st.projection,out=[];
    if(p.net<0){
      const deficit=Math.ceil(Math.abs(p.net)/100)*100;
      out.push({kind:"estrutural",title:"Eliminar o défice mensal",text:`É necessária uma melhoria recorrente de aproximadamente ${fmtMoney(deficit)}/mês.`});
      const salaryTarget=Math.min(deficit,Math.round(monthlyWageBill(team)*.18));
      if(salaryTarget>0)out.push({kind:"estrutural",title:"Reduzir salários",text:`Uma redução de ${fmtMoney(salaryTarget)}/mês na massa salarial melhora diretamente o resultado operacional.`});
      const cuts=Math.round(monthlyTrainingCost(team)*.25+financeRecurringIncome(team)*.0175);
      out.push({kind:"estrutural",title:"Combinar cortes",text:`Reduzir estrutura e formação pode poupar cerca de ${fmtMoney(cuts)}/mês, com impacto desportivo futuro.`});
      out.push({kind:"liquidez",title:"Venda ou financiamento",text:`Para cobrir 8 meses sem corrigir o défice seriam necessários ${fmtMoney(deficit*8)}. Esta solução apenas compra tempo.`});
    }else out.push({kind:"positivo",title:"Operação sustentável",text:`A estrutura gera aproximadamente ${fmtMoney(p.net)}/mês antes de receitas extraordinárias.`});
    if((f.divida||0)+(f.creditoUtilizado||0)>0)out.push({kind:"divida",title:"Reduzir encargos",text:`A dívida gera cerca de ${fmtMoney(p.interest)}/mês em juros. Amortizar crédito reduz primeiro o custo financeiro.`});
    return out;
  }
  function financeScenario(team,action,value){
    const f=team.financeiro,p=financeProjection(team);value=Math.max(0,Number(value)||0);
    let saldo=f.saldo,divida=(f.divida||0)+(f.creditoUtilizado||0),net=p.net,label="Sem alteração";
    if(action==="salario"){net+=value;label=`Redução salarial de ${fmtMoney(value)}/mês`;}
    if(action==="venda"){saldo+=value;label=`Venda de jogadores por ${fmtMoney(value)}`;}
    if(action==="credito"){saldo+=value;divida+=value;net-=value*(f.taxaJuroAnual||.08)/12;label=`Financiamento de ${fmtMoney(value)}`;}
    if(action==="investimento"){saldo-=value;label=`Investimento de ${fmtMoney(value)}`;}
    const end=saldo+net*8;
    return {label,saldo,divida,net,end,state:end<0||divida>p.income*6?"Risco":net<0?"Atenção":"Saudável"};
  }
  function financeHistoryHtml(f){
    const rows=f.historicoEpocas||[];
    if(!rows.length)return '<p class="helptext">O histórico financeiro será criado no fecho da primeira época.</p>';
    return `<table class="stat-list"><thead><tr><th>Época</th><th class="num">Saldo inicial</th><th class="num">Saldo final</th><th class="num">Receitas</th><th class="num">Despesas</th><th class="num">Resultado</th><th class="num">Dívida final</th></tr></thead><tbody>${rows.slice().reverse().map(r=>`<tr><td>${r.epoca}</td><td class="num">${fmtMoney(r.saldoInicial)}</td><td class="num">${fmtMoney(r.saldoFinal)}</td><td class="num finance-income">${fmtMoney(r.receitas)}</td><td class="num finance-expense">${fmtMoney(r.despesas)}</td><td class="num">${fmtMoney(r.resultado)}</td><td class="num">${fmtMoney(r.dividaFinal)}</td></tr>`).join("")}</tbody></table>`;
  }
  function renderFinances(){
    const team=myTeam();if(!team)return;initClubFinance(team);const f=team.financeiro,st=syncFinancialState(team,state.currentDate),p=st.projection;
    const movements=f.movimentos||[],monthKey=state.currentDate?`${state.currentDate.getFullYear()}-${String(state.currentDate.getMonth()+1).padStart(2,"0")}`:"";
    const month=movements.filter(m=>String(m.date||"").slice(0,7)===monthKey),monthIn=month.filter(m=>m.type==="receita").reduce((a,m)=>a+m.value,0),monthOut=month.filter(m=>m.type==="despesa").reduce((a,m)=>a+m.value,0);
    const result=f.receitasEpoca-f.despesasEpoca,totalDebt=(f.divida||0)+(f.creditoUtilizado||0);
    document.getElementById("financeSeasonLabel").textContent=`Época ${seasonLabel(state.season)} · ${st.label}`;
    grafRenderFinancas(team);
    document.getElementById("financeSummary").innerHTML=`
      <div class="stat-row stat-row-5">
        ${[["Saldo disponível",f.saldo,"neutral"],["Dívida total",totalDebt,totalDebt?'neg':'pos'],["Receitas do mês",monthIn,"pos"],["Despesas do mês",monthOut,"neg"],["Resultado mensal",monthIn-monthOut,monthIn-monthOut>=0?'pos':'neg']].map(([l,v,c])=>`<div class="stat-mini"><div class="eyebrow">${l}</div><b class="stat-mini-money money-${c}">${fmtMoney(v)}</b></div>`).join("")}
      </div>
      <div class="finance-status-banner finance-status-${st.level>=3?'crit':st.level>=1?'warn':'ok'}"><b>Estado: ${st.label}</b> · Massa salarial ${Math.round(st.wageRatio*100)}% das receitas recorrentes · Resultado estrutural ${fmtMoney(p.net)}/mês · ${p.net<0?`autonomia aproximada ${p.runway.toFixed(1)} meses`:'tesouraria com tendência positiva'}.</div>
      ${f.restricoesInsolvencia&&f.intervencaoDirecao?`<div class="insolvency-intervention"><b>Intervenção da direção · plano final de 3 meses</b><br>Compras, contratações, novos empréstimos e aumentos salariais bloqueados. Vendas, dispensas e amortizações disponíveis.</div>`:''}
      ${f.planoRecuperacao&&f.planoRecuperacao.estado==='ativo'?`<div class="finance-recovery-plan"><b>Plano de recuperação ativo</b><br>Meta de dívida: ${fmtMoney(f.planoRecuperacao.metaDivida)} · melhoria mensal necessária: ${fmtMoney(f.planoRecuperacao.metaReducaoMensal)} · prazo indicativo: ${f.planoRecuperacao.prazoMeses} meses.</div>`:''}`;
    document.getElementById("financeProjection").innerHTML=`
      <div class="pm-postmatch-grid"><div><b>Receita recorrente/mês</b><br>${fmtMoney(p.income)}</div><div><b>Custos fixos/mês</b><br>${fmtMoney(p.costs)}</div><div><b>Dia de jogo/mês (média)</b><br>${fmtMoney(p.matchday.net)}</div><div><b>Juros previstos/mês</b><br>${fmtMoney(p.interest)}</div><div><b>Previsão em 8 meses</b><br>${fmtMoney(p.endBalance)}</div><div><b>Linha de crédito</b><br>${fmtMoney(f.creditoUtilizado)} / ${fmtMoney(f.limiteCredito)}</div><div><b>Preço do bilhete</b><br>${fmtMoney(f.precoBilhete)}</div></div>
      <div id="financeActions" style="display:flex;flex-wrap:wrap;gap:7px;margin-top:10px;">
        <button class="btn btn-ghost" data-fin-action="credito">Usar linha de crédito</button><button class="btn btn-ghost" data-fin-action="emprestimo">Pedir empréstimo</button><button class="btn btn-ghost" data-fin-action="antecipar">Antecipar patrocínio</button><button class="btn btn-ghost" data-fin-action="amortizar">Amortizar dívida</button><button class="btn btn-ghost" data-fin-action="corte-formacao">${f.corteFormacao?'Repor':'Reduzir'} formação</button><button class="btn btn-ghost" data-fin-action="corte-estrutura">${f.corteEstrutura?'Repor':'Reduzir'} estrutura</button><button class="btn btn-ghost" data-fin-action="bilhete">Alterar bilhete</button>
      </div>
      <p class="helptext">Crédito e empréstimos criam juros. Antecipar patrocínio reduz receitas futuras. Cortes melhoram a tesouraria, mas prejudicam formação, estrutura e atratividade.</p>`;
    const players=clubSquads(team).flatMap(x=>x.players).slice().sort((a,b)=>(b.contrato?.salarioMensal||0)-(a.contrato?.salarioMensal||0)),wages=monthlyWageBill(team);
    document.getElementById("financeSquadCosts").innerHTML=`<table class="stat-list"><thead><tr><th>Jogador</th><th class="num">Salário/mês</th><th class="num">Contrato</th><th class="num">% massa salarial</th></tr></thead><tbody>${players.map(x=>{const sal=x.contrato?.salarioMensal||0;return `<tr><td>${playerNameHtml(x)}</td><td class="num">${fmtMoney(sal)}</td><td class="num">${x.contrato?.anos||0} ano(s)</td><td class="num">${wages?Math.round(sal/wages*100):0}%</td></tr>`}).join("")}</tbody></table>`;
    document.getElementById("financeMovements").innerHTML=movements.length?`<div class="eyebrow section-label">Movimentos</div><table class="stat-list"><thead><tr><th>Data</th><th>Tipo</th><th>Categoria</th><th>Descrição</th><th class="num">Valor</th></tr></thead><tbody>${movements.slice(0,40).map(m=>`<tr><td>${fmtDateShort(new Date(m.date))}</td><td class="money-${m.type==='receita'?'pos':'neg'}" style="font-weight:700;">${m.type==='receita'?'RECEITA':'DESPESA'}</td><td>${escapeHtml(m.category)}</td><td>${escapeHtml(m.description)}</td><td class="num money-${m.type==='receita'?'pos':'neg'}">${m.type==='receita'?'+':'-'}${fmtMoney(m.value)}</td></tr>`).join("")}</tbody></table>`:'<p class="helptext">Ainda sem movimentos financeiros.</p>';
    const totals=financeCategoryTotals(team,null),rec=financeRecommendations(team);
    const categoryRows=(obj,type)=>Object.entries(obj).sort((a,b)=>b[1]-a[1]).map(([cat,val])=>`<tr><td>${escapeHtml(cat)}</td><td class="num ${type==='receita'?'finance-income':'finance-expense'}">${type==='receita'?'+':'-'}${fmtMoney(val)}</td></tr>`).join("")||'<tr><td colspan="2">Sem movimentos</td></tr>';
    document.getElementById("financeProjection").innerHTML+=`<div class="finance-dashboard-grid"><section class="finance-section"><h3>Composição das receitas</h3><table class="stat-list"><tbody>${categoryRows(totals.receita,'receita')}</tbody></table></section><section class="finance-section"><h3>Composição das despesas</h3><table class="stat-list"><tbody>${categoryRows(totals.despesa,'despesa')}</tbody></table></section></div>`;
    document.getElementById("financeBudget").innerHTML=`
      <section class="finance-section"><h3>Orçamento previsto vs. estrutura atual</h3><table class="stat-list"><thead><tr><th>Indicador mensal</th><th class="num">Previsto</th><th class="num">Atual</th><th class="num">Desvio</th></tr></thead><tbody><tr><td>Receitas recorrentes</td><td class="num">${fmtMoney(f.orcamentoPrevisto.receitaMensal)}</td><td class="num">${fmtMoney(p.income)}</td><td class="num">${fmtMoney(p.income-f.orcamentoPrevisto.receitaMensal)}</td></tr><tr><td>Despesas fixas</td><td class="num">${fmtMoney(f.orcamentoPrevisto.despesaMensal)}</td><td class="num">${fmtMoney(p.costs+p.interest)}</td><td class="num">${fmtMoney(p.costs+p.interest-f.orcamentoPrevisto.despesaMensal)}</td></tr></tbody></table></section>
      <section class="finance-section"><h3>Recomendações</h3><div class="finance-recommendations">${rec.map(x=>`<article class="finance-tip finance-tip-${x.kind}"><b>${x.title}</b><span>${x.text}</span></article>`).join("")}</div></section>
      <section class="finance-section"><h3>Simulador de decisão</h3><div class="finance-simulator"><select id="financeScenarioAction"><option value="salario">Redução salarial mensal</option><option value="venda">Venda de jogadores</option><option value="credito">Novo financiamento</option><option value="investimento">Investimento imediato</option></select><input id="financeScenarioValue" type="number" min="0" step="500" value="10000"><button class="btn btn-primary" id="financeScenarioBtn">Simular</button></div><div id="financeScenarioResult" class="helptext">A simulação não altera o jogo.</div></section>
      <section class="finance-section"><h3>Histórico por época</h3>${financeHistoryHtml(f)}</section>`;
    document.getElementById('financeScenarioBtn').onclick=()=>{const scenario=financeScenario(team,document.getElementById('financeScenarioAction').value,document.getElementById('financeScenarioValue').value);document.getElementById('financeScenarioResult').innerHTML=`<b>${scenario.label}</b> · resultado mensal ${fmtMoney(scenario.net)} · saldo em 8 meses ${fmtMoney(scenario.end)} · dívida ${fmtMoney(scenario.divida)} · estado projetado: ${scenario.state}.`;};
    document.querySelectorAll('#financeActions [data-fin-action]').forEach(btn=>btn.onclick=()=>{const action=btn.dataset.finAction;let value=0;if(['credito','emprestimo','antecipar','amortizar'].includes(action))value=parseInt(prompt('Valor (€):','25000'),10)||0;if(action==='bilhete')value=parseInt(prompt('Novo preço do bilhete (€):',f.precoBilhete),10)||f.precoBilhete;const r=financeAction(team,action,value);if(!r.ok)alert(r.reason);renderFinances();});
  }

  // Nível de condições de treino, na mesma escala 0-100 dos restantes fatores de apelo (Boas
  // fica como referência central, ~50, tal como o valor por omissão dos outros fatores).
  const TREINO_APPEAL_SCORE = { "Excelentes":90, "Muito boas":70, "Boas":50, "Razoáveis":25 };
  // Pedido do utilizador: as condições de treino não contavam nada para o apelo do clube — um
  // jogador ambicioso, sobretudo jovem a pensar no desenvolvimento, dá importância real a isto.
  // Pesos rebalanceados (mantendo a mesma hierarquia geral): reputação 38%→36%, competição
  // 32%→30%, desempenho 18%→16%, finanças 12%→10%, condições de treino (novo) 8%.
  function clubAppeal(t){syncClubStrategicProfile(t);return clamp(t.reputacaoClube*.36+competitionPrestigeForTeam(t)*.30+t.desempenhoRecente*.16+t.capacidadeFinanceira*.10+(TREINO_APPEAL_SCORE[t.condicoesTreino]!=null?TREINO_APPEAL_SCORE[t.condicoesTreino]:50)*.08,5,99);}
  // Valores calibrados para a escala económica do hóquei em patins: transferências pagas são excecionais.
  // Correção (pedido do utilizador, 2026-09-17: "um jogador da terceira divisão não vale
  // 1000€"): o piso de 1000€ era universal, tal como acontecia com o salário antes de
  // divisionSalaryProfile/expectedSalary passarem a escalar por divisão — impunha o mesmo
  // mínimo do Placard a um jogador da 3ª Divisão. ownerTeam (opcional, retrocompatível: quando
  // omitido, comporta-se exatamente como antes) escala o piso pelo mesmo DIVISION_FINANCE_MULT
  // já usado no resto das finanças, com 150€ como mínimo absoluto na 3ª Divisão.
  function playerMarketValue(p, ownerTeam){
    const divMult = ownerTeam ? (DIVISION_FINANCE_MULT[ownerTeam.divisaoAtual] ?? 1) : 1;
    const floor = Math.max(150, Math.round(1000*divMult));
    const ovr=overall(p),base=Math.max(floor,(ovr-10)*2500);
    const ageMult=p.age<=21?1.45:p.age<=24?1.25:p.age<=29?1:p.age<=33?.72:.42;
    const potentialMult=p.age<=23?1+clamp((p.potential-ovr)*.08,0,.4):1;
    // Prémios de fim de época (2026-09-21): bónus directo e permanente, somado quando o jogador
    // vence um prémio (ver grantSeasonAward, 08-evolucao-jogadores.js) — o acoplamento via
    // reputacaoJogador (+90/ponto, linha acima) tem um tecto baixo (só +90€ por ponto de
    // reputação) para tornar um prémio visivelmente sentido no valor de mercado.
    return Math.max(floor,Math.round((base*ageMult*potentialMult+(p.reputacaoJogador||0)*90+(p.valorPremioBonus||0))/500)*500);
  }
  // Correção (OK Liga, 2026-09-06): "divisionDrop" só olhava para o Placard — um jogador do
  // Placard a mudar para a OK Liga (ou vice-versa) não é uma descida de divisão, são duas 1ªs
  // divisões de países diferentes (ver PLAYOFF_DIVISION_CONFIG, 07-playoff.js).
  function transferInterest(p,o,t){const youngMinutes=p.age<=23&&!p.titular?12:0,divisionDrop=!!PLAYOFF_DIVISION_CONFIG[o.divisaoAtual]&&!PLAYOFF_DIVISION_CONFIG[t.divisaoAtual]?-18:0,starPenalty=overall(p)>=16&&clubAppeal(t)<clubAppeal(o)?-18:0;const score=50+(clubAppeal(t)-clubAppeal(o))*.9+youngMinutes+divisionDrop+starPenalty;return{accepts:score>=48,reason:score>=48?"Aceita negociar":divisionDrop?"Não quer descer de divisão":starPenalty?"Clube insuficiente":"Sem interesse"};}

  // ============================= Fase 12/13: Contratos, mercado regulamentado e negociações =============================
  function contractYearsRemaining(contrato){
    if(!contrato || !contrato.dataFim) return contrato?contrato.anos||0:0;
    if(!state.currentDate) return contrato.anos||0;
    const end=new Date(contrato.dataFim+"T00:00:00Z");
    return Math.max(0,(end-state.currentDate)/(365.25*86400000));
  }
  function isFinalContractYear(player){ return player.contrato ? contractYearsRemaining(player.contrato)<=1.05 : true; }
  function contractStatusLabel(player){
    if(player.pendingTransferHold){
      const destino=state.teams[player.pendingTransferHold.toTeamId];
      return `🏷️ Etiqueta TRF → ${destino?destino.name:"outro clube"} (a partir de ${fmtDateShort(new Date(player.pendingTransferHold.effectiveFromDate+"T00:00:00Z"))})`;
    }
    // Limite de 1 transferência por época (pedido do utilizador 2026-09-14): assim que a
    // inscrição desta época já foi usada, o jogador fica indisponível para nova transferência,
    // assinatura de livre ou empréstimo até à época seguinte — mostra-se aqui pela mesma razão
    // que a etiqueta TRF acima, para o utilizador perceber logo porque as propostas são recusadas.
    if(playerTransferLimitReached(player)){
      return `🔁 Já transferido esta época — só muda de clube na época seguinte`;
    }
    if(player.preContrato){
      const destino=state.teams[player.preContrato.destinoId];
      return `Pré-contratado com ${destino?destino.name:"outro clube"} (a partir da próxima época)`;
    }
    if(!player.contrato) return "Sem contrato";
    return isFinalContractYear(player) ? "Último ano de contrato" : "Contrato ativo";
  }
  // Salário "justo" de referência, usado como âncora nas negociações. Correção (calibração
  // salarial por divisão, pedido do utilizador 2026-09-05): dependia só do valor de mercado do
  // jogador (OVR/idade/reputação), nunca da divisão do clube pagador — dois jogadores
  // equivalentes acabavam a "merecer" o mesmo salário estivessem no Placard ou na 3ª Divisão,
  // quando a realidade é ordens de grandeza diferente. Recebe agora o clube (o que vai pagar —
  // toTeam numa transferência/pré-contrato, o próprio clube numa renovação) e usa a mesma tabela
  // salarial por divisão de generateContract/divisionSalaryEstimate. Sem team (chamadas antigas
  // não identificadas), mantém a fórmula original como rede de segurança.
  function expectedSalary(player, team){
    if(!team) return Math.max(450,Math.round(playerMarketValue(player)*0.011 + (player.age>29?200:0)));
    return divisionSalaryEstimate(overall(player), player.reputacaoJogador||0, player.age, team.divisaoAtual);
  }
  // Fase de carreira usada na evolução, no papel pretendido e na flexibilidade salarial.
  function careerStage(player){
    const age=player.age||25, ovr=overall(player), physicalKeys=player.pos==="GR"?["agilidade","resistencia","forca"]:["velocidade","aceleracao","resistencia","forca"];
    const physical=avg(physicalKeys.map(k=>player.attrs[k]!=null?player.attrs[k]:12));
    if(age<=21) return {id:"inicio",label:"Início de carreira",salaryFloor:0.72,roleFlex:2};
    if(age<=26) return {id:"afirmacao",label:"Afirmação",salaryFloor:0.94,roleFlex:0};
    if(age<=31) return {id:"auge",label:"Auge",salaryFloor:1,roleFlex:0};
    if(age>=35 || physical<11 || ovr<=13) return {id:"final",label:"Final de carreira",salaryFloor:0.68,roleFlex:2};
    return {id:"declinio",label:"Declínio",salaryFloor:0.82,roleFlex:1};
  }
  function transferNegotiationKey(player,fromTeam,toTeam){return [player.id,fromTeam.id,toTeam.id].join("|");}
  // Estatuto do jogador no plantel: 5 níveis, calculados automaticamente por playerSquadImportance
  // mas substituíveis manualmente pelo utilizador (player.estatutoManual) — ver effectivePlayerEstatuto.
  const PLAYER_STATUS_LEVELS = ["Indispensável","Titular importante","Rotação","Suplente","Excedentário"];
  // Importância desportiva real: para equipas IA não depende da flag manual "titular".
  function playerSquadImportance(player,team){
    const squad=(team.players||[]).filter(p=>p.pos===player.pos);
    const games=player.season?.jogos||0, starts=player.season?.jogosTitular||0;
    const usageSample=clamp(games/8,0,1), startRate=games?starts/games:0;
    const ordered=squad.slice().sort((a,b)=>overall(b)-overall(a));
    const rank=Math.max(0,ordered.findIndex(p=>p.id===player.id));
    const rankScore=ordered.length<=1?100:100*(1-rank/(ordered.length-1));
    const next=ordered[rank+1], qualityGap=next?clamp((overall(player)-overall(next))*8,-16,24):12;
    const tactical=player.pos==="GR"?8:(aiSystemCriticalityBlock(team,player)?15:0);
    const promised=player.contrato?.papel==="Titular"?10:player.contrato?.papel==="Desenvolvimento"?3:5;
    // Correção (2026-10-16, "o Porto vendeu 4 titulares na 1.ª época"): sem jogos disputados
    // (pré-época / início de época) a participação valia 0 e o estatuto de TODOS os jogadores
    // ficava limitado a ~74 — nunca "imprescindível" (>=80), por isso a IA podia comprar os
    // melhores jogadores de qualquer clube ao preço de mercado. Enquanto a amostra é pequena,
    // a participação mistura-se com a esperada pelo lugar no plantel (top 5 de campo / 1.º GR
    // = titular provável); com 8+ jogos o valor é exatamente o que era antes.
    const expectedStart=rank<(player.pos==="GR"?1:5)?.9:rank<(player.pos==="GR"?2:7)?.35:.1;
    const participation=clamp((startRate*90+(games?10:0))*usageSample+(expectedStart*90+10)*(1-usageSample),0,100);
    const score=participation*.45+rankScore*(1-usageSample*.35)*.40+qualityGap+tactical+promised;
    const value=clamp(Math.round(score),0,100);
    const label=value>=80?PLAYER_STATUS_LEVELS[0]:value>=65?PLAYER_STATUS_LEVELS[1]:value>=45?PLAYER_STATUS_LEVELS[2]:value>=25?PLAYER_STATUS_LEVELS[3]:PLAYER_STATUS_LEVELS[4];
    return {score:value,label,startRate,games,rank:rank+1,qualityGap,tactical:!!tactical};
  }
  // Estatuto efetivo: manual (definido pelo utilizador) tem prioridade sobre o cálculo automático.
  function effectivePlayerEstatuto(player,team){
    return player.estatutoManual || playerSquadImportance(player,team).label;
  }
  function setPlayerEstatuto(playerId, teamId, estatuto){
    const team=state.teams[teamId], player=team&&team.players.find(p=>p.id===playerId);
    if(!team||!player) return {ok:false,reason:"Jogador não encontrado."};
    if(!isUserControlledTeam(team)) return {ok:false,reason:"Só podes definir o estatuto dos jogadores do teu clube."};
    if(estatuto && !PLAYER_STATUS_LEVELS.includes(estatuto)) return {ok:false,reason:"Estatuto inválido."};
    player.estatutoManual = estatuto || null;
    return {ok:true};
  }
  function teamDivisionRank(team){ return PLAYOFF_DIVISION_CONFIG[team.divisaoAtual]?3:isSecondTierDivision(team.divisaoAtual)?2:1; }
  function transferCareerPenalty(player,fromTeam,toTeam,offer){
    if(!fromTeam||!toTeam||fromTeam.id===toTeam.id)return 1;
    const importance=playerSquadImportance(player,fromTeam);
    const divisionDrop=Math.max(0,teamDivisionRank(fromTeam)-teamDivisionRank(toTeam));
    const appealDrop=Math.max(0,clubAppeal(fromTeam)-clubAppeal(toTeam));
    const training=TREINO_APPEAL_SCORE[fromTeam.condicoesTreino]||50;
    const newTraining=TREINO_APPEAL_SCORE[toTeam.condicoesTreino]||50;
    const trainingDrop=Math.max(0,training-newTraining);
    let mult=1+divisionDrop*.32+appealDrop*.008+trainingDrop*.004;
    if(importance.score>=80)mult+=.18;else if(importance.score>=65)mult+=.10;
    if((player.satisfacao??70)>=65)mult+=.08;
    if(offer?.papel==="Titular"&&importance.score<65)mult-=.08;
    if(player.temperamento==="Ambicioso"&&divisionDrop)mult+=.15;
    return clamp(mult,1,2.25);
  }
  function recurringMonthlyRevenue(team){
    initClubFinance(team);const f=team.financeiro;
    const ticket=(f.mediaBilhetesPagos||0)*(f.precoBilhete||0)/Math.max(1,12/4);
    return Math.max(1,(f.receitaMensalPatrocinio||0)+(f.receitaMensalComercial||0)+(f.receitaMensalQuotas||0)+(f.receitaMensalApoioMunicipal||0)+ticket);
  }
  function wageRevenueRatio(team,monthlyBill){ return (monthlyBill==null?monthlyWageBill(team):monthlyBill)/recurringMonthlyRevenue(team); }
  function renewalFinancialDecision(team,player,newSalary){
    const current=player.contrato?.salarioMensal||0;
    const before=monthlyWageBill(team),after=before-current+newSalary;
    const beforeRatio=wageRevenueRatio(team,before),afterRatio=wageRevenueRatio(team,after);
    const importance=playerSquadImportance(player,team);
    const minimumProtection=(player.pos==="GR"?team.players.filter(p=>p.pos==="GR").length<=2:team.players.filter(p=>p.pos==="J").length<=8);
    let allowed=true,reason="";
    if(beforeRatio>1.15 && newSalary>=current && !minimumProtection && importance.score<80){allowed=false;reason="Em situação crítica, só são permitidas reduções salariais, renovações indispensáveis ou necessárias para manter o plantel mínimo.";}
    else if(beforeRatio>1 && afterRatio>beforeRatio+.005 && !minimumProtection && importance.score<80){allowed=false;reason="Esta renovação agravaria o rácio salarial acima de 100% das receitas recorrentes. Reduz a proposta ou liberta espaço salarial.";}
    return {allowed,reason,beforeRatio,afterRatio,importance,minimumProtection};
  }
  // Os "3 grandes" do hóquei português (pedido do utilizador, 2026-09-17: "transfrencias entre
  // os 3 grandes devem ser raras: só por muito dinheiro, tipo o dobro") — Benfica, FC Porto e
  // Sporting. Reutiliza os mesmos IDs já usados em DERBY_PAIRS para os clássicos entre eles.
  const BIG_THREE_IDS = new Set(["benfica","porto","sporting"]);
  const BIG_THREE_TRANSFER_CHANCE = 0.08;
  function isBigThreeTransfer(fromTeamId,toTeamId){ return BIG_THREE_IDS.has(fromTeamId)&&BIG_THREE_IDS.has(toTeamId)&&fromTeamId!==toTeamId; }
  function clubTransferDemand(player,fromTeam,toTeam){
    const years=contractYearsRemaining(player.contrato), base=playerMarketValue(player,fromTeam);
    const importanceInfo=playerSquadImportance(player,fromTeam);
    const importance=importanceInfo.score>=80?1.45:importanceInfo.score>=65?1.25:importanceInfo.score>=45?1.05:.85;
    const contractMult=years>1.5?1.2:years>.7?.8:.35;
    const potentialMult=player.age<=23&&player.potential>overall(player)?1.22:1;
    const unhappyMult=(player.satisfacao??70)<35?.82:1;
    // Escassez de guarda-redes (2026-09-16, reportado pelo utilizador: um clube com só 2 GR reais
    // aceitava vender um deles e, depois, a proposta de contrato ao jogador era sempre bloqueada
    // por "o clube precisa de manter pelo menos 2 guarda-redes reais" — um negócio que nunca
    // podia mesmo concluir-se. Em vez de bloquear, o clube passa a pedir bastante mais para deixar
    // sair o penúltimo guarda-redes real (fica com o mínimo estrutural de 1) — reflete o custo de
    // ter de correr atrás de um substituto de imediato — e canReleasePlayerFromTeam deixa de
    // travar essa venda quando o preço já reflete essa escassez (ver proposeContract, mais abaixo).
    const scarcityMult=(player.pos==="GR"&&realGoalkeeperCount(fromTeam)<=STRUCTURAL_MIN_GOALKEEPERS)?2.4:1;
    // "Só por muito dinheiro, tipo o dobro": um clássico entre os 3 grandes exige o dobro do valor
    // normal — não impede o negócio (o utilizador continua a poder tentar), só o torna caro ao
    // ponto de raramente valer a pena, tanto para o utilizador como para a IA (que nunca paga
    // acima do valor de mercado do jogador — ver tryPurchase).
    const bigThreeMult=(toTeam&&isBigThreeTransfer(fromTeam.id,toTeam.id))?2:1;
    // Mesma correção do piso por divisão aplicada acima a playerMarketValue: o pedido do clube
    // (fee) também não pode impor o mesmo mínimo do Placard a uma venda da 3ª Divisão.
    const demandDivMult = fromTeam ? (DIVISION_FINANCE_MULT[fromTeam.divisaoAtual] ?? 1) : 1;
    const demandFloor = Math.max(300, Math.round(2500*demandDivMult));
    return Math.max(demandFloor,Math.round(base*importance*contractMult*potentialMult*unhappyMult*scarcityMult*bigThreeMult*unlistedSalePremium(player,fromTeam)/500)*500);
  }
  // Jogador fora da lista de transferências (pedido do utilizador, 2026-10-05): um clube só vende
  // quem não tem à venda se a proposta for boa, acima do valor de mercado, com dispersão
  // (média +25%, desvio-padrão 12 pontos percentuais, entre +5% e +60%). O prémio é fixo para o
  // par jogador/época (semente determinística) para não mudar a cada ronda de negociação. Jogadores
  // listados, livres e do próprio utilizador (que decide por si) ficam sem prémio.
  const UNLISTED_PREMIUM_MEAN=1.25, UNLISTED_PREMIUM_SD=0.12, UNLISTED_PREMIUM_MIN=1.05, UNLISTED_PREMIUM_MAX=1.6;
  function unlistedSalePremium(player,fromTeam){
    if(!player||!fromTeam||player.transferListado||isUserControlledTeam(fromTeam)) return 1;
    const rng=makeSeededRng(`sale-premium:${state.gameSeed||0}:${state.season||0}:${player.id}`);
    const u1=Math.max(1e-9,rng()),u2=rng();
    const z=Math.sqrt(-2*Math.log(u1))*Math.cos(2*Math.PI*u2);
    return clamp(UNLISTED_PREMIUM_MEAN+z*UNLISTED_PREMIUM_SD,UNLISTED_PREMIUM_MIN,UNLISTED_PREMIUM_MAX);
  }
  // Negociação de fee entre clubes (2026-09-14, pedido do utilizador: "as equipas fazem propostas
  // e negoceiam... a resposta da parte do outro clube deve demorar 1 a 4 dias"): submeter uma
  // proposta já não a resolve na hora — só as validações duras (dados inválidos, equipa B, nuvem
  // europeia, orçamento) continuam síncronas, porque isso não é "o outro clube a pensar", é uma
  // rejeição imediata. Se passam, cria-se uma entrada "pendente" na própria sessão
  // (state.transferNegotiations[key]), com uma demora sorteada de 1-4 dias (determinística, via
  // makeSeededRng, para ser reproduzível), resolvida mais tarde por resolvePendingClubNegotiations
  // — mesmo ponto único de avanço de dia que já resolve scouting/investimentos/lesões/carreira do
  // treinador (dailyConditionRecovery, 09-fluxo-epoca.js). Aplica-se por igual a propostas do
  // utilizador e a propostas da IA (initiator implícito: quem quer que chame esta função),
  // incluindo negociações inteiramente entre dois clubes de IA — ver runAiToAiMarketPass.
  function negotiateWithClub(playerId,fromTeamId,toTeamId,amount){
    const fromTeam=state.teams[fromTeamId],toTeam=state.teams[toTeamId],player=fromTeam&&fromTeam.players.find(p=>p.id===playerId);
    if(!fromTeam||!toTeam||!player)return{outcome:"recusa",reason:"Jogador ou clube inválido."};
    if(fromTeam.equipaPrincipalId)return{outcome:"recusa",reason:"Jogadores de equipas B não podem ser abordados externamente."};
    // Guarda de segurança (verificação pedida pelo utilizador: "a IA nem o utilizador podem
    // comprar jogadores da nuvem"): os restantes filtros (isMarketPassiveTeam, refreshTransferMarket,
    // sourcePool) já impedem, na prática, que este caminho seja alcançado para clubes da nuvem
    // europeia — mas esta função é o ponto final onde qualquer negócio se fecha, pelo que fica
    // aqui uma última barreira explícita, independente de qualquer caminho de UI presente ou
    // futuro que possa vir a chamar esta função diretamente.
    if(fromTeam.nuvemEuropeia||toTeam.nuvemEuropeia)return{outcome:"recusa",reason:"Este clube nunca participa no mercado de transferências."};
    // Jogador intransferível (Lucas Ordóñez, nuvem — pedido do utilizador): nunca se contrata.
    if(player.intransferivel)return{outcome:"recusa",reason:"Este jogador não está disponível — não pode ser contratado por nenhum clube."};
    // Mesma barreira, agora também para as equipas virtuais das Seleções Nacionais (bug
    // reportado pelo utilizador, 2026-09-27: "a selecção de itália contratou um jogador por
    // empréstimo. as seleções não são clubes") — nunca compram nem vendem, só agrupam jogadores
    // de outros clubes durante a janela do torneio.
    if(fromTeam.selecaoNacional||toTeam.selecaoNacional)return{outcome:"recusa",reason:"Este clube nunca participa no mercado de transferências."};
    if(player.pendingTransferHold)return{outcome:"recusa",reason:"Este jogador já tem uma transferência acordada, à espera da próxima janela de inscrição."};
    if(playerTransferLimitReached(player))return{outcome:"recusa",reason:"Este jogador já foi transferido esta época — só pode voltar a mudar de clube na época seguinte."};
    if(!state.transferNegotiations)state.transferNegotiations={};
    const key=transferNegotiationKey(player,fromTeam,toTeam);
    const session=state.transferNegotiations[key]||{rondaClube:0,estado:"clube",exigencia:clubTransferDemand(player,fromTeam,toTeam)};
    // A verificação de proposta já pendente tem de vir antes de qualquer validação dos NOVOS
    // termos (ex.: orçamento) — enquanto se espera resposta a uma proposta, uma segunda proposta
    // (com um valor diferente, válido ou não) nunca deve "furar a fila": bloqueia sempre e devolve
    // a mesma data de resposta já agendada, tal como já acontece em proposeContract/proposeLoan.
    if(session.estado==="pendente")return{outcome:"pendente",reason:"Já há uma proposta à espera de resposta do clube.",responseDate:session.pendingResponseDate};
    initClubFinance(toTeam);
    if(amount>toTeam.financeiro.orcamentoTransferencias||amount>toTeam.financeiro.saldo)return{outcome:"recusa",reason:"O clube comprador não dispõe desse orçamento."};
    session.rondaClube++;
    const d=state.currentDate||new Date();
    const rng=makeSeededRng(`club-neg:${key}:${session.rondaClube}:${isoDate(d)}`);
    const dias=seededRnd(rng,1,4), responseDate=addDays(d,dias);
    session.estado="pendente";
    session.playerId=player.id;session.fromTeamId=fromTeam.id;session.toTeamId=toTeam.id;
    session.ultimaProposta=Math.max(0,Math.round(amount));
    session.pendingSubmittedDate=isoDate(d);session.pendingResponseDate=isoDate(responseDate);
    state.transferNegotiations[key]=session;
    // Correção (pedido do utilizador, 2026-09-16: "quando recebo uma proposta por um jogador
    // também deve aparecer um e-mail"): esta notícia tinha sempre o mesmo texto e o mesmo título,
    // "Proposta enviada ao clube", quer o utilizador fosse quem propunha (comprador, toTeam) quer
    // fosse quem RECEBIA a proposta por um jogador seu (vendedor, fromTeam — caso de uma compra
    // iniciada por um clube de IA, ver tryPurchase). Do lado do vendedor isso lia-se como "a minha
    // proposta foi enviada ao meu próprio clube", confuso e sem indicar sequer quem propôs. Passa a
    // haver duas mensagens distintas, cada uma a citar o clube do outro lado do negócio.
    // Correção (2026-09-17, apontada pelo utilizador): tal como no pedido à direção, esta
    // confirmação tem de vir do OUTRO clube (quem recebeu a proposta), não do próprio
    // utilizador — managerEmailAddress(toTeam.id) enviava a mensagem a partir do endereço do
    // próprio comprador. Passa a usar mercado@<clube-vendedor>.<tld>.
    if(isUserControlledTeam(toTeam))pushNews(d,`Recebemos a tua proposta de ${fmtMoney(session.ultimaProposta)} pelo passe de ${playerLinkHtml(fromTeam.id,player)}. Vamos analisar e responder até ${fmtDateShort(responseDate)}.`,"proposta","Proposta enviada ao clube",{sender:resolveNewsSender("proposta",{teamId:fromTeam.id})});
    else if(isUserControlledTeam(fromTeam))pushNews(d,`${teamLinkHtml(toTeam.id)} propôs ${fmtMoney(session.ultimaProposta)} pelo passe de ${playerLinkHtml(fromTeam.id,player)}. Resposta prevista para ${fmtDateShort(responseDate)}.`,"proposta","Nova proposta recebida",{autoAdvanceStop:true,teamId:toTeam.id});
    return{outcome:"pendente",responseDate:session.pendingResponseDate,session};
  }
  // Prazo de resposta de uma sessão de fee já acordada (pedido do utilizador 2026-09-14) — lê
  // session.prazoResposta se já existir (definido no momento em que o fee é aceite, ver
  // resolvePendingClubNegotiations) ou calcula-o e guarda-o agora, para sessões antigas
  // (gravadas antes desta funcionalidade existir) nunca ficarem sem prazo nem serem penalizadas
  // retroativamente com uma data já passada — usa a data atual como base nesse caso.
  function sessionRegistrationDeadline(session, date){
    if(!session.prazoResposta) session.prazoResposta=isoDate(registrationWindowCloseDate(date));
    return session.prazoResposta;
  }
  // Caduca acordos de fee cujo prazo de resposta (sessionRegistrationDeadline) já passou sem o
  // negócio se ter concretizado — pedido do utilizador 2026-09-14: "se um acordo é alcançado com
  // um clube, o jogador tem de responder até ao limite do prazo final das inscrições". Sem isto,
  // um fee acordado ficava pendente para sempre à espera de uma proposta de termos pessoais que
  // podia nunca chegar, acumulando entradas obsoletas na secção "Acordos com clubes à espera de
  // contrato" (Mercado). Chamado a partir de dailyConditionRecovery, logo a seguir a
  // resolvePendingClubNegotiations — por essa altura, qualquer negociação de termos pessoais para
  // o mesmo par (jogador, clubes) já foi decidida nesse mesmo dia ou antes (proposeContract nunca
  // agenda uma resposta depois deste prazo), por isso um acordo ainda "contrato" com o prazo
  // ultrapassado significa mesmo que ninguém propôs a tempo, ou que a proposta foi recusada e
  // não houve nova tentativa dentro do prazo.
  function resolveExpiredClubAgreements(date){
    if(!state.transferNegotiations)return;
    Object.keys(state.transferNegotiations).forEach(key=>{
      const session=state.transferNegotiations[key];
      if(!session||session.estado!=="contrato")return;
      const prazo=sessionRegistrationDeadline(session,date);
      if(new Date(date)<=new Date(prazo+"T00:00:00Z"))return;
      const fromTeam=state.teams[session.fromTeamId],toTeam=state.teams[session.toTeamId];
      const player=fromTeam&&fromTeam.players.find(p=>p.id===session.playerId);
      delete state.transferNegotiations[key];
      if(!fromTeam||!toTeam||!player)return; // negócio já concretizado entretanto — nada a noticiar
      if(isUserControlledTeam(fromTeam)||isUserControlledTeam(toTeam)){
        pushNews(date,`O acordo entre o ${teamLinkHtml(fromTeam.id)} e o ${teamLinkHtml(toTeam.id)} pelo passe de ${playerLinkHtml(fromTeam.id,player)} caducou — passou o prazo desta janela de inscrições sem o jogador ter respondido à proposta de contrato.`,"proposta","Acordo de transferência caducado",{autoAdvanceStop:true});
      }
    });
  }
  // Resolve as propostas de fee entre clubes cuja data de resposta já chegou — reavalia
  // clubTransferDemand no momento da resposta (não fixa as condições no momento do pedido, mesmo
  // princípio já usado em resolvePendingDirectionInvestments), e corre para TODAS as sessões,
  // envolvam ou não o utilizador — é assim que as negociações IA-contra-IA também avançam dia a
  // dia sem qualquer intervenção do utilizador.
  // Decisão do clube vendedor (pedido do utilizador, 2026-10-05): em vez de um bloqueio duro, o
  // clube pode RECUSAR uma proposta — sempre que isso fizer sentido para si — por três motivos:
  //  1) sem reposição: se a venda deixasse menos de SQUAD_REPLACEMENT_CHECK_OUTFIELD jogadores de
  //     campo (contando até 2 da equipa B prontos a subir), o clube faz contas (clubCanReplaceSale):
  //     só recusa se não tiver margem financeira/salarial para repor o jogador (livres ou listados);
  //  2) comprador rival direto (derbi, ou os dois no topo da mesma divisão): não vende ao preço de
  //     mercado — só por um prémio de 50% sobre a exigência (nos "3 grandes" a exigência já é o dobro);
  //  3) jogador imprescindível (estatuto máximo e um dos 3 melhores da sua posição): só por um
  //     prémio de 50% sobre a exigência.
  // Devolve null (aceita avaliar a proposta normalmente) ou {motivo, texto, exigencia?}. Usado na
  // resposta do clube (resolvePendingClubNegotiations) e como filtro de alvos da IA (tryPurchase).
  function clubSaleRefusal(player, fromTeam, toTeam, amount){
    if(!player||!fromTeam||!toTeam) return null;
    const demand=clubTransferDemand(player,fromTeam,toTeam);
    if(player.pos!=="GR"){
      const remainingJ=fromTeam.players.filter(p=>p.pos==="J"&&!p.__provisional&&p.id!==player.id).length;
      const bTeam=fromTeam.equipaBId?state.teams[fromTeam.equipaBId]:null;
      const bDepth=bTeam?Math.min(2,bTeam.players.filter(p=>p.pos==="J"&&!p.__provisional&&playerAvailableForMatch(p)).length):0;
      if(remainingJ+bDepth<SQUAD_REPLACEMENT_CHECK_OUTFIELD && !clubCanReplaceSale(player,fromTeam,amount)){
        return {motivo:"sem-reposicao",texto:`O ${fromTeam.name} não tem margem financeira para repor o jogador depois da venda.`};
      }
    }
    const premium=Math.round(demand*1.5/500)*500;
    if(amount<premium){
      if(clubsAreDirectRivals(fromTeam,toTeam) && !isBigThreeTransfer(fromTeam.id,toTeam.id)){
        return {motivo:"rival",texto:`O ${fromTeam.name} não vende ao preço de mercado a um rival direto como o ${toTeam.name}.`,exigencia:premium};
      }
      const imp=playerSquadImportance(player,fromTeam);
      if(imp.score>=80 && imp.rank<=3){
        return {motivo:"imprescindivel",texto:`${player.name} é considerado imprescindível no ${fromTeam.name}.`,exigencia:premium};
      }
    }
    return null;
  }
  // O clube vendedor faz contas: depois da venda, consegue repor um jogador de campo? Conta o
  // dinheiro que entra (saldo + valor da venda, menos a reserva de tesouraria) e a folga salarial
  // (massa salarial sem o jogador + o salário do substituto), e procura o substituto mais barato
  // entre os jogadores livres (sem fee) e os listados para transferência (fee = valor pedido).
  // Não há recusa fixa por número de jogadores: um clube só fica sem jogadores se quiser.
  function clubCanReplaceSale(player, fromTeam, amount){
    initClubFinance(fromTeam);
    const f=fromTeam.financeiro, freed=player.contrato?.salarioMensal||0;
    const wageBase=monthlyWageBill(fromTeam)-freed, wageCap=(f.limiteSalarial||Infinity)*0.9;
    const reserve=Math.max(monthlyWageBill(fromTeam)*3,financeConfig(fromTeam).homeCost*4,15000);
    const funds=(f.saldo||0)+(amount||0)-reserve;
    const wageOk=sal=>wageBase+sal<=wageCap;
    const free=(f.saldo||0)+(amount||0)>0?(state.freeAgents||[]).filter(p=>p.pos==="J"&&!p.__provisional):[];
    for(const p of free){
      const role=assignInitialRole(overall(p),p.age,p.potential,false);
      if(wageOk(freeAgentSalaryDemand(p,fromTeam,role))) return true;
    }
    if(funds<=0) return false;
    const budget=Math.min(funds,Math.max(f.orcamentoTransferencias||0,amount||0));
    for(const c of replacementMarketPool()){
      if(c.other.id===fromTeam.id) continue;
      if(c.value>budget) break; // lista ordenada por valor
      const p=c.player, salary=Math.round(Math.max(expectedSalary(p,fromTeam),p.contrato?.salarioMensal||0)*transferCareerPenalty(p,c.other,fromTeam));
      if(wageOk(salary)) return true;
    }
    return false;
  }
  // Mercado de reposição: os jogadores de campo mais baratos de todos os clubes ativos (listados
  // pelo valor pedido, os restantes pelo valor de mercado), ordenados por valor. Em cache por dia
  // para não recalcular valores a cada candidato da IA.
  let replacementPoolCache=null;
  function replacementMarketPool(){
    const key=isoDate(state.currentDate||new Date());
    if(replacementPoolCache&&replacementPoolCache.key===key&&replacementPoolCache.season===state.season) return replacementPoolCache.list;
    const list=[];
    Object.values(state.teams).forEach(other=>{
      if(isMarketPassiveTeam(other)) return;
      other.players.forEach(player=>{
        if(player.pos!=="J"||player.emprestimo||player.__provisional) return;
        const value=player.transferListado&&player.valorPedido?player.valorPedido:playerMarketValue(player,other);
        list.push({other,player,value});
      });
    });
    list.sort((a,b)=>a.value-b.value);
    replacementPoolCache={key,season:state.season,list:list.slice(0,80)};
    return replacementPoolCache.list;
  }
  // Rivais diretos: derbi conhecido, ou dois clubes da mesma divisão ambos no top 3 por reputação.
  function clubsAreDirectRivals(a,b){
    if(!a||!b||a.id===b.id) return false;
    if(isDerby(a.id,b.id)) return true;
    if(a.divisaoAtual!==b.divisaoAtual) return false;
    const top=Object.values(state.teams).filter(t=>t.divisaoAtual===a.divisaoAtual&&!t.equipaPrincipalId&&!t.nuvemEuropeia&&!t.selecaoNacional)
      .sort((x,y)=>(y.reputacaoClube||0)-(x.reputacaoClube||0)).slice(0,3).map(t=>t.id);
    return top.includes(a.id)&&top.includes(b.id);
  }
  function resolvePendingClubNegotiations(date){
    if(!state.transferNegotiations)return;
    Object.values(state.transferNegotiations).forEach(session=>{
      if(!session||session.estado!=="pendente")return;
      if(new Date(date)<new Date(session.pendingResponseDate))return;
      const fromTeam=state.teams[session.fromTeamId],toTeam=state.teams[session.toTeamId];
      const player=fromTeam&&fromTeam.players.find(p=>p.id===session.playerId);
      if(!fromTeam||!toTeam||!player){session.estado="clube";return;}
      const demand=clubTransferDemand(player,fromTeam,toTeam),amount=session.ultimaProposta||0;
      const involvesUser=isUserControlledTeam(fromTeam)||isUserControlledTeam(toTeam);
      session.exigencia=demand;
      const recusa=clubSaleRefusal(player,fromTeam,toTeam,amount);
      if(recusa){
        session.estado="clube"; session.recusaMotivo=recusa.motivo;
        if(recusa.exigencia) session.exigencia=Math.max(demand,recusa.exigencia);
        if(involvesUser) pushNews(date,`${teamLinkHtml(fromTeam.id)} recusou a proposta pelo passe de ${playerLinkHtml(fromTeam.id,player)}. ${recusa.texto}${recusa.exigencia?` Só admitiria falar a partir de ${fmtMoney(session.exigencia)}.`:""}`,"proposta","Proposta de transferência recusada",{autoAdvanceStop:true, teamId:fromTeam.id});
        return;
      }
      if(amount>=demand){
        session.estado="contrato";session.valorAcordado=amount;
        // Prazo de resposta (pedido do utilizador 2026-09-14: "se um acordo é alcançado com um
        // clube, o jogador tem de responder até ao limite do prazo final das inscrições") — sem
        // isto, o acordo de fee ficava pendente indefinidamente à espera de uma proposta de
        // termos pessoais. proposeContract usa este prazo para limitar a data de resposta do
        // jogador, e resolveExpiredClubAgreements (chamada a partir de dailyConditionRecovery)
        // caduca o acordo assim que o prazo passa sem o negócio se ter concretizado.
        session.prazoResposta=isoDate(registrationWindowCloseDate(date));
        if(involvesUser){
          // Pedido do utilizador (2026-09-14): a notícia de aceitação do fee deve poder abrir já
          // a página do contrato ao jogador — só faz sentido quando é O UTILIZADOR quem compra
          // (externalTransferPanelHtml, aberta via openPlayerModal, já mostra o formulário de
          // termos pessoais pré-preenchido e forçado a aberto assim que o fee está acordado). Do
          // lado do vendedor não há nada para o utilizador propor, por isso fica sem botão.
          const openBtn=isUserControlledTeam(toTeam)?contractNegOpenButtonHtml("transferencia",player,fromTeam,toTeam,"Propor contrato ao jogador →"):"";
          pushNews(date,`${teamLinkHtml(fromTeam.id)} aceitou ${fmtMoney(amount)} pelo passe de ${playerLinkHtml(fromTeam.id,player)}.${openBtn}`,"proposta","Acordo de transferência alcançado",{autoAdvanceStop:true, teamId:fromTeam.id});
        }
      } else if(amount>=demand*.72){
        session.exigencia=Math.max(demand,Math.round((demand+amount*.15)/500)*500);session.estado="clube";
        if(involvesUser)pushNews(date,`${teamLinkHtml(fromTeam.id)} respondeu com uma contraproposta de ${fmtMoney(session.exigencia)} pelo passe de ${playerLinkHtml(fromTeam.id,player)}.`,"proposta","Contraproposta do clube",{autoAdvanceStop:true, teamId:fromTeam.id});
      } else {
        session.estado="clube";
        if(involvesUser)pushNews(date,`${teamLinkHtml(fromTeam.id)} recusou a proposta pelo passe de ${playerLinkHtml(fromTeam.id,player)}.`,"proposta","Proposta de transferência recusada",{autoAdvanceStop:true, teamId:fromTeam.id});
      }
    });
  }
  function agreedTransferFee(player,fromTeam,toTeam){const n=state.transferNegotiations&&state.transferNegotiations[transferNegotiationKey(player,fromTeam,toTeam)];return n&&n.estado==="contrato"?n.valorAcordado:null;}
  function transferCostSummary(player,fromTeam,toTeam,salary,years){const fee=fromTeam?agreedTransferFee(player,fromTeam,toTeam)||clubTransferDemand(player,fromTeam,toTeam):0;const wages=Math.round((salary||0)*(years||1)*12);return{fee,wages,total:fee+wages};}

  // Exigência negocial do jogador. Nas renovações, o salário atual é uma referência
  // obrigatória: uma redução nunca é aceite automaticamente e gera contraproposta.
  // Prémio salarial por deslocação de país (2026-09-06, pedido do utilizador): "um jogador que
  // muda de país tem de ir receber mais, pois vai estar deslocado da sua família e isso paga-se."
  // Aplicado ao salário de MERCADO (nunca ao salário atual diretamente) para nunca compor a cada
  // renovação — um jogador já deslocado continua a exigir o prémio todos os anos, mas sempre
  // recalculado a partir do valor de mercado corrente, não multiplicado repetidamente em cima do
  // que já ganhava. Ver também isPlayerDisplaced/playerHousingCost (01-nucleo.js) para o custo de
  // alojamento, recorrente e à parte do salário.
  const DISPLACEMENT_WAGE_PREMIUM = 1.18;
  function contractDemand(player, fromTeam, toTeam, offer, kind){
    const marketSalary=expectedSalary(player, toTeam);
    const displaced = toTeam ? isPlayerDisplaced(player, toTeam) : false;
    const marketSalaryAdjusted = displaced ? marketSalary*DISPLACEMENT_WAGE_PREMIUM : marketSalary;
    const currentSalary=player.contrato?.salarioMensal||0;
    const isRenewal=kind==="renovacao" && fromTeam && toTeam && fromTeam.id===toTeam.id;
    const stage=careerStage(player);
    let demandedSalary;
    if(isRenewal){
      demandedSalary = Math.max(currentSalary*stage.salaryFloor,marketSalaryAdjusted*stage.salaryFloor);
    } else {
      // Correção: uma transferência nunca considerava o salário atual do jogador — só o
      // "valor de mercado" genérico, calculado a partir da sua própria qualidade, sem olhar
      // nenhuma vez para o clube de origem nem de destino. Isto permitia, por exemplo, comprar
      // uma estrela do Benfica para um clube muito mais pequeno, a ganhar MENOS do que já
      // ganhava — algo que não acontece na realidade, a não ser que o destino seja claramente
      // maior (aí o prestígio/ambição compensa uma eventual diferença salarial menor). Agora só
      // aceita ganhar menos do que já ganha se for uma subida clara de dimensão de clube.
      const appealDelta = (fromTeam && toTeam) ? clubAppeal(toTeam)-clubAppeal(fromTeam) : 0;
      demandedSalary = (currentSalary>0 && appealDelta<10) ? Math.max(marketSalaryAdjusted,currentSalary) : marketSalaryAdjusted;
      demandedSalary *= fromTeam ? transferCareerPenalty(player,fromTeam,toTeam,offer) : freeAgentCareerFit(player,toTeam,offer?.papel||"Rotacao").mult;
    }
    const ovr=overall(player), age=player.age||25;
    if(ovr>=16) demandedSalary*=1.08;
    if(age<=23 && player.potential>ovr) demandedSalary*=1.05;
    if((player.satisfacao??70)<40) demandedSalary*=1.08;
    demandedSalary*=persSalarioMult(player,toTeam,isRenewal);
    // Correção (calibração salarial por divisão): o piso de 450€ era universal — voltava a
    // impor o mesmo mínimo do Placard a um jogador da 3ª Divisão mesmo depois de
    // expectedSalary/divisionSalaryEstimate calcularem (correctamente) um valor bem mais baixo,
    // anulando ali mesmo toda a calibração acima. O piso passa a ser o da divisão do clube
    // pagador (toTeam) — 0€ na 2ª/3ª Divisão, 500€ no Placard — com 450€ como rede de segurança
    // só quando o clube pagador não é conhecido.
    const floor = toTeam ? divisionSalaryProfile(toTeam.divisaoAtual).base : 450;
    demandedSalary=Math.max(floor,Math.round(demandedSalary/50)*50);
    const importanceInfo=fromTeam?playerSquadImportance(player,fromTeam):{score:0};
    const preferredRole=(stage.id==="final"||stage.id==="declinio")?"Rotacao":(importanceInfo.score>=65||ovr>=15?"Titular":(age<=21&&player.potential-ovr>=3?"Desenvolvimento":"Rotacao"));
    const preferredYears=age>=32?1:2;
    return {salarioMensal:demandedSalary,papel:preferredRole,anos:preferredYears,currentSalary,isRenewal,stage,displaced};
  }
  function negotiationSessionKey(kind,player,fromTeam,toTeam){return [kind,player.id,fromTeam?.id||"livre",toTeam?.id||""].join("|");}
  // Botão "ir direto para a negociação" (pedido do utilizador, 2026-09-16): usado em várias
  // notícias do mercado — acordo de fee alcançado, contraproposta do jogador, lembrete de resposta
  // pendente — sempre com o mesmo destino final (a proposta de contrato ao jogador), mas cada tipo
  // de negociação chega lá de forma diferente. Transferência/pré-contrato: o jogador ainda está no
  // plantel do clube de origem (fromTeam) — abre a ficha dele aí, onde externalTransferPanelHtml já
  // mostra o formulário pré-preenchido e forçado a aberto. Renovação: é um jogador já nosso — abre
  // a ficha no próprio clube, marcando também state.uiNegotiationOpenId (feito no listener global,
  // ver data-renov) para o separador de contrato aparecer já aberto, tal como o botão "Renovar" já
  // faz manualmente. Jogador livre: não existe nenhum clube onde abrir uma ficha (está em
  // state.freeAgents) — vai direto à secção de jogadores livres do Mercado.
  function contractNegOpenButtonHtml(kind, player, fromTeam, toTeam, label){
    const text = label || "Ver negociação →";
    if(kind==="renovacao") return ` <button class="news-open-contract" data-team="${toTeam.id}" data-id="${player.id}" data-renov="1">${text}</button>`;
    if(kind==="livre-sign") return ` <button class="news-open-freeagent" data-id="${player.id}">${text}</button>`;
    if(fromTeam) return ` <button class="news-open-contract" data-team="${fromTeam.id}" data-id="${player.id}">${text}</button>`;
    return "";
  }
  function negotiationScore(player, fromTeam, toTeam, offer, kind){
    const demand=contractDemand(player,fromTeam,toTeam,offer,kind);
    // 0.4.9: na 3.ª divisão joga-se por gosto e muitos jogadores pedem 0 € (ou menos de 300 €): o
    // denominador mínimo de 300 € fazia com que uma proposta IGUAL ao pedido (ex.: 0 € para 0 €, ou
    // 150 € para 150 €) valesse só 0,35–0,5 do pedido e fosse sempre recusada. Agora cumprir o pedido
    // vale 1,0; só o Placard (pedidos >= 500 €) mantém exactamente a conta anterior.
    const dSal=demand.salarioMensal;
    const salaryRatio=dSal<=0 ? (offer.salarioMensal>0?clamp(1+offer.salarioMensal/600,1,1.8):1) : clamp(offer.salarioMensal/Math.max(50,dSal),0.35,1.8);
    const roleBonus=offer.papel===demand.papel?8:(demand.papel==="Titular"&&offer.papel!=="Titular"?-14:offer.papel==="Titular"?5:-4);
    const appealDelta=clubAppeal(toTeam)-clubAppeal(fromTeam||toTeam);
    const satisfaction=((player.satisfacao??70)-50)*0.12;
    const durationBonus=offer.anos===demand.anos?5:offer.anos>demand.anos?3:-4;
    let score=38+(salaryRatio-1)*78+roleBonus+appealDelta*0.35+satisfaction+durationBonus;
    if(demand.isRenewal) score+=4;
    score+=persNegociacaoMod(player,fromTeam,toTeam,demand.isRenewal);
    if(demand.isRenewal && offer.salarioMensal<demand.currentSalary*demand.stage.salaryFloor) score-=24;
    else if(demand.isRenewal && offer.salarioMensal<demand.currentSalary && ["declinio","final"].includes(demand.stage.id)) score+=4;
    return clamp(Math.round(score),0,100);
  }
  // Item 9 (pedido do utilizador): "deve haver momentos em que os jogadores nao querem renovar os
  // contratos principalmente se o treinador nao cumpre, com o seu estatuto contratual". Reutiliza
  // o mesmo mapeamento papel→utilização esperada já usado em applyRolePromiseSatisfaction, mas só
  // dispara para incumprimentos GRANDES (gap<-0.30) e só depois de uma amostra mínima de jogos
  // (gamesSoFar>=8), para não gerar falsos positivos logo no arranque da época.
  function playerRoleGrievanceSeverity(player){
    if(!player.contrato || !player.contrato.papel) return 0;
    const gamesSoFar = Math.max(1, state.currentRound||1);
    if(gamesSoFar < 8) return 0;
    const usageRatio = clamp((player.season.jogosTitular||0)/gamesSoFar, 0, 1);
    const expected = player.contrato.papel==="Titular" ? 0.6 : player.contrato.papel==="Rotacao" ? 0.25 : 0.05;
    const gap = usageRatio-expected;
    if(gap >= -0.30) return 0;
    return clamp((-gap-0.30)*2, 0, 1);
  }
  function evaluateContractOffer(player, fromTeam, toTeam, offer, kind){
    if(!state.contractNegotiations) state.contractNegotiations={};
    const key=negotiationSessionKey(kind,player,fromTeam,toTeam);
    const session=state.contractNegotiations[key]||{ronda:0,paciencia:3,lastOffer:null};
    session.ronda++;
    const demand=contractDemand(player,fromTeam,toTeam,offer,kind);
    // Numa renovação, na primeira ronda desta negociação, decide-se de uma vez por todas (e fica
    // guardado na sessão, para não voltar a ser sorteado a cada ronda seguinte) se o jogador guarda
    // mágoa suficiente do incumprimento do seu estatuto para recusar renovar de vez — seja qual for
    // a proposta salarial em cima da mesa.
    if(demand.isRenewal && toTeam){
      if(session.ronda===1 && session.roleGrievanceRefusal==null){
        const severity = playerRoleGrievanceSeverity(player);
        const rng = makeSeededRng(`${player.id}|${state.season}|${toTeam.id}|renov-magoa-papel`);
        session.roleGrievanceRefusal = severity>0 && seededRndFloat(rng,0,1) < severity*0.5;
        const persMotivo = persRecusaRenovacao(player,toTeam);
        if(persMotivo){ session.roleGrievanceRefusal = true; session.persMotivo = persMotivo; }
      }
      if(session.roleGrievanceRefusal){
        state.contractNegotiations[key]=session;
        if(session.persMotivo) return {outcome:"recusa",score:0,reason:persTextoRecusa(player,session.persMotivo)};
        return {outcome:"recusa",score:0,reason:`O jogador está desiludido — o treinador prometeu-lhe o estatuto de ${ROLE_LABELS[player.contrato.papel]||player.contrato.papel} e não cumpriu — não quer continuar aqui.`};
      }
    }
    const score=negotiationScore(player,fromTeam,toTeam,offer,kind);
    const acceptedCounter=!!session.counter && offer.salarioMensal>=session.counter.salarioMensal && offer.anos>=session.counter.anos && offer.papel===session.counter.papel;
    if(acceptedCounter){ delete state.contractNegotiations[key]; return {outcome:"aceita",score:100}; }
    const severeLowball=offer.salarioMensal<demand.salarioMensal*0.7;
    if(severeLowball){
      session.paciencia--;
      player.satisfacao=clamp((player.satisfacao??70)-2,0,100);
    }
    session.lastOffer={...offer}; state.contractNegotiations[key]=session;
    // Correção: as recusas eram sempre genéricas ("proposta demasiado baixa"), mesmo quando a
    // verdadeira razão é o jogador não querer descer de patamar (fromTeam claramente maior que
    // toTeam) — o utilizador só via um valor difícil de bater, sem perceber que o entrave é a
    // relutância do jogador em sair de um clube grande para um mais pequeno, não uma exigência
    // salarial qualquer. A mensagem passa a dizer isso quando for esse o caso.
    const isDownstep = !demand.isRenewal && fromTeam && toTeam && fromTeam.id!==toTeam.id && (clubAppeal(fromTeam)-clubAppeal(toTeam))>DOWNSTEP_APPEAL_NOTE_THRESHOLD;
    if(session.paciencia<=0){
      session.counter=null;session.counterDate=null;session.counterReminderSent=false;
      return {outcome:"recusa",score,reason:isDownstep?"O jogador encerrou as negociações — não está disposto a descer para um clube desta dimensão por um valor tão abaixo do que exige.":"O jogador encerrou as negociações depois de propostas muito abaixo das suas exigências."};
    }
    const payCut=demand.isRenewal && offer.salarioMensal<demand.currentSalary*demand.stage.salaryFloor;
    const roleBelow=demand.papel==="Titular" && offer.papel!=="Titular";
    if(!payCut && !roleBelow && score>=66){ delete state.contractNegotiations[key]; return {outcome:"aceita",score}; }
    if(score>=28 || payCut || roleBelow){
      // Correção (2026-09-16, reportado pelo utilizador: "chega até a fazer contrapropostas de
      // menor valor"): quando o entrave era o papel ou a duração (roleBelow/score baixo por outro
      // motivo que não o salário), a contraproposta ignorava por completo o que já estava em cima
      // da mesa e pedia sempre exatamente `demand.salarioMensal` — que pode ser MENOR do que a
      // proposta que o utilizador já tinha feito. Um jogador nunca contraproõe por menos do que já
      // lhe foi oferecido — a contraproposta passa a nunca descer abaixo da própria oferta.
      const counterSalary=Math.max(demand.salarioMensal, offer.salarioMensal, payCut?Math.round(demand.currentSalary*demand.stage.salaryFloor/50)*50:0);
      session.counter={salarioMensal:counterSalary,anos:demand.anos,papel:demand.papel};
      // Lembrete "jogador à espera de resposta" (pedido do utilizador, 2026-09-16): guarda a data
      // desta contraproposta e um sinalizador de "ainda não avisado" — resolvePendingContractCounterReminders
      // (chamada a partir de dailyConditionRecovery) usa estes dois campos para publicar, uma única
      // vez, uma notícia a lembrar que o jogador continua à espera, 3 dias depois, caso o
      // utilizador ainda não tenha respondido com uma nova proposta.
      session.counterDate=isoDate(state.currentDate||new Date());
      session.counterReminderSent=false;
      state.contractNegotiations[key]=session;
      return {outcome:"contraproposta",score,counter:session.counter,ronda:session.ronda,paciencia:session.paciencia};
    }
    session.counter=null;session.counterDate=null;session.counterReminderSent=false;
    return {outcome:"recusa",score,reason:isDownstep?"O jogador só aceita descer para um clube desta dimensão com uma compensação salarial clara — a proposta ainda está longe disso.":"A proposta está demasiado longe das exigências do jogador."};
  }
  // Prioridade de renovação da IA (0-100), combinando OVR, utilização, média de notas,
  // titularidade, potencial, idade, moral, satisfação, massa salarial e situação financeira.
  function renewalPriorityScore(player, team){
    const ovr=overall(player);
    const gamesSoFar=Math.max(1,state.currentRound||state.fixtures.length||1);
    const ssDec=seasonStatsForDecision(player);
    const usage=clamp((ssDec.jogos||0)/gamesSoFar,0,1);
    // Calibração (encontrada na mesma simulação longa): o termo de utilização penalizava o
    // valor absoluto de jogos, independentemente do papel do jogador no plantel — um suplente
    // de Rotação a cumprir exatamente o que se espera dele (ex.: jogar ~30% dos jogos) recebia
    // a mesma penalização pesada que um titular falhado, só por ter menos minutos em termos
    // absolutos. Passa a comparar a utilização real com a expectativa do seu próprio papel
    // contratual (Titular/Rotação/Desenvolvimento) — só penaliza (ou recompensa) o desvio face
    // ao que foi combinado, não o valor absoluto de jogos.
    const papel = player.contrato ? player.contrato.papel : "Rotacao";
    const expectedUsage = papel==="Titular" ? 0.65 : papel==="Desenvolvimento" ? 0.10 : 0.30;
    const usageFactor = clamp((usage-expectedUsage)*20, -12, 14);
    const notaMedia=ssDec.notas&&ssDec.notas.length?avg(ssDec.notas):6;
    const importanceInfo=playerSquadImportance(player,team);
    const starter=importanceInfo.score>=80?15:importanceInfo.score>=65?11:importanceInfo.score>=45?5:0;
    const potentialGap=clamp((player.potential-ovr)*1.5,-6,12);
    // Calibração (encontrada numa simulação longa de 12 épocas): a curva original penalizava
    // fortemente a partir dos 33 anos (-14), o que já "reformava" a maioria dos veteranos por
    // via da não-renovação de contrato antes de o sistema de reformas (avaliação de contexto,
    // não só idade) ter oportunidade de decidir quando cada um deve mesmo sair. Dos 30 aos 33
    // anos a decisão passa a depender sobretudo do desempenho/utilização (que já pesam no
    // score); a idade só volta a pesar com força depois dos 37.
    const ageFactor=player.age<=23?10:player.age<=29?4:player.age<=33?-2:player.age<=36?-8:-14;
    const moralFactor=(((player.moral||60)+(player.satisfacao||60))/2-50)*0.15;
    initClubFinance(team);
    const wageShare=team.financeiro.limiteSalarial?(player.contrato.salarioMensal/team.financeiro.limiteSalarial)*100:10;
    const wagePenalty=wageShare>18?-(wageShare-18)*0.6:0;
    const financeFactor=team.financeiro.saldo<0?-8:0;
    const score=ovr*3+usageFactor+(notaMedia-6)*6+starter+potentialGap+ageFactor+moralFactor+wagePenalty+financeFactor;
    return clamp(Math.round(score),0,100);
  }
  function renewalTier(score){ return score>=80?"prioritaria":score>=60?"tentar":score>=40?"seletiva":"deixar-terminar"; }
  function renewalTierLabel(tier){ return {prioritaria:"Prioritária",tentar:"Tentar renovar",seletiva:"Seletiva","deixar-terminar":"Deixar terminar"}[tier]||tier; }

  // ---- Negociação interativa (utilizador) ----
  // Garante que uma equipa nunca fica abaixo do mínimo de plantel (1 GR, 5 jogadores de campo)
  // ao perder um jogador por transferência direta — a mesma regra já aplicada em dispensas e
  // no mercado interno A/B, agora também para transferências imediatas durante o defeso.
  // opts.allowScarcitySale (2026-09-16, pedido do utilizador): usado só pela venda de um GR já
  // negociada e paga (proposeContract, kind "transferencia") — o preço já pago pelo comprador
  // (clubTransferDemand já cobra um prémio de escassez, acima) é o que torna o negócio possível,
  // por isso o piso desce de 2 para 1 real guarda-redes (nunca a zero: o plantel tem sempre de
  // ficar com pelo menos um). As restantes chamadas (seleção de alvos de recrutamento da IA,
  // dispensas sem qualquer compensação) mantêm o piso normal de 2, para não criarem escassez a
  // custo zero.
  function canReleasePlayerFromTeam(team, player, opts){
    if(player.emprestimo) return {ok:false,reason:"Um jogador emprestado não pode ser vendido, dispensado ou novamente emprestado pelo clube de destino."};
    const remaining=team.players.filter(p=>p.id!==player.id);
    const grFloor=(opts&&opts.allowScarcitySale)?1:STRUCTURAL_MIN_GOALKEEPERS;
    if(player.pos==="GR" && remaining.filter(p=>p.pos==="GR"&&!p.__provisional).length<grFloor) return {ok:false,reason:`O clube precisa de manter pelo menos ${grFloor} guarda-redes reais.`};
    if(player.pos!=="GR" && remaining.filter(p=>p.pos==="J").length<STRUCTURAL_MIN_OUTFIELD) return {ok:false,reason:`O clube ficaria com menos de ${STRUCTURAL_MIN_OUTFIELD} jogadores de campo.`};
    return {ok:true};
  }
  // Negociação de termos pessoais (2026-09-14, pedido do utilizador): tal como negotiateWithClub,
  // as validações duras (dados inválidos, bloqueios financeiros/de crise, elegibilidade,
  // acordo de fee em falta) continuam síncronas — o jogador "pensar" só começa depois de a
  // proposta ser viável. Cobre transferência, pré-contrato, jogador livre e renovação por igual
  // (renovações também passam a ter demora, por decisão do utilizador nesta ronda de perguntas).
  function proposeContract(kind, playerId, fromTeamId, toTeamId, offer){
    const toTeam=state.teams[toTeamId];
    const fromTeam=fromTeamId?state.teams[fromTeamId]:null;
    const d=state.currentDate||new Date();
    // Correção (2026-09-14, encontrada ao converter o mercado IA-contra-IA para negociação com
    // demora): um "livre-sign" nunca tinha fromTeam (o jogador não está no plantel de NINGUÉM,
    // está em state.freeAgents) — procurar só em toTeam.players nunca o encontrava, e a proposta
    // falhava sempre com "Jogador ou clube inválido." Isto já afetava (silenciosamente, sem
    // qualquer teste a exercitar este caminho específico) a assinatura de jogadores livres pelo
    // próprio utilizador, não é uma regressão desta conversão.
    const player=(fromTeam||toTeam).players.find(p=>p.id===playerId) || (!fromTeam && (state.freeAgents||[]).find(p=>p.id===playerId));
    if(!player||!toTeam) return {outcome:"recusa",reason:"Jogador ou clube inválido."};const b=crisisSpendingBlock(toTeam,kind==="transferencia"?"compra":"aumento-salarial",offer&&offer.salarioMensal,player);if(b)return{outcome:"recusa",reason:b};
    if(kind==="renovacao" && player.emprestimo) return {outcome:"recusa",reason:"Este jogador está emprestado — o contrato pertence ao clube de origem, não pode ser renovado pelo clube de destino."};
    if(player.intransferivel) return {outcome:"recusa",reason:"Este jogador não está disponível — não pode ser contratado por nenhum clube."};
    if(player.pendingTransferHold) return {outcome:"recusa",reason:"Este jogador já tem uma transferência acordada, à espera da próxima janela de inscrição."};
    // Limite de 1 transferência por época (ver playerTransferLimitReached, acima): cobre
    // transferência definitiva e assinatura de jogador livre, que criam uma inscrição imediata
    // (nesta época). Um pré-contrato só regista o jogador na PRÓXIMA época — verifica-se contra
    // essa época, não a atual, para não bloquear por engano um jogador que ainda não usou a
    // inscrição da época seguinte. Renovação nunca muda de clube, fica sempre de fora.
    if((kind==="transferencia"||kind==="livre-sign") && playerTransferLimitReached(player)) return {outcome:"recusa",reason:"Este jogador já foi transferido esta época — só pode voltar a mudar de clube na época seguinte."};
    if(kind==="pre-contrato" && playerTransferLimitReached(player, state.season+1)) return {outcome:"recusa",reason:"Este jogador já tem uma mudança de clube agendada para a próxima época."};
    if(kind==="transferencia" && fromTeam){
      const buyerState=financialState(toTeam);
      if(buyerState.level>=3) return {outcome:"recusa",reason:"A direção bloqueou compras enquanto o clube estiver em dificuldade financeira grave. Usa a equipa B, jogadores livres ou empréstimos."};
      const check=canReleasePlayerFromTeam(fromTeam,player,{allowScarcitySale:true});
      if(!check.ok) return {outcome:"recusa",reason:check.reason};
      if(fromTeam.equipaPrincipalId) return {outcome:"recusa",reason:"Jogadores de equipas B não podem ser abordados externamente."};
      // Correção: a compra direta pelo utilizador nunca verificava a diferença de dimensão
      // entre os clubes — a mesma regra que já bloqueia empréstimos/compras demasiado
      // desproporcionados entre clubes IA nunca se aplicava quando era o próprio utilizador a
      // comprar. Permitia, por exemplo, comprar uma estrela do Benfica para um clube muito mais
      // pequeno, sem qualquer travão de realismo.
      if(purchaseGapBlocked(fromTeam,toTeam)) return {outcome:"recusa",reason:"A diferença de dimensão entre os clubes é grande demais para esta transferência fazer sentido."};
      if(agreedTransferFee(player,fromTeam,toTeam)==null) return {outcome:"recusa",reason:"É necessário chegar primeiro a acordo com o clube vendedor."};
      // Prazo de resposta (pedido do utilizador 2026-09-14: "se um acordo é alcançado com um
      // clube, o jogador tem de responder até ao limite do prazo final das inscrições") — se o
      // prazo já passou, o acordo de fee caducou (resolveExpiredClubAgreements já o teria
      // removido no avanço de dia seguinte, mas verifica-se aqui também por segurança).
      const feeSession=state.transferNegotiations&&state.transferNegotiations[transferNegotiationKey(player,fromTeam,toTeam)];
      if(feeSession){
        const prazo=sessionRegistrationDeadline(feeSession,d);
        if(prazo && new Date(d)>new Date(prazo+"T00:00:00Z")) return {outcome:"recusa",reason:"O prazo para o jogador responder, dentro desta janela de inscrições, já terminou — o acordo com o clube vendedor caducou."};
      }
    }
    if(!fromTeam && kind!=="renovacao"){
      const fit=freeAgentCareerFit(player,toTeam,offer?.papel||"Rotacao");
      if(!fit.ok){
        if(player.freeAgentContext){const list=player.freeAgentContext.rejectedTeams||[];if(!list.includes(toTeam.id))list.push(toTeam.id);player.freeAgentContext.rejectedTeams=list.slice(-12);}
        return {outcome:"recusa",reason:fit.drop>=2?"O jogador não aceita descer duas divisões nesta fase da carreira sem um período maior no mercado.":"O projeto desportivo, as condições e o papel oferecido não compensam o retrocesso de carreira."};
      }
    }
    initClubFinance(toTeam);
    const wageAfter=monthlyWageBill(toTeam)-(kind==="renovacao"?player.contrato.salarioMensal:0)+offer.salarioMensal;
    if(kind==="renovacao"){
      const financial=renewalFinancialDecision(toTeam,player,offer.salarioMensal);
      if(!financial.allowed) return {outcome:"recusa",reason:financial.reason};
    } else if(kind!=="pre-contrato" && wageAfter>toTeam.financeiro.limiteSalarial){
      return {outcome:"recusa",reason:"A proposta excede o limite salarial do clube."};
    }
    if(!state.contractNegotiations)state.contractNegotiations={};
    const key=negotiationSessionKey(kind,player,fromTeam,toTeam);
    const existing=state.contractNegotiations[key];
    if(existing&&existing.aguardaResposta)return{outcome:"pendente",reason:"Já há uma proposta à espera de resposta do jogador.",responseDate:existing.pendingResponseDate,session:existing};
    const session=existing||{ronda:0,paciencia:3,lastOffer:null};
    const rng=makeSeededRng(`contract-neg:${key}:${session.ronda}:${isoDate(d)}`);
    const dias=seededRnd(rng,1,4);
    let responseDate=addDays(d,dias);
    // Limita a resposta ao prazo da janela de inscrição quando há um fee acordado (só se aplica
    // a transferências entre clubes — pré-contrato, livre e renovação não têm fee nem esta
    // pressão de tempo).
    if(kind==="transferencia" && fromTeam){
      const feeSession=state.transferNegotiations&&state.transferNegotiations[transferNegotiationKey(player,fromTeam,toTeam)];
      const prazo=feeSession?sessionRegistrationDeadline(feeSession,d):null;
      if(prazo){
        const prazoData=new Date(prazo+"T00:00:00Z");
        if(responseDate>prazoData) responseDate=prazoData;
      }
    }
    session.aguardaResposta=true;
    session.kind=kind;session.playerId=player.id;session.fromTeamId=fromTeam?fromTeam.id:null;session.toTeamId=toTeam.id;
    session.pendingOffer={...offer};
    session.pendingSubmittedDate=isoDate(d);session.pendingResponseDate=isoDate(responseDate);
    state.contractNegotiations[key]=session;
    if(isUserControlledTeam(toTeam)||(fromTeam&&isUserControlledTeam(fromTeam)))pushNews(d,`Proposta de contrato enviada a ${fromTeam?playerLinkHtml(fromTeam.id,player):playerNameHtml(player)}. Resposta prevista para ${fmtDateShort(responseDate)}.`,"proposta","Proposta enviada ao jogador",{sender:isUserControlledTeam(toTeam)?managerEmailAddress(toTeam.id):undefined});
    return {outcome:"pendente",responseDate:session.pendingResponseDate,session};
  }
  // Resolve as propostas de termos pessoais cuja data de resposta já chegou — chama a mesma
  // evaluateContractOffer que já existia (accept/contraproposta/recusa, ronda/paciência
  // preservadas na sessão), só que agora só corre quando a demora de 1-4 dias já passou.
  function resolvePendingContractNegotiations(date){
    if(!state.contractNegotiations)return;
    Object.keys(state.contractNegotiations).forEach(key=>{
      const session=state.contractNegotiations[key];
      if(!session||!session.aguardaResposta)return;
      if(new Date(date)<new Date(session.pendingResponseDate))return;
      session.aguardaResposta=false;
      const toTeam=state.teams[session.toTeamId];
      const fromTeam=session.fromTeamId?state.teams[session.fromTeamId]:null;
      // Mesma correção do "livre-sign" aplicada em proposeContract: sem fromTeam, o jogador está
      // em state.freeAgents, não no plantel de toTeam.
      const player=toTeam&&((fromTeam||toTeam).players.find(p=>p.id===session.playerId) || (!fromTeam && (state.freeAgents||[]).find(p=>p.id===session.playerId)));
      if(!toTeam||!player)return;
      const offer=session.pendingOffer,kind=session.kind;
      const involvesUser=isUserControlledTeam(toTeam)||(fromTeam&&isUserControlledTeam(fromTeam));
      // Correção (2026-10-16): o acordo de fee entre clubes pode caducar no mesmo dia em que o jogador
      // responde (resolveExpiredClubAgreements corre antes) — a transferência concluía-se então com
      // fee 0 (vendedor sem receber, comprador sem pagar). Sem acordo de fee válido, não há negócio.
      if(kind==="transferencia"&&fromTeam&&agreedTransferFee(player,fromTeam,toTeam)==null){
        delete state.contractNegotiations[key];
        if(involvesUser) pushNews(date,`A transferência de ${playerLinkHtml(fromTeam.id,player)} para o ${teamLinkHtml(toTeam.id)} não se concretizou: o acordo entre clubes caducou antes da resposta do jogador.`,"mercado",null,{autoAdvanceStop:true});
        return;
      }
      const result=evaluateContractOffer(player,fromTeam,toTeam,offer,kind);
      if(result.outcome==="aceita"){
        // Pedido do utilizador (2026-09-14): tem de haver sempre uma notícia explícita e dedicada
        // no momento em que o JOGADOR aceita os termos pessoais — distinta da notícia de
        // conclusão do negócio que applyAcceptedOffer já publica a seguir (que descreve o
        // movimento em si: "muda-se para", "assinou pré-contrato", etiqueta TRF, renovação). Uma
        // não substitui a outra.
        if(involvesUser){
          // Correção: a mensagem original não mencionava nenhum clube — pushNews/newsIsFromUserDivision
          // filtra silenciosamente qualquer notícia de mercado que não cite o nome de um clube da
          // divisão do utilizador, por isso a notícia nunca chegava a aparecer. Passa a incluir
          // sempre o clube de destino (toTeam), tal como todas as outras notícias de mercado.
          const kindLabel=kind==="renovacao"?"a renovação de contrato com o":kind==="pre-contrato"?"o pré-contrato com o":kind==="livre-sign"?"a proposta de contrato do":"a proposta de transferência do";
          pushNews(date,`${fromTeam?playerLinkHtml(fromTeam.id,player):playerNameHtml(player)} aceitou ${kindLabel} ${teamLinkHtml(toTeam.id)}: ${fmtMoney(offer.salarioMensal)}/mês, ${offer.anos} ano(s), papel ${ROLE_LABELS[offer.papel]||offer.papel}.`,"proposta","Termos pessoais aceites pelo jogador",{autoAdvanceStop:true});
        }
        applyAcceptedOffer(kind,player,fromTeam,toTeam,offer);
        // Mercado IA-contra-IA (2026-09-14): a ficha de recrutamento (aiRecruitmentLedger) só se
        // atualiza agora que o negócio realmente se fechou — não no momento em que a proposta foi
        // enviada (tryPurchase/tryFreeAgent, mais acima), que pode ter sido dias antes.
        if(session.aiMeta && !isUserControlledTeam(toTeam)){
          const fee=fromTeam?(agreedTransferFee(player,fromTeam,toTeam)||0):0;
          const total=aiTotalRecruitmentCost(player,toTeam,session.aiMeta.type,fee,offer.salarioMensal);
          aiRegisterRecruitment(toTeam,player,session.aiMeta.type,total);
        }
      } else if(involvesUser){
        // Correção (2026-09-14, reportado pelo utilizador: "nao estao a aparecer noticias de
        // aceitação ou rejeição... nem dos jogadores"): tal como a notícia de aceitação dos
        // termos pessoais (corrigida mais acima), estas duas mensagens nunca mencionavam nenhum
        // clube — playerNameHtml só mostra o nome do jogador, não o do clube. pushNews/
        // newsIsFromUserDivision filtra silenciosamente qualquer notícia de mercado que não cite
        // o nome de um clube da divisão do utilizador, por isso estas notícias NUNCA chegavam a
        // aparecer desde que este sistema de negociação com demora foi introduzido — confirmado
        // por teste dedicado (0 notícias publicadas apesar de a negociação ter sido corretamente
        // resolvida). Passa a incluir sempre o clube proponente (toTeam).
        if(result.outcome==="contraproposta"){
          // Pedido do utilizador (2026-09-16): a notícia de contraproposta tem de dar para ir
          // direto para a negociação do contrato, tal como já acontece na notícia de acordo de
          // fee alcançado — só faz sentido quando é o utilizador quem controla toTeam (é quem
          // enviou a proposta original e quem pode responder com uma nova).
          const openBtn=isUserControlledTeam(toTeam)?contractNegOpenButtonHtml(kind,player,fromTeam,toTeam,"Responder à contraproposta →"):"";
          pushNews(date,`${fromTeam?playerLinkHtml(fromTeam.id,player):playerNameHtml(player)} respondeu à proposta do ${teamLinkHtml(toTeam.id)} com uma contraproposta: ${fmtMoney(result.counter.salarioMensal)}/mês, ${result.counter.anos} ano(s), papel ${ROLE_LABELS[result.counter.papel]||result.counter.papel}.${openBtn}`,"proposta","Contraproposta do jogador",{autoAdvanceStop:true});
        }
        else pushNews(date,`${fromTeam?playerLinkHtml(fromTeam.id,player):playerNameHtml(player)} recusou a proposta do ${teamLinkHtml(toTeam.id)}: ${result.reason}`,"proposta","Proposta recusada pelo jogador",{autoAdvanceStop:true});
      }
    });
  }
  // Lembrete "jogador à espera de resposta" (pedido do utilizador, 2026-09-16: "depois de 3 dias
  // sem responder à contraproposta deve sair um e-mail a dizer que o jogador está à espera de uma
  // resposta") — corre a seguir a resolvePendingContractNegotiations, no mesmo ponto único de
  // avanço de dia. Só examina sessões com uma contraproposta ainda por responder
  // (session.counter, marcado em evaluateContractOffer) e que ainda não geraram lembrete — cada
  // sessão só é lembrada uma vez; uma nova proposta do utilizador (proposeContract) substitui
  // session.counter por um novo pendingOffer/aguardaResposta, o que naturalmente "consome" o
  // lembrete sem precisar de o limpar aqui.
  function resolvePendingContractCounterReminders(date){
    if(!state.contractNegotiations)return;
    Object.keys(state.contractNegotiations).forEach(key=>{
      const session=state.contractNegotiations[key];
      if(!session||!session.counter||session.counterReminderSent||!session.counterDate)return;
      if(session.aguardaResposta)return; // já há uma nova proposta em curso — nada a lembrar
      if(new Date(date)<addDays(new Date(session.counterDate+"T00:00:00Z"),3))return;
      session.counterReminderSent=true;
      const toTeam=state.teams[session.toTeamId];
      const fromTeam=session.fromTeamId?state.teams[session.fromTeamId]:null;
      const player=toTeam&&((fromTeam||toTeam).players.find(p=>p.id===session.playerId) || (!fromTeam && (state.freeAgents||[]).find(p=>p.id===session.playerId)));
      if(!toTeam||!player)return;
      if(!isUserControlledTeam(toTeam))return; // só interessa ao utilizador quando é ele quem tem de responder
      const openBtn=contractNegOpenButtonHtml(session.kind,player,fromTeam,toTeam,"Responder à contraproposta →");
      // Nota (mesma correção já aplicada às restantes notícias de mercado nesta função): o texto
      // tem de citar sempre o nome de um clube — pushNews/newsIsFromUserDivision filtra em
      // silêncio qualquer notícia de mercado que não o faça.
      pushNews(date,`${fromTeam?playerLinkHtml(fromTeam.id,player):playerNameHtml(player)} continua à espera de uma resposta do ${teamLinkHtml(toTeam.id)} à sua contraproposta de ${fmtMoney(session.counter.salarioMensal)}/mês.${openBtn}`,"proposta","Jogador à espera de resposta",{autoAdvanceStop:true});
    });
  }
  function applyAcceptedOffer(kind, player, fromTeam, toTeam, offer, opts){
    opts=opts||{};
    const anos=offer.anos||1;
    // Avanço automático de vários dias (2026-09-16): esta função é partilhada por negócios do
    // utilizador e negócios inteiramente entre clubes de IA — só os primeiros devem interromper o
    // avanço automático, por isso calcula-se aqui, uma única vez, em vez de confiar em quem chama.
    const involvesUser=(fromTeam&&isUserControlledTeam(fromTeam))||isUserControlledTeam(toTeam);
    if(kind==="renovacao"){
      player.contrato=generateContract(overall(player),player.age,{anos,salarioMensal:offer.salarioMensal,papel:offer.papel,dataInicio:isoDate(state.currentDate||new Date())});
      player.__manualResolutionSeason=state.season;
      player.moral=clamp((player.moral||60)+6,0,100); player.satisfacao=clamp((player.satisfacao||60)+8,0,100);
      pushNews(state.currentDate,`${player.name} renovou contrato com o ${teamLinkHtml(toTeam.id)} até ${player.contrato.dataFim.slice(0,4)}.`,"mercado",null,{autoAdvanceStop:involvesUser});
    } else if(kind==="pre-contrato"){
      player.preContrato={destinoId:toTeam.id,salarioMensal:offer.salarioMensal,anos,papel:offer.papel,dataAcordo:isoDate(state.currentDate||new Date())};
      player.__manualResolutionSeason=state.season;
      pushNews(state.currentDate,`${player.name} (${fromTeam?teamLinkHtml(fromTeam.id):"—"}) assinou um pré-contrato com o ${teamLinkHtml(toTeam.id)}, válido a partir da próxima época.`,"mercado",null,{autoAdvanceStop:involvesUser});
    } else if(fromTeam && !opts.skipWindowCheck && !registrationWindowOpenFor(state.currentDate||new Date())){
      // Etiqueta TRF (RGHP Art.15º, pedido do utilizador 2026-09-14): acordo de transferência
      // definitiva fechado fora de uma janela real de inscrição — o jogador continua a jogar
      // pelo clube atual até a próxima janela abrir (resolvePendingTransferHolds,
      // 09-fluxo-epoca.js, ativa o negócio automaticamente nesse dia). Não se aplica a
      // pré-contratos/renovações/jogadores livres, que já têm o seu próprio mecanismo de
      // ativação diferida ou não têm clube de origem a "prender" o jogador.
      const nextWindow=nextRegistrationWindowOpenDate(state.currentDate||new Date());
      player.pendingTransferHold={
        toTeamId:toTeam.id, salarioMensal:offer.salarioMensal, anos, papel:offer.papel,
        agreedFee: agreedTransferFee(player,fromTeam,toTeam)||0,
        agreedDate: isoDate(state.currentDate||new Date()),
        effectiveFromDate: isoDate(nextWindow),
      };
      player.__manualResolutionSeason=state.season;
      pushNews(state.currentDate,`${player.name} chegou a acordo para se transferir do ${teamLinkHtml(fromTeam.id)} para o ${teamLinkHtml(toTeam.id)}. Como a janela de inscrições está fechada, só poderá representar o novo clube a partir de ${fmtDateShort(nextWindow)}.`,"mercado","Transferência acordada — inscrição pendente",{autoAdvanceStop:involvesUser});
    } else { // transferencia imediata (janela aberta, ou ativação de uma etiqueta TRF anterior)
      initClubFinance(toTeam); if(fromTeam) initClubFinance(fromTeam);
      const value=fromTeam ? (opts.feeOverride!=null?opts.feeOverride:agreedTransferFee(player,fromTeam,toTeam)) : 0;
      if(fromTeam){
        fromTeam.players=fromTeam.players.filter(p=>p.id!==player.id);
        fromTeam.marketNeedDirty=true; // abriu uma lacuna real — ver AI_MARKET_COOLDOWN_DAYS em runAiToAiMarketPass
        addFinanceMovement(fromTeam,"receita","Transferências",`Venda de ${player.name}`,value,state.currentDate);
        // Limpa a sessão de negociação de fee (state.transferNegotiations) assim que o negócio se
        // concretiza — sem isto, a sessão "estado:contrato" ficava para sempre no dicionário,
        // mesmo depois de o jogador já ter mudado de clube há muito, acumulando entradas obsoletas
        // que "Acordos com clubes à espera de contrato" (Mercado) continuava a mostrar (pedido do
        // utilizador 2026-09-14: "isto não me interessa ver" — confirmado por teste dedicado: 82
        // sessões acumuladas numa simulação de 25 dias, 45 já obsoletas, 0 do próprio clube).
        if(state.transferNegotiations) delete state.transferNegotiations[transferNegotiationKey(player,fromTeam,toTeam)];
      }
      toTeam.players.push(player);
      registerPlayerEntry(player,toTeam,fromTeam?"transferencia":"livre",value,fromTeam);
      if(value) addFinanceMovement(toTeam,"despesa","Transferências",`Contratação de ${player.name}`,value,state.currentDate);
      toTeam.financeiro.orcamentoTransferencias=Math.max(0,toTeam.financeiro.orcamentoTransferencias-value);
      player.contrato=generateContract(overall(player),player.age,{anos,salarioMensal:offer.salarioMensal,papel:offer.papel,dataInicio:isoDate(state.currentDate||new Date())});
      player.titular=false; player.moral=clamp((player.moral||60)+6,0,100); player.satisfacao=clamp((player.satisfacao||60)+8,0,100);
      player.__manualResolutionSeason=state.season;
      state.transferHistory.unshift({player:player.name,from:fromTeam?fromTeam.name:"Livre",to:toTeam.name,value});
      // Eventos Narrativos — Fase 3 ("O Vilão", 09b-eventos-narrativos.js): só quando um jogador
      // que contava de facto para o clube do utilizador (formado lá, ou com presença de peso no
      // plantel) sai para outro clube — e só com uma probabilidade pequena, para o "vilão" não se
      // banalizar em toda e qualquer venda. A recorrência do evento a cada reencontro vive só no
      // catálogo (elegivel() ali verifica o próximo jogo do utilizador); esta marcação fica-se
      // por identificar quem É o vilão e para onde foi.
      if(fromTeam && fromTeam.id===state.userTeamId && toTeam.id!==fromTeam.id && overall(player)>=14){
        const jogosNoClube=(player.career&&player.career.jogos||0)+(player.season&&player.season.jogos||0);
        const importava = player.clubeFormadorId===fromTeam.id || jogosNoClube>=60;
        if(importava && Math.random()<0.35){
          player.vilaoDoClube=true;
          player.vilaoClubeId=toTeam.id;
          player.vilaoDesde=state.season;
          player.vilaoEncontros=0;
        }
      }
      state.transferMarket=state.transferMarket.filter(x=>x.playerId!==player.id);
      state.freeAgents=(state.freeAgents||[]).filter(p=>p.id!==player.id);
      pushNews(state.currentDate,`${player.name} muda-se do ${fromTeam?teamLinkHtml(fromTeam.id):"mercado livre"} para o ${teamLinkHtml(toTeam.id)}.`,"mercado",null,{autoAdvanceStop:involvesUser});
    }
  }
  // Ativa transferências com etiqueta TRF assim que a data chega à próxima janela de inscrição —
  // mesmo ponto único de avanço de dia dos restantes resolvers (dailyConditionRecovery,
  // 09-fluxo-epoca.js). Funciona da mesma forma estando ou não em defeso.
  function resolvePendingTransferHolds(date){
    Object.values(state.teams).forEach(fromTeam=>{
      fromTeam.players.slice().forEach(player=>{
        const hold=player.pendingTransferHold;
        if(!hold)return;
        if(new Date(date)<new Date(hold.effectiveFromDate))return;
        const toTeam=state.teams[hold.toTeamId];
        player.pendingTransferHold=null;
        if(!toTeam)return;
        applyAcceptedOffer("transferencia",player,fromTeam,toTeam,{salarioMensal:hold.salarioMensal,anos:hold.anos,papel:hold.papel},{skipWindowCheck:true,feeOverride:hold.agreedFee});
      });
    });
  }
  function releasePlayerToFreeAgency(playerId, teamId){
    const team=state.teams[teamId], player=team&&team.players.find(p=>p.id===playerId);
    if(!team||!player) return {ok:false,reason:"Jogador não encontrado."};
    // 2026-10-16: já vendido com transferência adiada para a próxima janela (TRF) — dispensá-lo
    // deixava um "livre" que outro clube podia contratar e que depois era levado pelo comprador original.
    if(player.pendingTransferHold) return {ok:false,reason:"Este jogador já está vendido (transferência à espera da próxima janela)."};
    const remaining=team.players.filter(p=>p.id!==player.id);
    if(player.pos==="GR" && !remaining.some(p=>p.pos==="GR")) return {ok:false,reason:"O clube precisa de manter pelo menos 1 guarda-redes."};
    if(player.pos!=="GR" && remaining.filter(p=>p.pos==="J").length<5) return {ok:false,reason:"O clube precisa de manter pelo menos 5 jogadores de campo."};
    rememberFreeAgentOrigin(player,team);
    team.players=remaining;
    team.marketNeedDirty=true; // abriu uma lacuna real — ver AI_MARKET_COOLDOWN_DAYS em runAiToAiMarketPass
    player.titular=false; player.__manualResolutionSeason=state.season; player.contrato=null; player.preContrato=null;
    state.freeAgents=(state.freeAgents||[]).concat(player);
    recordClubMovement(movementEntrySeason(), team, "saida", "dispensa", 0, player, null);
    if(freeAgentNewsRelevant(player,team)) pushNews(state.currentDate,`${player.name} foi dispensado pelo ${teamLinkHtml(team.id)} por mútuo acordo.`,"mercado");
    return {ok:true};
  }
  // Etiqueta "transferível" (pedido do utilizador, 2026-09-11): sinaliza um jogador teu como
  // disponível para negociar, com um valor pedido — ao contrário de releasePlayerToFreeAgency
  // (que dispensa já, de graça), isto não tira o jogador do plantel nem mexe no contrato, é só um
  // sinal para generateAiOffersForUser reagir. Pode ser colocada em qualquer altura do ano (não só
  // no defeso) — só tem efeito prático quando o defeso abrir, tal como já acontece com o resto do
  // mercado. Sem limite de quantos jogadores podes marcar, e sem bloqueio para jogadores
  // taticamente críticos: a decisão de vender é sempre tua.
  function setPlayerTransferListed(playerId, teamId, valorPedido){
    const team=state.teams[teamId], player=team&&team.players.find(p=>p.id===playerId);
    if(!team||!player) return {ok:false,reason:"Jogador não encontrado."};
    if(!isUserControlledTeam(team)) return {ok:false,reason:"Só podes colocar no mercado jogadores do teu clube."};
    const value=Math.max(0,Math.round(Number(valorPedido)||0));
    if(!value) return {ok:false,reason:"Indica um valor pedido válido."};
    player.transferListado=true; player.valorPedido=value;
    persAoListar(player);
    // Contradição directa entre o estatuto do jogador no clube e ser colocado no mercado: um
    // jogador Indispensável ou Titular importante fica descontente ao ver-se à venda, mesmo que o
    // estatuto seja automático (não só quando definido manualmente pelo utilizador) — a lógica é a
    // mesma, o jogador sabe o papel real que tem no plantel. Só a contradição directa; não há
    // penalização contínua por pouco uso (isso já é coberto, de forma parecida, pelo papel do
    // contrato em applyRolePromiseSatisfaction).
    const estatuto = effectivePlayerEstatuto(player, team);
    if(estatuto==="Indispensável" || estatuto==="Titular importante"){
      const penalidade = estatuto==="Indispensável" ? 18 : 10;
      player.satisfacao = clamp((player.satisfacao!=null?player.satisfacao:70) - penalidade, 0, 100);
      pushNews(state.currentDate, `${playerLinkHtml(team.id,player)} ficou surpreendido e desagradado ao ver-se colocado no mercado pelo ${teamLinkHtml(team.id)}, depois de lhe terem garantido um lugar de ${estatuto.toLowerCase()} no plantel.`, "sistema", `Descontentamento no ${team.name}`);
    }
    return {ok:true};
  }
  function clearPlayerTransferListed(playerId, teamId){
    const team=state.teams[teamId], player=team&&team.players.find(p=>p.id===playerId);
    if(!team||!player) return {ok:false,reason:"Jogador não encontrado."};
    player.transferListado=false; player.valorPedido=null;
    return {ok:true};
  }
  function movementEntrySeason(){
    return state.inDefeso && !state.isPreSeasonDefeso ? state.season+1 : state.season;
  }
  // Limite de inscrições por época (RGHP, pedido do utilizador 2026-09-14: "um jogador só pode
  // ser transferido 1 vez por epoca, ou seja pode ter 2 inscrições"): a inscrição inicial (o
  // clube por onde o jogador começa a época) conta como a 1ª — só é permitida MAIS UMA mudança
  // de clube (transferência definitiva, contratação de jogador livre, ativação de pré-contrato
  // ou empréstimo — confirmado pelo utilizador que empréstimos também contam) na mesma época.
  // Guardado no próprio jogador (player.registrationLimit={season,count}), incrementado só no
  // único ponto onde uma inscrição REALMENTE se efetiva (registerPlayerEntry, abaixo) — nunca no
  // momento em que um negócio é proposto ou mesmo acordado (uma etiqueta TRF, por exemplo, só
  // conta quando o negócio ativa de facto, não quando é combinado). Não se aplica a renovações
  // (nunca mudam de clube, nunca chamam registerPlayerEntry). Aplica-se por igual ao utilizador e
  // à IA porque o bloqueio vive nas funções de negociação partilhadas por ambos
  // (negotiateWithClub/proposeContract/canLoanPlayer), não numa verificação separada por caminho.
  function playerRegistrationsUsedThisSeason(player, season){
    season = season!=null ? season : movementEntrySeason();
    return (player.registrationLimit && player.registrationLimit.season===season) ? player.registrationLimit.count : 0;
  }
  function playerTransferLimitReached(player, season){
    return playerRegistrationsUsedThisSeason(player, season) >= 1;
  }
  // Separador "Transferências" da Ficha do Clube (2026-10-04): regista UM movimento no ledger
  // partilhado state.clubMovements — nunca chamado diretamente para a ponta de saída de uma
  // transferência (ver registerPlayerEntry, abaixo, que já trata dos dois lados de uma vez).
  function recordClubMovement(season, team, direction, type, value, player, counterpartTeam){
    if(!team) return;
    if(!Array.isArray(state.clubMovements)) state.clubMovements=[];
    state.clubMovements.unshift({
      season, date: isoDate(state.currentDate||new Date()),
      clubId: team.id, direction, tipo: type, valor: Math.max(0, Math.round(value||0)),
      playerId: player.id, playerName: player.name, playerPos: player.pos,
      counterpartId: counterpartTeam ? counterpartTeam.id : null,
      counterpartName: counterpartTeam ? counterpartTeam.name : (direction==="entrada" ? "Mercado livre" : null),
    });
  }
  // fromTeam (2026-10-04, opcional): quando a entrada tem uma equipa de origem conhecida na mesma
  // operação (transferência paga, ativação de pré-contrato, início de empréstimo), regista também
  // a saída correspondente do lado de lá — um único ponto de registo para os dois lados do mesmo
  // movimento, em vez de duplicar a chamada em cada local que já tem fromTeam/toTeam à mão.
  function registerPlayerEntry(player,team,type,value,fromTeam){
    const season=movementEntrySeason();
    player.movimentoEntrada={
      epoca:season, clubeId:team.id, tipo:type, valor:Math.max(0,Math.round(value||0))
    };
    player.registrationLimit={season, count:playerRegistrationsUsedThisSeason(player,season)+1};
    player.emprestimoListado=false;player.emprestimoMotivo=null;player.emprestimoListadoDesde=null; // 0.4.12: mudou de clube, deixa a lista de empréstimos
    recordClubMovement(season, team, "entrada", type, value, player, fromTeam||null);
    if(fromTeam) recordClubMovement(season, fromTeam, "saida", type, value, player, team);
  }

  function rememberFreeAgentOrigin(player,team){
    player.freeAgentContext={formerTeamId:team.id,formerTeamName:team.name,formerDivision:team.divisaoAtual,formerAppeal:Math.round(clubAppeal(team)*10)/10,formerTraining:team.condicoesTreino||"Boas",lastSalary:player.contrato?.salarioMensal||0,formerImportance:playerSquadImportance(player,team).score,formerRole:player.contrato?.papel||"Rotacao",releasedSeason:state.season,releasedDate:isoDate(state.currentDate||new Date()),rejectedTeams:[]};
  }
  function freeAgentMonths(player){const c=player.freeAgentContext;if(!c||!c.releasedDate||!state.currentDate)return 0;return Math.max(0,(state.currentDate-new Date(c.releasedDate+"T00:00:00Z"))/(30.4375*86400000));}
  function freeAgentCareerFit(player,team,role){
    const c=player.freeAgentContext;if(!c)return {ok:true,mult:1,score:60,drop:0,months:0};
    const fromRank=PLAYOFF_DIVISION_CONFIG[c.formerDivision]?3:isSecondTierDivision(c.formerDivision)?2:1;
    const drop=Math.max(0,fromRank-teamDivisionRank(team)),months=freeAgentMonths(player);
    const stage=careerStage(player),relaxBase=stage.id==="final"?.11:stage.id==="declinio"?.085:player.temperamento==="Ambicioso"?.045:.065;
    const relax=clamp(months*relaxBase,0,.82),appealDrop=Math.max(0,(c.formerAppeal||50)-clubAppeal(team));
    const trainingDrop=Math.max(0,(TREINO_APPEAL_SCORE[c.formerTraining]||50)-(TREINO_APPEAL_SCORE[team.condicoesTreino]||50));
    const importance=c.formerImportance||0,roleUpgrade=role==="Titular"&&c.formerRole!=="Titular";
    const sameClub=team.id===c.formerTeamId;
    let penalty=drop*28+appealDrop*.62+trainingDrop*.28+(importance>=80?18:importance>=65?10:0)+(player.temperamento==="Ambicioso"&&drop?15:0)-(roleUpgrade?10:0);
    penalty*=1-relax;
    if(sameClub&&months<4)penalty+=35;
    if(drop>=2&&months<6&&stage.id!=="final")penalty+=18;
    const score=72-penalty;
    let mult=1+drop*.38+appealDrop*.008+trainingDrop*.004+(importance>=80?.18:importance>=65?.10:0)+(player.temperamento==="Ambicioso"&&drop?.15:0)-(roleUpgrade?.08:0);
    mult=1+(mult-1)*(1-relax);
    return {ok:score>=40,mult:clamp(mult,1,2.4),score,drop,months,trainingDrop,sameClub};
  }
  function freeAgentSalaryDemand(player,team,role){const fit=freeAgentCareerFit(player,team,role),last=player.freeAgentContext?.lastSalary||0;return Math.max(expectedSalary(player,team),Math.round(last*fit.mult/50)*50,divisionSalaryProfile(team.divisaoAtual).base);}

  // Notícias do mercado de livres (pedido do utilizador, 2026-10-16): na passagem de época ficam
  // dezenas de jogadores livres — só os de reputação alta (ou ligados a um clube do utilizador)
  // merecem notícia; os restantes descobrem-se na lista de jogadores livres.
  const FREE_AGENT_NEWS_MIN_REPUTATION=40;
  function freeAgentNewsRelevant(player,...teams){
    if(teams.some(t=>t&&isUserControlledTeam(t))) return true;
    const rep=player.reputacaoJogador!=null?player.reputacaoJogador:(typeof computePlayerReputation==="function"?computePlayerReputation(player):0);
    return rep>=FREE_AGENT_NEWS_MIN_REPUTATION;
  }
  function signFreeAgentToTeam(team, player, opts){
    opts=opts||{};const b=crisisSpendingBlock(team,"contratacao",opts.salarioMensal,player);if(b){if(isUserControlledTeam(team))alert(b);return false;}
    state.freeAgents=(state.freeAgents||[]).filter(p=>p.id!==player.id);
    const ovr=overall(player),papel=opts.papel||assignInitialRole(ovr,player.age,player.potential,false);
    const anos=opts.anos||randomRenewalContractYears();
    const salario=opts.salarioMensal||Math.round(freeAgentSalaryDemand(player,team,papel)*0.96/50)*50;
    player.contrato=generateContract(ovr,player.age,{anos,salarioMensal:salario,papel,dataInicio:isoDate(state.currentDate||new Date())});
    player.titular=false; player.__manualResolutionSeason=state.season;
    team.players.push(player);
    registerPlayerEntry(player,team,"livre",0);
    if(typeof scintAoContratar==="function") scintAoContratar(team,player);
    player.lastFreeAgentMove=player.freeAgentContext?{...player.freeAgentContext,toTeamId:team.id,toTeamName:team.name,acceptedSalary:salario}:null;
    delete player.freeAgentContext;
    if(freeAgentNewsRelevant(player,team)) pushNews(state.currentDate,`${teamLinkHtml(team.id)} contratou ${player.name} (jogador livre) para reforçar o plantel.`,"mercado");
    return true;
  }
  // Equipas B não contratam externamente (nem jogadores livres, nem compras) — alimentam-se só
  // da formação e das renovações de contrato. Nunca preenchidas por esta rede de segurança.
  function ensureRosterMinimumsFromFreeAgents(team){
    if(team.equipaPrincipalId || team.selecaoNacional) return;
    let guard=0;
    while(team.players.filter(p=>p.pos==="GR").length<1 && guard<20){
      const idx=(state.freeAgents||[]).findIndex(p=>p.pos==="GR"&&!(typeof scintReservado==="function"&&scintReservado(p)));
      if(idx<0) break;
      signFreeAgentToTeam(team, state.freeAgents[idx]); guard++;
    }
    guard=0;
    while(team.players.filter(p=>p.pos==="J").length<8 && guard<20){
      const idx=(state.freeAgents||[]).findIndex(p=>p.pos==="J"&&!(typeof scintReservado==="function"&&scintReservado(p)));
      if(idx<0) break;
      signFreeAgentToTeam(team, state.freeAgents[idx]); guard++;
    }
  }
  // Fluxo de defeso (versão Fase 12/13 — corre uma vez por transição de época, antes do
  // ecrã dedicado de defeso previsto para a Fase 15): ativa pré-contratos, decide renovações
  // pela prioridade da IA (ou pelo que o utilizador já tiver negociado manualmente), liberta
  // jogadores para o mercado de livres e garante mínimos de plantel em todos os clubes.
  function processDefesoMarket(){
    if(state.defesoProcessedSeason===state.season) return;
    const stats={renovados:0,dispensados:0,preContratosAtivados:0,reforcosLivres:0};
    Object.values(state.teams).forEach(team=>{
      // Correção (bug reportado pelo utilizador, 2026-09-27: "as seleções não são clubes") — uma
      // equipa virtual de Seleção Nacional (state.teams["selecaoNacional-"+code]) partilha os
      // MESMOS objetos de jogador com o respetivo clube real (pickNationalSquad/
      // makeVirtualSelecaoTeam, 07h-selecoes.js, nunca copia jogadores) e persiste em state.teams
      // durante toda a janela do torneio — incluindo, por vezes, durante uma transição de época
      // (beginDefeso chama prepareSelecoesEdicaoForNewSeason() antes de processDefesoMarket()).
      // Sem esta exclusão, o contrato de um jogador convocado seria avaliado (e possivelmente
      // renovado/dispensado) usando o contexto sem sentido da seleção como "clube", em vez do seu
      // clube real — e a mesma decisão de dispensa contaria a duplicar sobre o mesmo jogador.
      if(team.selecaoNacional) return;
      initClubFinance(team);
      let releasedThisClub=0; const initialSquadSize=team.players.length;
      team.players.slice().forEach(player=>{
        if(player.preContrato){
          const destino=state.teams[player.preContrato.destinoId];
          if(destino && destino.id!==team.id){
            team.players=team.players.filter(p=>p.id!==player.id);
            const pc=player.preContrato;
            player.contrato=generateContract(overall(player),player.age,{anos:pc.anos,salarioMensal:pc.salarioMensal,papel:pc.papel,dataInicio:isoDate(state.currentDate)});
            player.titular=false; player.preContrato=null;
            destino.players.push(player);
            registerPlayerEntry(player,destino,"livre",0,team);
            stats.preContratosAtivados++;
            if(freeAgentNewsRelevant(player,team,destino)) pushNews(state.currentDate,`${player.name} muda-se para o ${teamLinkHtml(destino.id)}, depois de ter assinado um pré-contrato.`,"mercado");
          } else player.preContrato=null;
          return;
        }
        if(!player.contrato) return;
        if(player.__manualResolutionSeason===state.season) return; // já resolvido manualmente pelo utilizador
        if(!isFinalContractYear(player)) return;
        const priority=renewalPriorityScore(player,team);
        const tier=renewalTier(priority);
        const importance=playerSquadImportance(player,team),positionCount=team.players.filter(p=>p.pos===player.pos).length,coreFloor=player.pos==="GR"?2:8;
        const identityProtection=importance.score>=65||positionCount<=coreFloor||team.players.length<=10,departureCap=Math.max(1,Math.floor(initialSquadSize*.22));
        const baseChance=tier==="prioritaria"?1:tier==="tentar"?.90:tier==="seletiva"?.68:.28;
        const willRenew=identityProtection||releasedThisClub>=departureCap||Math.random()<baseChance;
        if(willRenew){
          const anos=randomRenewalContractYears();
          player.contrato=generateContract(overall(player),player.age,{anos,salarioMensal:Math.round(expectedSalary(player,team)*(0.92+Math.random()*0.16)),papel:importance.score>=65?"Titular":player.contrato.papel,dataInicio:isoDate(state.currentDate)});
          stats.renovados++;
        } else {
          rememberFreeAgentOrigin(player,team);
          team.players=team.players.filter(p=>p.id!==player.id);
          player.titular=false;
          state.freeAgents=(state.freeAgents||[]).concat(player);
          recordClubMovement(movementEntrySeason(), team, "saida", "fim-contrato", 0, player, null);
          releasedThisClub++;stats.dispensados++;
          if(freeAgentNewsRelevant(player,team)) pushNews(state.currentDate,`${player.name} deixou o ${teamLinkHtml(team.id)} em final de contrato.`,"mercado");
        }
      });
    });
    Object.values(state.teams).forEach(team=>{
      const before=team.players.length;
      ensureRosterMinimumsFromFreeAgents(team);
      stats.reforcosLivres += team.players.length-before;
    });
    state.defesoProcessedSeason=state.season;
    state.lastDefesoStats=stats;
  }
  // Mercado público: permite abordar qualquer jogador de uma equipa principal adversária.
  // Equipas B nunca aparecem aqui; os seus jogadores só circulam pelo mercado interno A/B.
  function refreshTransferMarket(){
    if(state.marketLastRefreshSeason===state.season&&state.transferMarket.length)return;
    const candidates=[];
    Object.values(state.teams).forEach(team=>{
      const isBTeam=!!team.equipaPrincipalId;
      // Correção (verificação pedida pelo utilizador): os clubes da nuvem europeia nunca podem
      // entrar no mercado de transferências — nem os seus jogadores listados, nem como
      // compradores. Sem esta exclusão, os seus jogadores (gerados com plantéis normais, sem
      // qualquer marca "__provisional") passavam o filtro seguinte e apareciam no mercado.
      if(team.id===state.userTeamId||isBTeam||team.nuvemEuropeia||team.selecaoNacional)return; // 0.2.3: 3.ª Divisão já entra no mercado
      team.players.forEach(player=>{
        if(!player.__provisional) candidates.push({team,player});
      });
    });
    state.transferMarket=candidates
      .sort((a,b)=>a.team.name.localeCompare(b.team.name,"pt")||overall(b.player)-overall(a.player)||a.player.name.localeCompare(b.player.name,"pt"))
      .map(x=>({teamId:x.team.id,playerId:x.player.id,value:playerMarketValue(x.player,x.team)}));
    state.marketLastRefreshSeason=state.season;
  }

  // ================= Empréstimos e propostas da IA =================
  function loanOfferKey(player,owner,destination){return [player.id,owner.id,destination.id].join("|");}
  // Fase 16: elegibilidade de empréstimo com dois perfis reais — jovem a precisar de minutos, ou
  // veterano pouco utilizado a tentar relançar a carreira — em vez de "jovem OU não-titular"
  // (demasiado permissivo, deixava passar praticamente qualquer suplente).
  // Correção: um jogador não-titular podia ser um dos melhores do clube na sua posição (ex.:
  // dois GR de nível muito parecido, ou um plantel curto onde o "suplente" ainda é claramente
  // necessário) — não titular não é o mesmo que "não vai fazer falta". Um clube só empresta
  // quem sobra mesmo depois de cobrir uma convocatória inteira (2 GR + 8 jogadores de campo,
  // as mesmas contagens da convocatória do utilizador) — os restantes, por muito banco que
  // sejam, continuam a contar como profundidade de plantel necessária.
  function isSquadSurplus(player, team){
    if(!team) return true; // sem equipa conhecida (compatibilidade), não bloqueia por este motivo
    const sameGroup = team.players.filter(p=>p.pos===player.pos).sort((a,b)=>overall(b)-overall(a));
    const rank = sameGroup.findIndex(p=>p.id===player.id);
    const neededCount = player.pos==="GR" ? CONVOCATORIA_MAX_GR : CONVOCATORIA_MAX_J;
    return rank >= neededCount;
  }
  function loanEligibilityProfile(player, team){
    // 0.4.12: o dono pôs o jogador na lista de empréstimos — a decisão dele prevalece (inclusive sobre ser titular).
    if(player.emprestimoListado){
      // Um clube de IA nunca empresta uma peça central do plantel, mesmo que a tenha listado antes de a situação mudar.
      if(!isUserControlledTeam(team) && playerSquadImportance(player,team).score>=65) return null;
      return "listado";
    }
    if(player.titular) return null; // um titular não é candidato a sair emprestado
    // Marco S: um clube que já sinalizou disponibilidade para vender este jogador (colocou-o na
    // lista de transferências) também aceita mais facilmente cedê-lo por empréstimo — não precisa
    // de se enquadrar no perfil "jovem"/"relançamento" abaixo.
    if(player.transferListado) return "listado";
    if(!isSquadSurplus(player, team)) return null;
    const gamesSoFar = Math.max(1, state.currentRound||1);
    const usageRate = clamp((player.season.jogos||0)/gamesSoFar, 0, 1);
    const rotationOrDev = player.contrato && (player.contrato.papel==="Rotacao"||player.contrato.papel==="Desenvolvimento");
    if(player.age<=23 && rotationOrDev) return "jovem";
    if(player.age>=28 && usageRate<0.35 && (player.satisfacao!=null?player.satisfacao:70)<65) return "relancamento";
    return null;
  }
  const LOAN_APPEAL_GAP_LIMIT = 18;      // diferença de atratividade (0-99) considerada "outra dimensão"
  // Calibração: um jogador com reputação individual baixa (a maioria dos jogadores de rotação,
  // mesmo em clubes grandes) só era barrado pelo LOAN_APPEAL_GAP_LIMIT quando a reputação
  // individual já era >=35 — na prática, nunca. Este limite absoluto aplica-se sempre,
  // independentemente da reputação do jogador, e é maior (mais permissivo) porque cobre também
  // os casos "anónimos" legítimos — só bloqueia mesmo os extremos (clube de elite -> clube do
  // fundo da tabela). Não se aplica a empréstimos vindos de uma equipa B (ver mais abaixo): uma
  // equipa B tem sempre pouca "atratividade" própria, mas pedir-lhe jogadores emprestados é uma
  // fonte de reforço perfeitamente normal, não uma "queda" de dimensão.
  // Correção: um empréstimo/compra entre o Placard e a 3ª Divisão foi encontrado a acontecer
  // (Juventude Pacense, Placard, emprestou a HC Fão, 3ª Divisão) mesmo com a diferença de apelo
  // dentro do limite (26, abaixo do limite de 30) — o problema real não é só a diferença
  // numérica, é saltar uma divisão inteira (a 2ª Divisão) sem lá passar. Um clube nunca pode
  // negociar diretamente com um clube a mais de uma divisão de distância.
  // Correção (2026-09-17, apontada pelo utilizador: "estas transferencias nao fazem sentido",
  // exemplo concreto no jogo real do utilizador — um jogador do FC Porto, reputação de topo, a
  // mudar-se para o CE Lleida, um clube bem mais modesto de Espanha): a OK Liga e a Serie A1 nunca
  // tinham entrada nesta tabela — só as três divisões portuguesas (placard/2div/3div) existiam
  // aqui. Como divisionsTooFarApart devolve `false` (ou seja, "distância aceitável") sempre que
  // QUALQUER um dos dois clubes tem uma divisão desconhecida na tabela, isto significava que esta
  // verificação de distância nunca se aplicava a NENHUMA transferência que envolvesse um clube
  // espanhol ou italiano — nem sequer entre uma 3ª Divisão portuguesa e o topo da OK Liga. A OK
  // Liga e a Serie A1 são, tal como o Campeonato Placard, a divisão de topo dos seus países (sem
  // 2ª/3ª divisão modelada) — ver HM2027_OKLiga_Implementada_2026-09-06.md e
  // HM2027_SerieA1_Implementada_2026-09-06.md — por isso entram aqui no mesmo nível (tier 1) que
  // o Placard: transferências entre topos de país continuam totalmente normais (é esse o ponto da
  // funcionalidade de transferências entre países), mas uma 2ª/3ª divisão portuguesa volta a ficar
  // sujeita ao mesmo limite de uma divisão de distância ao negociar com um clube estrangeiro. Isto
  // não substitui a verificação de reputação/apelo (purchaseGapBlocked/canLoanPlayer, que continua
  // a ser o que trava — ou não — um caso como o do FC Porto acima, consoante a reputação pessoal
  // do jogador em causa) — só corrige a distância de DIVISÃO, que estava a ser ignorada por completo
  // em qualquer negociação transfronteiriça.
  const DIVISION_TIER = { placard:1, "ok-liga":1, "serie-a1":1, "2div":2, "ok-liga-plata":2, "3div":3 };
  // 0.3.1 (pedido do utilizador: "a transferência de jogadores entre divisões distantes nunca deve
  // estar limitada para o utilizador"): qualquer negociação em que um dos clubes seja controlado
  // pelo utilizador (equipa A ou B) deixa de estar sujeita à distância de divisão. O limite
  // mantém-se para clubes de IA entre si.
  function divisionsTooFarApart(teamA, teamB){
    if(isUserControlledTeam(teamA) || isUserControlledTeam(teamB)) return false;
    const a = DIVISION_TIER[teamA.divisaoAtual], b = DIVISION_TIER[teamB.divisaoAtual];
    if(a==null || b==null) return false;
    return Math.abs(a-b) > 1;
  }
  const LOAN_APPEAL_GAP_HARD_LIMIT = 30;
  // Correção: o mesmo problema de distância entre clubes que já existia nos empréstimos
  // também acontecia nas compras — quando o empréstimo falhava a verificação de dimensão (ex.:
  // um clube da 3ª Divisão a pedir um jogador do plantel principal do Sporting), o código não
  // desistia, propunha antes uma COMPRA, sem nenhuma verificação de distância nessa via. Só
  // bloqueia o sentido "clube pequeno compra a um clube grande" — um clube grande comprar a um
  // clube pequeno continua livre (é normal, é como funciona a descoberta de talento na vida real).
  // Um jogador com alguma reputação pessoal só se transfere (venda definitiva, não empréstimo)
  // para um clube claramente maior — nunca lateral nem para baixo. PURCHASE_DOWNGRADE_TOLERANCE
  // dá uma margem de ruído pequena (o "apelo" do clube oscila com resultados recentes/finanças,
  // dois clubes quase empatados não devem travar-se por causa disso); PURCHASE_DOWNGRADE_REP_FLOOR
  // é bem mais baixo que o equivalente dos empréstimos (LOAN_STAR_REPUTATION=55) porque uma VENDA
  // definitiva é mais grave e permanente do que um empréstimo — um jogador não precisa de ser um
  // "astro" para isto se aplicar, só de já ter alguma reputação pessoal a valer a pena proteger.
  const PURCHASE_DOWNGRADE_TOLERANCE = 3;
  const PURCHASE_DOWNGRADE_REP_FLOOR = 15;
  function purchaseGapBlocked(owner, destination, player){
    if(divisionsTooFarApart(owner,destination)) return true;
    const gap = clubAppeal(destination)-clubAppeal(owner);
    const ownerIsBTeam = !!owner.equipaPrincipalId;
    // 0.3.1: o utilizador nunca fica limitado pela diferença de dimensão entre clubes (divisões distantes).
    const userInvolved = isUserControlledTeam(owner) || isUserControlledTeam(destination);
    if(!userInvolved && !ownerIsBTeam && gap < -LOAN_APPEAL_GAP_HARD_LIMIT) return true;
    // Correção (verificação pedida pelo utilizador, 2026-09-13: "o Zé Miranda é um jogador da
    // formação do Benfica, muito acarinhado pelos sócios. Ele só sai para um clube maior e por
    // muito, muito dinheiro" — e casos semelhantes: Nil Roca/Benfica→Vilafranca, Luís
    // Belchior/Barcelos→Caldes). O limite "duro" acima (30 pontos de apelo) só travava o caso mais
    // extremo — um clube ligeiramente menor continuava livre para comprar um jogador com
    // reputação real a um clube maior. Só se aplica quando `player` é conhecido nesta chamada
    // (algumas verificações genéricas de clube ainda chamam esta função sem jogador, antes de
    // escolher um candidato).
    if(player && !ownerIsBTeam && gap < -PURCHASE_DOWNGRADE_TOLERANCE && (player.reputacaoJogador||0)>=PURCHASE_DOWNGRADE_REP_FLOOR) return true;
    return false;
  }
  // Correção: o limite "duro" acima (30 pontos de apelo) só travava o caso mais extremo. Um
  // clube modesto continuava a poder comprar, a peso de ouro, um jogador com nome a um clube
  // claramente maior (ex.: Riba d'Ave a comprar titulares do Benfica/FC Porto) — porque o apelo
  // do clube já mistura vários fatores (resultados, finanças, condições) que diluem a diferença
  // pura de reputação até ficar abaixo dos 30 pontos. Bloquear a compra à partida, no entanto,
  // modelaria isto como "o clube vendedor recusa-se a vender", quando o que realmente devia
  // travar estas transferências é o próprio JOGADOR: um clube pode sempre aceitar uma proposta
  // financeira boa, mas o jogador só assina por um clube claramente pior se for compensado com
  // um salário bem mais alto — exatamente a mesma lógica (transferCareerPenalty) já usada nas
  // negociações pessoais do utilizador (contractDemand). Aplicamos aqui a mesma inflação
  // salarial ao custo de uma compra IA-IA, em vez de um bloqueio rígido: continua possível, mas
  // só quando o clube comprador consegue mesmo pagar o que o jogador exige.
  const LOAN_STAR_REPUTATION = 55;        // reputacaoJogador (0-100) a partir da qual se considera "estrela"
  const LOAN_STAR_INTERNATIONAL = 8;      // internacionalizações a partir das quais se considera "internacional de topo"
  const LOAN_BIG_CLUB_MIN_QUALITY = 14;   // OVR mínimo que justifica um clube grande pedir emprestado, em vez de comprar
  function canLoanPlayer(player,owner,destination){
    if(!player||!owner||!destination)return{ok:false,reason:"Dados de empréstimo inválidos."};
    if(player.emprestimo)return{ok:false,reason:"O jogador já está emprestado."};
    if(player.pendingTransferHold)return{ok:false,reason:"Este jogador já tem uma transferência acordada, à espera da próxima janela de inscrição."};
    // Limite de 1 transferência por época (pedido do utilizador: "empréstimo conta"): um
    // empréstimo também gera uma inscrição nova no clube de destino, por isso conta para o
    // mesmo limite das transferências definitivas e assinaturas de jogadores livres.
    if(playerTransferLimitReached(player))return{ok:false,reason:"Este jogador já foi transferido esta época — só pode voltar a mudar de clube na época seguinte."};
    if(owner.id===destination.id)return{ok:false,reason:"O destino tem de ser outro clube."};
    // Guarda de segurança (verificação pedida pelo utilizador): os clubes da nuvem europeia
    // nunca participam no mercado — nem a comprar/pedir emprestado, nem a ceder/emprestar.
    if(owner.nuvemEuropeia||destination.nuvemEuropeia)return{ok:false,reason:"Este clube nunca participa no mercado de transferências."};
    if(player.intransferivel)return{ok:false,reason:"Este jogador não está disponível — não pode ser emprestado a nenhum clube."};
    if(owner.selecaoNacional||destination.selecaoNacional)return{ok:false,reason:"Este clube nunca participa no mercado de transferências."};
    if(divisionsTooFarApart(owner,destination)) return {ok:false,reason:"Os dois clubes estão a mais de uma divisão de distância — nunca negoceiam diretamente entre si."};
    const profile = loanEligibilityProfile(player, owner);
    if(!profile) return {ok:false,reason:"Este jogador não se enquadra num perfil de empréstimo: nem jovem a precisar de minutos, nem veterano pouco utilizado a relançar a carreira."};
    const isStar = (player.reputacaoJogador||0)>=LOAN_STAR_REPUTATION || (player.internacionalizacoes||0)>=LOAN_STAR_INTERNATIONAL;
    if(isStar) return {ok:false,reason:"Jogador com reputação ou internacionalizações elevadas — não costuma ser emprestado."};
    const gap = clubAppeal(destination)-clubAppeal(owner); // positivo = destino maior que o proprietário
    // Emprestar de uma equipa B é sempre normal (não é uma "queda" de dimensão, é a fonte mais
    // comum de reforço) — isento do limite de distância entre clubes.
    const ownerIsBTeam = !!owner.equipaPrincipalId;
    const userInvolvedLoan = isUserControlledTeam(owner) || isUserControlledTeam(destination); // 0.3.1
    if(!userInvolvedLoan && !ownerIsBTeam && gap < -LOAN_APPEAL_GAP_HARD_LIMIT) return {ok:false,reason:"A diferença de dimensão entre os clubes é grande demais para um empréstimo fazer sentido."};
    // Um jogador totalmente anónimo (reputação muito baixa) pode perfeitamente sair de um clube
    // grande para um pequeno à procura de minutos — é o caso de uso mais comum e realista. Só
    // bloqueia quando o jogador já tem alguma reputação a mais para a dimensão do destino.
    if(!ownerIsBTeam && gap < -LOAN_APPEAL_GAP_LIMIT && (player.reputacaoJogador||0)>=35) return {ok:false,reason:"O clube de destino é demasiado pequeno para a reputação deste jogador."};
    // Correção: o limite de distância "de cima para baixo" já existia, mas faltava o
    // equivalente "de baixo para cima" — um jogador anónimo de um clube muito pequeno (incluindo
    // perfil "relançamento", que não tinha nenhuma verificação de distância) podia saltar
    // divisões inteiras (ex.: 3ª Divisão direto para o Placard) sem qualquer travão, desde que
    // não fosse "jovem" com OVR baixo (o único caso já coberto). Aplica-se sempre, a qualquer
    // perfil, tal como o limite equivalente na direção inversa.
    if(!userInvolvedLoan && !ownerIsBTeam && gap > LOAN_APPEAL_GAP_HARD_LIMIT) return {ok:false,reason:"A diferença de dimensão entre os clubes é grande demais para um empréstimo fazer sentido."};
    if(!ownerIsBTeam && gap > LOAN_APPEAL_GAP_LIMIT && profile==="jovem" && overall(player)<LOAN_BIG_CLUB_MIN_QUALITY){
      return {ok:false,reason:"Um clube desta dimensão deveria contratar ou promover da equipa B, em vez de pedir emprestado um jovem comum."};
    }
    return {ok:true, profile};
  }
  function evaluateLoanOffer(player,owner,destination,share,role,clausulas){
    const check=canLoanPlayer(player,owner,destination);if(!check.ok)return{outcome:"recusa",reason:check.reason};
    const profile=check.profile;
    const roleScore=role==="Titular"?20:role==="Rotacao"?8:-2;
    const motivoLista=player.emprestimoListado?(player.emprestimoMotivo||"evoluir"):null;
    // 0.4.12: um dono que listou o jogador para aliviar a massa salarial dá mais peso a quem paga o salário.
    const financeScore=clamp(share,0,100)*(motivoLista&&motivoLista!=="evoluir"?.30:.22);
    const appeal=clubAppeal(destination)-clubAppeal(owner);
    let score=35+roleScore+financeScore+appeal*.12+empPrecoDono(clausulas,player,owner);
    if(motivoLista){
      score+=10; // o próprio clube quer emprestá-lo
      if(motivoLista!=="salario"){ if(role==="Desenvolvimento") score-=10; }
      else if(role==="Desenvolvimento") score-=4;
    } else if(profile==="jovem"){
      score+=15; // precisa de minutos regulares para desenvolver
      if(role==="Desenvolvimento") score-=10; // quer jogar, não só treinar
    } else { // relancamento
      score+=10;
      if(role==="Desenvolvimento") score-=15; // um veterano não aceita um papel de formação
    }
    if(score>=64)return{outcome:"aceita"};
    if(score>=42)return{outcome:"contraproposta",counter:{salaryShare:Math.max(50,Math.min(100,share+25)),role:profile==="jovem"?"Titular":"Rotacao",clausulas:empContrapropostaClausulas(clausulas,player,owner)}};
    return{outcome:"recusa",reason:"O clube proprietário não considera o empréstimo vantajoso."};
  }
  function completeLoan(player,owner,destination,share,role,clausulas,opts){
    const check=canReleasePlayerFromTeam(owner,player);if(!check.ok)return check;
    owner.players=owner.players.filter(p=>p.id!==player.id);destination.players.push(player);
    owner.marketNeedDirty=true; // abriu uma lacuna real (saída por empréstimo) — ver AI_MARKET_COOLDOWN_DAYS em runAiToAiMarketPass
    player.emprestimoListado=false;player.emprestimoMotivo=null;player.emprestimoListadoDesde=null; // 0.4.12: já saiu por empréstimo
    registerPlayerEntry(player,destination,"emprestimo",0,owner);
    player.titular=false;invalidateLoanIndex();player.emprestimo={ownerId:owner.id,destinationId:destination.id,salaryShare:clamp(share,0,100),papel:role,startSeason:state.season,returnSeason:state.season+1,clausulas:empNormalizarClausulas(clausulas),inicio:isoDate(state.currentDate),rondaInicio:state.currentRound||0,jogosInicio:(player.season&&player.season.jogos)||0,golosInicio:(player.season&&player.season.golos)||0,titularInicio:(player.season&&player.season.jogosTitular)||0,notasInicio:(player.season&&Array.isArray(player.season.notas)?player.season.notas.length:0),ovrInicio:overall(player),chamadaUsada:false};
    state.loanHistory.unshift({player:player.name,from:owner.name,to:destination.name,share:player.emprestimo.salaryShare,season:state.season});
    if(!(opts&&opts.silencioso))pushNews(state.currentDate,`${player.name} foi emprestado por ${teamLinkHtml(owner.id)} a ${teamLinkHtml(destination.id)} por uma época (${empClausulasTexto(clausulas)}).`,'mercado',null,{autoAdvanceStop:isUserControlledTeam(owner)||isUserControlledTeam(destination)});return{ok:true};
  }
  function loanNegotiationKey(player,owner,destination){return [player.id,owner.id,destination.id].join("|");}
  // Empréstimos (2026-09-14, pedido do utilizador: também passam a ter demora de negociação, tal
  // como as transferências definitivas e os contratos pessoais). Ao contrário das duas
  // negociações acima, um pedido de empréstimo nunca tinha sessão persistida — cada chamada era
  // avaliada do zero — por isso usa um novo `state.loanNegotiations`, mas segue exatamente o
  // mesmo molde de pedido/resposta com demora de 1-4 dias.
  function proposeLoan(playerId,ownerId,destinationId,share,role,clausulas){
    const owner=state.teams[ownerId],destination=state.teams[destinationId],player=owner&&owner.players.find(p=>p.id===playerId);
    const check=canLoanPlayer(player,owner,destination);
    if(!check.ok)return{outcome:"recusa",reason:check.reason};
    if(!state.loanNegotiations)state.loanNegotiations={};
    const key=loanNegotiationKey(player,owner,destination);
    const existing=state.loanNegotiations[key];
    if(existing&&existing.estado==="pendente")return{outcome:"pendente",reason:"Já há um pedido de empréstimo à espera de resposta.",responseDate:existing.responseDate};
    const d=state.currentDate||new Date();
    const rondas=(existing?existing.rondas||0:0)+1;
    const rng=makeSeededRng(`loan-neg:${key}:${rondas}:${isoDate(d)}`);
    const dias=seededRnd(rng,1,4), responseDate=addDays(d,dias);
    const session={estado:"pendente",playerId:player.id,ownerId:owner.id,destinationId:destination.id,share:clamp(share,0,100),role,clausulas:empNormalizarClausulas(clausulas),submittedDate:isoDate(d),responseDate:isoDate(responseDate),rondas};
    state.loanNegotiations[key]=session;
    // Mesma correção (2026-09-17) do fee entre clubes: quando é o utilizador a pedir o
    // empréstimo, a confirmação tem de vir do clube DONO do jogador (quem vai analisar o
    // pedido), não do próprio utilizador; quando é o utilizador quem recebe o pedido (dono),
    // a notícia vem do clube de destino, que é quem está a pedir.
    if(isUserControlledTeam(destination))pushNews(d,`Recebemos o teu pedido de empréstimo de ${playerLinkHtml(owner.id,player)}. Vamos analisar e responder até ${fmtDateShort(responseDate)}.`,"proposta","Pedido de empréstimo enviado",{sender:resolveNewsSender("proposta",{teamId:owner.id})});
    else if(isUserControlledTeam(owner))pushNews(d,`${teamLinkHtml(destination.id)} pediu para levar ${playerLinkHtml(owner.id,player)} por empréstimo. Vamos analisar e responder até ${fmtDateShort(responseDate)}.`,"proposta","Pedido de empréstimo recebido",{autoAdvanceStop:true,sender:resolveNewsSender("proposta",{teamId:destination.id})});
    return{outcome:"pendente",responseDate:session.responseDate};
  }
  function resolvePendingLoanNegotiations(date){
    if(!state.loanNegotiations)return;
    Object.keys(state.loanNegotiations).forEach(key=>{
      const session=state.loanNegotiations[key];
      if(!session||session.estado!=="pendente")return;
      if(new Date(date)<new Date(session.responseDate))return;
      const owner=state.teams[session.ownerId],destination=state.teams[session.destinationId];
      const player=owner&&owner.players.find(p=>p.id===session.playerId);
      const involvesUser=owner&&destination&&(isUserControlledTeam(owner)||isUserControlledTeam(destination));
      if(!owner||!destination||!player){session.estado="cancelada";return;}
      const result=evaluateLoanOffer(player,owner,destination,session.share,session.role,session.clausulas);
      if(result.outcome==="aceita"){
        // 0.4.12: o clube aceitou — falta o jogador. Com o utilizador envolvido há 1-3 dias de demora
        // (resolveLoanConsents); entre clubes de IA decide-se já.
        if(involvesUser){ loanSessionToPlayerConsult(session,player,owner,destination,date); return; }
        const dec=loanConsentDecide(player,owner,destination,session.share,session.role,key);
        if(!dec.ok){ session.estado="recusada-jogador"; session.motivoJogador=dec.motivoNeg||null; session.recusadaEm=isoDate(new Date(date)); loanNoteRefusal(player,destination.id); return; }
        session.estado="aceite";
        completeLoan(player,owner,destination,session.share,session.role,session.clausulas);
        if(session.aiMeta && !isUserControlledTeam(destination)){
          const total=aiTotalRecruitmentCost(player,destination,"emprestimos",0,(player.contrato?.salarioMensal||0)*.5);
          aiRegisterRecruitment(destination,player,"emprestimos",total);
        }
      } else if(result.outcome==="contraproposta"){
        session.estado="clube";session.counter=result.counter;
        if(involvesUser)pushNews(date,`${teamLinkHtml(owner.id)} respondeu com uma contraproposta para o empréstimo de ${playerLinkHtml(owner.id,player)}: ${result.counter.salaryShare}% do salário, papel ${ROLE_LABELS[result.counter.role]||result.counter.role}, ${empClausulasTexto(result.counter.clausulas)}.`,"proposta","Contraproposta de empréstimo",{autoAdvanceStop:true, teamId:owner.id});
      } else {
        session.estado="recusada";
        if(involvesUser)pushNews(date,`${teamLinkHtml(owner.id)} recusou o pedido de empréstimo de ${playerLinkHtml(owner.id,player)}: ${result.reason}`,"proposta","Pedido de empréstimo recusado",{autoAdvanceStop:true, teamId:owner.id});
      }
    });
  }
  function returnSeasonLoans(){
    Object.values(state.teams).filter(t=>!String(t.id||"").startsWith("selecaoNacional-")).forEach(destination=>destination.players.slice().forEach(player=>{
      const loan=player.emprestimo;if(!loan||loan.returnSeason>state.season+1)return;
      const owner=state.teams[loan.ownerId];if(!owner)return;
      if(empFimDeEmprestimo(destination,owner,player,loan))return; // opção de compra exercida: o jogador fica no destino
      destination.players=destination.players.filter(p=>p.id!==player.id);owner.players.push(player);
      player.emprestimo=null;player.titular=false;
      const seasonRegresso=movementEntrySeason();
      recordClubMovement(seasonRegresso, owner, "entrada", "fim-emprestimo", 0, player, destination);
      recordClubMovement(seasonRegresso, destination, "saida", "fim-emprestimo", 0, player, owner);
      // 2026-10-15 (pedido do utilizador): sem notícias de TODOS os regressos de empréstimo no início da
      // época — só quando o clube do utilizador (A ou B) é o dono ou o destino.
      if(isUserControlledTeam(owner)||isUserControlledTeam(destination)) pushNews(state.currentDate,`${player.name} regressou a ${teamLinkHtml(owner.id)} após o empréstimo.`,'mercado');
    }));
  }
  // Fase C: carências ligadas à identidade tática do clube — só verificadas depois de cumpridos
  // os mínimos gerais de plantel (GR/jogadores de campo). Um clube "3-1" precisa de pelo menos
  // 1 AVÇ de referência e de um DEF/MED construtor; um clube "2-2" precisa de pelo menos 2 AVÇ.
  function aiSquadNeed(team){
    const gr=realGoalkeeperCount(team),j=team.players.filter(p=>p.pos==="J"&&!p.__provisional).length;
    if(gr<2) return "GR";
    // Correção (pedido do utilizador: "há um problema com guarda-redes, as equipas ficam facilmente
    // sem 2 GR e vão sempre buscar o Henrique Dias"): ter 2 GR "no papel" não significa ter 2
    // disponíveis para jogar — um deles pode estar de fora várias semanas/meses com uma lesão grave
    // de longa duração, e isso nunca era visto como carência pelo mercado da IA (só contava o total
    // de GR no plantel, disponíveis ou não). Chegava-se sempre ao dia do jogo sem reforço a tempo e
    // o motor recorria ao jogador de emergência genérico. Reaproveita AI_LONG_INJURY_DAYS_THRESHOLD
    // (já usado para as razões urgentes fora da janela) — só conta como carência urgente quando a
    // paragem é mesmo longa, nunca por uma lesão ligeira ou suspensão curta.
    const grPlayers=team.players.filter(p=>p.pos==="GR"&&!p.__provisional);
    const disponiveisAgora=grPlayers.filter(playerAvailableForMatch).length;
    if(disponiveisAgora<2 && grPlayers.some(p=>!playerAvailableForMatch(p) && (p.diasLesao||0)>=AI_LONG_INJURY_DAYS_THRESHOLD)) return "GR";
    if(j<9) return "J";
    const sistema = team.sistema||"3-1";
    const outfield = team.players.filter(p=>p.pos==="J");
    const avcs = outfield.filter(p=>p.linha==="Avancado");
    const minAvc = sistema==="2-2" ? 2 : 1;
    if(avcs.length<minAvc) return "AVC";
    if(sistema==="3-1" && !outfield.some(p=>p.linha!=="Avancado" && playerProfile(p)==="construtor")) return "CONSTRUTOR";
    return null;
  }
  function candidateMatchesNeed(p, need){
    if(need==="GR") return p.pos==="GR";
    if(need==="AVC") return p.pos==="J" && p.linha==="Avancado";
    if(need==="CONSTRUTOR") return p.pos==="J" && p.linha!=="Avancado" && playerProfile(p)==="construtor";
    return p.pos==="J";
  }
  // Fase C (secção 17 do documento): um clube não deve libertar (venda ou empréstimo) um
  // jogador essencial para a identidade tática do seu sistema sem ter alternativa no plantel —
  // o único AVÇ adequado ao 3-1, um dos únicos dois AVÇ do 2-2, ou o único DEF/MED construtor.
  function aiSystemCriticalityBlock(team, player){
    if(player.pos!=="J") return null;
    const sistema = team.sistema||"3-1";
    const outfield = team.players.filter(p=>p.pos==="J");
    if(player.linha==="Avancado"){
      const avcs = outfield.filter(p=>p.linha==="Avancado");
      const minAvc = sistema==="2-2" ? 2 : 1;
      if(avcs.length<=minAvc) return sistema==="2-2" ? "É um dos únicos dois avançados necessários ao 2-2." : sistema==="1-2-1" ? "É o único avançado (pivot) do sistema 1-2-1." : "É o único avançado de referência do sistema 3-1.";
      return null;
    }
    if(playerProfile(player)==="construtor"){
      const construtores = outfield.filter(p=>p.linha!=="Avancado" && playerProfile(p)==="construtor");
      if(construtores.length<=1) return "É o único DEF/MED construtor do plantel.";
    }
    return null;
  }
  function clubAverageOutfieldOverall(team){
    const outfield=team.players.filter(p=>p.pos==="J");
    if(!outfield.length) return 12;
    return outfield.reduce((s,p)=>s+overall(p),0)/outfield.length;
  }
  // Correção (2026-09-11, pedido do utilizador: "recebo sempre 3 propostas por jogador... a ia
  // deve usar critérios"): antes, um clube sem carência específica de plantel (o caso mais comum
  // — a maioria dos clubes já tem o mínimo de guarda-redes/jogadores de campo/avançados/construtor
  // preenchido) caía sempre no mesmo critério genérico e global — "o teu jogador mais próximo de
  // OVR 14" — igual para TODOS os clubes, o que fazia dezenas de clubes diferentes convergirem,
  // dia após dia, sempre no mesmo jogador teu (e o limite de 3 propostas novas por dia, que existe
  // só para não inundar o ecrã, acabava quase sempre preenchido três vezes por esse único alvo).
  // Uma primeira tentativa de correção usou aiSquadUpgradeValue (já usado no mercado IA-contra-IA)
  // como critério — mas essa função só desloca a pontuação de cada candidato por uma CONSTANTE por
  // clube, o que não muda a ORDEM relativa dos candidatos: continuava a escolher sempre o mesmo
  // jogador (o de OVR mais alto) para todos os clubes, só a pontuação absoluta é que mudava.
  // A escolha usa agora aiOfferTargetScore: o "alvo ideal" de cada clube deixa de ser um número
  // fixo (14 para todos) e passa a ser calculado a partir da PRÓPRIA média de OVR do plantel desse
  // clube (mais uma margem de reforço realista) — como essa média genuinamente difere de clube
  // para clube, também difere o jogador teu que cada um prefere, sem introduzir nenhuma
  // aleatoriedade nova: é sempre o mesmo cálculo determinístico, só que compara com um referencial
  // que varia de clube para clube, tal como aconteceria com clubes reais de dimensões diferentes.
  // Os teus jogadores taticamente críticos para o sistema (aiSystemCriticalityBlock, já usado para
  // proteger isto entre clubes IA, mas nunca aplicado até agora às propostas que TU recebes)
  // deixam de poder ser alvo espontâneo — a não ser que os marques tu mesmo como transferíveis
  // (ver abaixo), já que aí a decisão de vender é tua.
  function aiOfferTargetScore(candidate,club,need){
    const tacticalNeed=need==="CONSTRUTOR"&&playerProfile(candidate)==="construtor"?4:need==="AVC"&&candidate.linha==="Avancado"?3:0;
    const sistema=club.sistema||"3-1";
    const styleFit=candidate.linha==="Avancado"?(sistema==="2-2"?2:0):(playerProfile(candidate)==="construtor"?(sistema==="3-1"?2:0):0);
    const targetLevel=clubAverageOutfieldOverall(club)+2; // reforço realista: ligeiramente acima da própria média do clube, não necessariamente o teu melhor jogador
    const proximity=-Math.abs(overall(candidate)-targetLevel);
    return proximity+tacticalNeed+styleFit;
  }
  // Prémio de preço exigido pela IA para sequer considerar um jogador Indispensável/Titular
  // importante do utilizador (Marco R): sorteado por jogador (estável dia a dia, não recalculado a
  // cada tentativa), para não ser sempre exactamente "o dobro" — mesmo padrão de jitter
  // determinístico de playerDissatisfactionThreshold (06-motor-jogo.js).
  function aiOfferStatusPremiumThreshold(player){
    return seededRndFloat(makeSeededRng(`${player.id}|estatuto-premio`), 1.4, 2.6);
  }
  // 0.4.6: interesse desportivo realista. O jogador tem de ter nível para a rotação do clube
  // proponente: compara-se com o 7.º melhor jogador de campo desse clube (o limite da rotação
  // numa equipa de 4+GR com banco). Quanto maior o clube face ao do utilizador, menos tolerância
  // (um grande não propõe por quem está claramente abaixo do seu plantel); um clube igual ou
  // menor aceita jogadores ligeiramente abaixo, porque os reforços pontuais são normais.
  function aiOfferPlayerFitsBuyer(player, ai, user){
    const ovs=ai.players.filter(p=>p.pos===player.pos&&!p.__provisional&&!p.emprestimo).map(p=>overall(p)).sort((x,y)=>y-x);
    if(!ovs.length) return true;
    const ref = player.pos==="GR" ? ovs[Math.min(1,ovs.length-1)] : ovs[Math.min(6,ovs.length-1)];
    const gap = clubAppeal(ai) - clubAppeal(user);
    const tolerancia = gap > 20 ? 0 : gap > 8 ? 0.5 : gap > -5 ? 1.5 : 2.5;
    return overall(player) >= ref - tolerancia;
  }
  // 0.4.14 (pedido do utilizador, a jogar com o Entroncamento sem mexer nos estatutos: "estou a
  // receber demasiadas propostas da IA para vender jogadores, é um exagero e não é real"): medido
  // em simulação, 56 propostas em 46 dias, quase todas pelos 4 titulares, vindas de 40+ clubes de
  // todas as divisões. A causa era o critério acima: "7.º melhor do comprador" é o nível do banco,
  // que quase todos os clubes cumprem, por isso qualquer clube sem carência tinha interesse em
  // qualquer titular teu. Uma proposta ESPONTÂNEA (o utilizador não pôs o jogador à venda) só faz
  // sentido se o jogador for um reforço real para o onze do comprador: quanto maior o clube face
  // ao teu, mais acima tem de entrar na hierarquia do plantel dele (um grande só vem buscar quem
  // seria titular; um clube do mesmo nível já aceita um jogador de rotação alta). Guarda-redes:
  // tem de ser, pelo menos, tão bom como o titular do comprador (com uma pequena tolerância se o
  // clube for do teu nível ou inferior). Não há teto numérico: o volume desce porque a maioria dos
  // clubes deixa de ter motivo desportivo.
  function aiOfferPlayerUpgradesBuyer(player, ai, user, need){
    const ovs=ai.players.filter(p=>p.pos===player.pos&&!p.__provisional&&!p.emprestimo).map(p=>overall(p)).sort((x,y)=>y-x);
    if(!ovs.length) return true;
    const gap = clubAppeal(ai) - clubAppeal(user);
    let idx, tol;
    if(player.pos==="GR"){ idx=0; tol = gap>8 ? 0 : 1; }
    else if(gap>20){ idx=2; tol=0; }
    else if(gap>8){ idx=3; tol=0; }
    else if(gap>-5){ idx=4; tol=0.5; }
    else { idx=5; tol=1; }
    // Sem carência de plantel (o caso comum), o clube só avança por quem seja claramente melhor do
    // que o que já tem: entre os 3 melhores jogadores de campo dele, ou o titular da baliza só se
    // for estritamente superior. Com carência, aplica-se o critério normal acima.
    if(!need){
      if(player.pos==="GR"){ return overall(player) > ovs[0]; }
      idx=Math.min(idx,2); tol=0;
    }
    const ref=ovs[Math.min(idx,ovs.length-1)];
    return overall(player) >= ref - tol;
  }
  // Intervalo mínimo entre duas abordagens espontâneas do mesmo clube ao utilizador (um clube
  // faz uma abordagem de cada vez; só volta a tentar passado este tempo).
  // Um clube com carência real volta a abordar passadas 3 semanas; um clube sem carência só faz uma
  // abordagem oportunista por janela de inscrições (≈ 6 semanas de intervalo, no mínimo).
  const AI_OFFER_APPROACH_COOLDOWN_DAYS = 21;
  const AI_OFFER_APPROACH_COOLDOWN_NO_NEED_DAYS = 45;
  function aiRecentlyApproachedUser(ai, need){
    if(!ai.lastUserApproachDate) return false;
    const hoje = state.currentDate||new Date();
    return (new Date(isoDate(hoje)+"T00:00:00Z") - new Date(ai.lastUserApproachDate+"T00:00:00Z"))/86400000 < (need?AI_OFFER_APPROACH_COOLDOWN_DAYS:AI_OFFER_APPROACH_COOLDOWN_NO_NEED_DAYS);
  }
  function generateAiOffersForUser(force){
    // Correção (2026-09-17, apontada pelo utilizador: "recebi zero propostas pelos meus
    // jogadores, o que é estranho"): esta função usava marketPeriodForDate(...)==="defeso" para
    // decidir se o mercado está aberto — mas essa função é um conceito antigo, fixo a Junho-Agosto
    // (ver os seus próprios comentários: "só serve a elegibilidade de pré-contratos" desde a
    // funcionalidade de mercado realista de 2026-09-14).
    // Segunda correção (2026-09-17, mesmo dia, apontada de novo pelo utilizador: "quando recebo as
    // propostas, deve aparecer um botão para poder responder... não estão a aparecer no separador
    // mercado, o que impossibilita a resposta"): state.inDefeso não é o sinal certo — é uma
    // bandeira CURTA, só para o ecrã de defeso, que desliga logo que essa transição de época
    // termina (finalizePreSeasonDefeso/finalizeNewSeasonTail), muito antes de a JANELA REAL de
    // inscrições fechar (registrationWindowOpenFor, 1 Ago-15 Out / 2-15 Jan — ver a funcionalidade
    // de mercado realista de 2026-09-14, "negociar é possível o ano inteiro"). O resto do mercado
    // (fee entre clubes, termos pessoais, empréstimos) já usa a janela real e continua a resolver-se
    // dia a dia muito depois de a época já ter começado — só esta função, a única que gera as
    // propostas manuais e com botão que o utilizador recebe pelos SEUS jogadores, tinha ficado presa
    // à bandeira curta: assim que o ecrã de defeso fechava (dias depois de a época arrancar), parava
    // de gerar propostas novas para sempre, e expirePendingAiOffers (chamada nesse mesmo instante)
    // apagava de imediato qualquer proposta ainda por responder — dando exatamente a sensação
    // reportada: a proposta chegou, mas o botão desapareceu e nunca mais voltou a aparecer nada no
    // Mercado. Passa a usar a janela real, tal como o resto do mercado.
    // 0.2.12: no arranque da carreira (1.º dia da época 1) não há propostas — só depois de carregar em "Continuar" pelo menos uma vez.
    if(state.season===1 && state.currentDate && isoDate(state.currentDate)===isoDate(seasonStartDate(1))) return;
    if(!state.userTeamId||!registrationWindowOpenFor(state.currentDate))return;
    const dayKey=isoDate(state.currentDate);if(!force&&state.lastAiOfferDate===dayKey)return;state.lastAiOfferDate=dayKey;
    const user=myTeam(),candidates=user.players.filter(p=>!p.emprestimo&&!p.__provisional&&!playerTransferLimitReached(p));
    // Etiqueta "transferível" (pedido do utilizador, 2026-09-11): jogadores que o próprio
    // utilizador assinalou como disponíveis, com um valor pedido, têm sempre prioridade absoluta
    // sobre o critério automático abaixo, e uma probabilidade de proposta mais alta — é o sinal
    // mais forte possível de interesse em negociar.
    const listed=candidates.filter(p=>p.transferListado);
    // 0.4.12: jogadores que o utilizador pôs na lista de empréstimos — os clubes interessados pedem-nos emprestados.
    const loanListed=candidates.filter(p=>p.emprestimoListado);
    let created=0;
    // 0.4.6 (pedido do utilizador: "ponho um jogador na lista e recebo ~40 propostas, de clubes
    // grandes: não é realista" / "não quero limites por limitar — o que não quero é o Benfica ou
    // outro grande interessado em jogadores de nível manifestamente insuficiente"): o problema não
    // era o número de propostas, era QUEM as fazia — qualquer clube propunha por qualquer jogador
    // de campo listado. Agora só propõe quem tem interesse desportivo (aiOfferPlayerFitsBuyer: o
    // jogador tem de ter nível para a rotação do clube proponente). Sem tetos artificiais: o
    // volume desce naturalmente porque a maioria dos clubes grandes deixa de ser elegível.
    // Ordem aleatória: antes a ordem fixa dos clubes dava sempre prioridade aos primeiros da lista.
    const aiOrder=Object.values(state.teams).filter(t=>t.id!==user.id&&!isMarketPassiveTeam(t));
    for(let i=aiOrder.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[aiOrder[i],aiOrder[j]]=[aiOrder[j],aiOrder[i]];}
    aiOrder.forEach(ai=>{
      if(created>=3)return;
      // "Transferências entre os 3 grandes devem ser raras" (pedido do utilizador, 2026-09-17):
      // aplica-se também quando é o PRÓPRIO utilizador um dos 3 grandes a receber a proposta de
      // outro dos 3 grandes — a esmagadora maioria das vezes nem chega a haver proposta.
      if(isBigThreeTransfer(user.id,ai.id)&&Math.random()>=BIG_THREE_TRANSFER_CHANCE)return;
      const need=aiSquadNeed(ai);
      const listedFit=listed.filter(p=>(!need||candidateMatchesNeed(p,need))&&!offerRecentlyRejectedByUser(ai.id,p.id)&&aiOfferPlayerFitsBuyer(p,ai,user))
        .sort((a,b)=>aiOfferTargetScore(b,ai,need)-aiOfferTargetScore(a,ai,need));
      const loanFit=loanListed.filter(p=>!p.transferListado&&(!need||candidateMatchesNeed(p,need))&&!offerRecentlyRejectedByUser(ai.id,p.id)&&!loanRefusalRecent(p,ai.id)&&aiOfferPlayerFitsBuyer(p,ai,user)&&canLoanPlayer(p,user,ai).ok)
        .sort((a,b)=>aiOfferTargetScore(b,ai,need)-aiOfferTargetScore(a,ai,need));
      // Sem jogador listado, a iniciativa é espontânea: um clube com carência real procura activamente
      // (5%/dia); um clube sem carência só aproveita oportunidades pontuais (0,8%/dia) e
      // faz uma abordagem de cada vez (arrefecimento por clube).
      const hasListed=!!(listedFit.length||loanFit.length);
      if(!hasListed && !force && aiRecentlyApproachedUser(ai,need)) return;
      const baseChance=force?.22:(need?.05:.008);
      const chance=hasListed?Math.min(.6,(force?.22:.08)*2.5):baseChance;
      if(Math.random()>chance)return;
      let pool=listedFit.length?listedFit:loanFit;
      if(!pool.length){
        pool=candidates.filter(p=>(!need||candidateMatchesNeed(p,need))&&!aiSystemCriticalityBlock(user,p)&&!offerRecentlyRejectedByUser(ai.id,p.id)&&aiOfferPlayerFitsBuyer(p,ai,user)&&aiOfferPlayerUpgradesBuyer(p,ai,user,need))
          .sort((a,b)=>aiOfferTargetScore(b,ai,need)-aiOfferTargetScore(a,ai,need));
      }
      // 0.4.14: "um jogador indispensável não recebe muitas propostas" (pedido anterior, Marco R)
      // nunca tinha sido cumprido na prática — só o preço subia, e na simulação com o Entroncamento
      // 54 das 56 propostas foram por Indispensáveis (num clube pequeno, os melhores jogadores são
      // todos Indispensáveis e dão o reforço mais óbvio a qualquer clube). Numa abordagem
      // espontânea (jogador não listado), os clubes só reparam num Indispensável/Titular importante
      // 1 vez em 5: tentam primeiro quem o treinador tem como rotação/suplente.
      if(!hasListed){
        const incluirImportantes=Math.random()<.2;
        if(!incluirImportantes){
          pool=pool.filter(p=>{ const e=effectivePlayerEstatuto(p,user); return e!=="Indispensável"&&e!=="Titular importante"; });
        }
      }
      const player=pool[0];if(!player)return;
      // Marco R (pedido do utilizador: "um jogador indispensável não recebe muitas propostas da
      // IA"): um jogador Indispensável/Titular importante para o utilizador quase nunca é alvo de
      // proposta séria — só passa se o valor oferecido ficar bem acima do mercado (prémio sorteado
      // por jogador, ver aiOfferStatusPremiumThreshold acima), e nunca por empréstimo (não faz
      // sentido pedir emprestado o jogador mais importante de alguém). A verificação financeira já
      // existente (aiRecruitmentFinanciallySafe, mais abaixo) filtra naturalmente os clubes sem
      // margem para pagar o prémio — não é preciso nenhuma verificação nova.
      const highStatusEstatuto = effectivePlayerEstatuto(player, user);
      const isHighStatus = highStatusEstatuto==="Indispensável" || highStatusEstatuto==="Titular importante";
      // Fase 16: só propõe empréstimo se o jogador for elegível E as dimensões dos clubes forem
      // compatíveis (canLoanPlayer já cobre os dois lados) — caso contrário, se quer o jogador,
      // propõe compra, como faria um clube "a sério" em vez de pedir emprestado sem sentido.
      const loanCheck = canLoanPlayer(player, user, ai);
      // Correção (2026-10-10, apontada pelo utilizador: "sempre que ponho um jogador na lista de
      // transferências só recebo pedidos de empréstimo"): um jogador colocado no mercado com valor
      // pedido está À VENDA — o interesse natural é em comprá-lo. Antes, bastava o jogador ser
      // elegível para empréstimo (a maioria é) para a proposta ser SEMPRE de empréstimo, ignorando
      // por completo o preço pedido. Agora, para um jogador listado, a proposta é de compra na
      // grande maioria dos casos (empréstimo só ocasional, ou quando o clube não tem margem
      // financeira para comprar).
      const listedForSale = !!(player.transferListado && player.valorPedido);
      // 0.4.12: um jogador só na lista de empréstimos nunca recebe proposta de compra — o utilizador não o pôs à venda.
      const loanOnlyListed = !!player.emprestimoListado && !listedForSale;
      const loanAllowed = loanCheck.ok && (!isHighStatus || !!player.emprestimoListado);
      let loan = loanAllowed && (loanOnlyListed || !listedForSale || Math.random()<(player.emprestimoListado?.55:.12));
      if(loanOnlyListed && !loan) return;
      // Correção (verificações pedidas pelo utilizador, 2026-09-13): "seria impensável o Termas
      // comprar o Diogo Duarte" — faltavam DUAS verificações que já existiam para empréstimos mas
      // nunca tinham sido aplicadas a compras: (a) o próprio jogador, com alguma reputação a mais
      // para a dimensão do clube comprador, nunca aceitaria (purchaseGapBlocked, 3º argumento
      // novo — mesma regra "gap<-18 && reputação>=35" já usada em canLoanPlayer); (b) o clube IA
      // proponente tinha mesmo dinheiro/margem salarial para pagar a proposta (nenhuma verificação
      // financeira existia nesta função — um clube pequeno podia propor comprar um jogador que
      // nunca conseguiria pagar).
      if(!loan && purchaseGapBlocked(user, ai, player)){
        if(listedForSale && loanAllowed) loan=true; else return;
      } // nem empréstimo nem compra fazem sentido para esta diferença de dimensão
      const askBase = (player.transferListado && player.valorPedido ? player.valorPedido : playerMarketValue(player,user)) * (isBigThreeTransfer(user.id,ai.id)?2:1) * (isHighStatus ? aiOfferStatusPremiumThreshold(player) : 1);
      let offer;
      if(loan){
        const lt=player.emprestimoListado?aiLoanOfferTerms(player,user,ai):null;
        offer={id:uid(),type:"emprestimo",fromTeamId:ai.id,toTeamId:user.id,playerId:player.id,salaryShare:lt?lt.share:50,papel:lt?lt.papel:(loanCheck.profile==="jovem"?"Titular":"Rotacao"),clausulas:empGerarClausulasIA(player,user,ai,loanCheck.profile),status:"pendente",date:dayKey};
      } else {
        // 0.4.16 (pedido do utilizador, Vasco da Gama: "faz sentido oferecer mais do que o clube está a
        // pedir quando é um jogador listado?" / "faz sentido alguém querer um jogador de OVR 6 que
        // vale 0 por 5000?"): a proposta era sempre o pedido ±15 %, por isso um terço das propostas
        // por um jogador à venda ficava ACIMA do preço pedido, e o pedido podia ser 30 vezes o valor
        // do jogador sem que isso mudasse nada. Um comprador não oferece mais do que o pedido, e
        // ancora a oferta no que o jogador vale para ele: o valor de mercado mais uma margem
        // desportiva (maior com carência de plantel). Se o pedido for muito superior a isso, a
        // proposta vem abaixo do pedido (é o utilizador que decide se aceita, contrapõe ou recusa).
        // Jogador não listado: mantém-se a abordagem em torno do valor de mercado.
        let value;
        if(listedForSale){
          // Pôr um jogador à venda NÃO o desvaloriza: o comprador avalia-o como avaliaria se ele não
          // estivesse listado (valor de mercado, com margem se lhe faz falta) e só o preço pedido
          // funciona como teto. Pedido razoável → oferece o pedido (às vezes tenta baixar um pouco);
          // pedido acima do que vale para ele → oferece o que lhe parece justo, abaixo do pedido.
          const mv=playerMarketValue(player,user);
          const avaliacao=mv*(need?1.5:1.15)*(isBigThreeTransfer(user.id,ai.id)?2:1)*(isHighStatus?aiOfferStatusPremiumThreshold(player):1)*(.9+Math.random()*.2);
          value=Math.min(player.valorPedido,Math.max(avaliacao,mv*.9));
          if(value>=player.valorPedido && Math.random()<.3) value*=(.9+Math.random()*.1);
        } else value=askBase*(.85+Math.random()*.3);
        const passo=value<2000?50:500;
        value=Math.max(listedForSale?Math.min(100,player.valorPedido):passo,Math.round(value/passo)*passo);
        const salary=Math.round(Math.max(expectedSalary(player,ai),player.contrato?.salarioMensal||0)*transferCareerPenalty(player,user,ai));
        const total=aiTotalRecruitmentCost(player,ai,"compras",value,salary);
        if(!aiRecruitmentFinanciallySafe(ai,total,value,salary)){
          if(!(listedForSale&&loanAllowed)) return; // este clube não tem margem financeira para pagar esta proposta
          loan=true; // sem margem para comprar, pede o jogador emprestado
        }
        if(!loan) offer={id:uid(),type:"compra",fromTeamId:ai.id,toTeamId:user.id,playerId:player.id,value,status:"pendente",date:dayKey};
      }
      if(loan && !offer) offer={id:uid(),type:"emprestimo",fromTeamId:ai.id,toTeamId:user.id,playerId:player.id,salaryShare:50,papel:loanCheck.profile==="jovem"?"Titular":"Rotacao",clausulas:empGerarClausulasIA(player,user,ai,loanCheck.profile),status:"pendente",date:dayKey};
      if(!state.aiOffers.some(o=>o.status==="pendente"&&o.playerId===player.id&&o.fromTeamId===ai.id)){
        state.aiOffers.push(offer);created++;ai.lastUserApproachDate=dayKey;
        // Avanço automático de vários dias (2026-09-16, pedido do utilizador): antes só o painel
        // do Mercado mostrava propostas recebidas — sem notícia, o avanço automático não tinha
        // como saber que chegou algo a decidir. Notícia dedicada, sempre sobre o clube do
        // utilizador (esta função só corre para `user=myTeam()`), a interromper o avanço.
        // Correção (2026-09-17, pedido do utilizador: "no email tem de aparecer os termos da
        // proposta e um caminho para poder responder"): a notícia dizia só QUE havia uma
        // proposta, nunca QUANTO nem O QUÊ, e não dava nenhuma forma de lá chegar a partir do
        // próprio e-mail — era preciso ir manualmente ao separador Mercado. Passa a incluir os
        // termos (mesmo texto já usado em renderAiOffersSection, para não haver dois textos
        // diferentes para a mesma proposta) e um botão que salta direto para lá, mesmo padrão
        // "news-open-..." já usado noutras notícias do mercado (ver contractNegOpenButtonHtml).
        const termos = loan ? `${offer.salaryShare}% do salário · ${ROLE_LABELS[offer.papel]||offer.papel} · ${empClausulasTexto(offer.clausulas)}` : fmtMoney(offer.value);
        pushNews(state.currentDate,`${teamLinkHtml(ai.id)} apresentou uma proposta de ${loan?"empréstimo":"compra"} por ${playerLinkHtml(user.id,player)}: <b>${termos}</b>. <button class="news-open-aioffer" data-offer="${offer.id}">Responder →</button>`,"proposta","Nova proposta recebida",{autoAdvanceStop:true, teamId:ai.id});
      }
    });
  }

  // ================= Fase 16: mercado IA-contra-IA =================
  // Um verdadeiro mercado de verão entre clubes controlados pela IA (sem envolver o utilizador):
  // cada clube com uma carência de plantel tenta resolvê-la, por ordem, através da equipa B,
  // depois jogadores livres, depois empréstimo de outro clube IA (só se as regras de elegibilidade
  // e compatibilidade de dimensão o permitirem), e por fim compra a outro clube IA. Corre uma
  // única vez por defeso — não há negociação diária nem repetida no mesmo clube/jogador, o que já
  // evita por construção os comportamentos circulares (mesmo jogador com várias propostas no
  // mesmo dia, transferências múltiplas do mesmo jogador na mesma janela).
  // Reage a carências criadas pelo próprio utilizador durante a janela de mercado em curso (ex.:
  // um empréstimo que deixou um clube com só 1 GR) — chamado mesmo antes de a época avançar, já
  // depois de o utilizador ter tido oportunidade de negociar. Sem guarda de idempotência (pode
  // correr mais do que uma vez por época): aiSquadNeed já evita negócios quando não há carência.
  // Calibração (revista a pedido do utilizador, 2026-09-13: "na primeira época também deve
  // poder haver empréstimos. as equipas com lacunas têm de comprar, pedir emprestado, ir buscar
  // ao free agent. e se isso gera lacunas, na outra equipa, devem reagir") — a 1ª época já não é
  // um caso especial: os clubes IA compram, pedem emprestado e vão ao mercado de livres desde o
  // início, tal como em qualquer outra época. O que evita transferências sem sentido não é uma
  // restrição por época, mas sim as proteções normais (aiRecruitmentFinanciallySafe e
  // purchaseGapBlocked, ver tryPurchase). Uma carência criada por esta passagem numa OUTRA equipa
  // (o "dador" que ficou a jeito) é resolvida na mesma transição de época, através de
  // processAiToAiMarketReactive (chamado em finalizeNewSeason), que corre exatamente a mesma
  // lógica sem qualquer restrição adicional.
  function runAiToAiMarketPass(dealsLog, movedThisPass){
    const aiClubs = Object.values(state.teams).filter(t=>!isUserControlledTeam(t) && !isMarketPassiveTeam(t));
    // As equipas B não "compram/vendem" por iniciativa própria (aiSquadNeed não corre para
    // elas), mas são uma fonte perfeitamente normal de empréstimo/compra para OUTROS clubes —
    // por isso entram no conjunto de onde se procuram candidatos, mesmo não entrando no
    // conjunto de clubes que procuram resolver as suas próprias carências.
    // Correção (verificação pedida pelo utilizador): ao contrário das equipas B, os clubes da
    // nuvem europeia NUNCA podem ser fonte de jogadores para outros clubes — "nunca entram no
    // mercado de transferências" foi uma decisão explícita, em qualquer direção. Excluídos
    // também deste "sourcePool" de dadores, não só do conjunto de clubes que procuram reforços.
    const sourcePool = Object.values(state.teams).filter(t=>!isUserControlledTeam(t) && !t.nuvemEuropeia && !t.selecaoNacional);
    aiClubs.sort((a,b)=>clubAppeal(b)-clubAppeal(a));
    // Calibração (encontrada quando o Benfica ficou com 8 jogadores numa só passagem): nada
    // impedia MUITOS clubes diferentes de escolherem o mesmo clube "dador" atrativo um a seguir
    // ao outro — cada transação individual passava a verificação de mínimos no momento em que
    // acontecia, mas a soma de várias transações "válidas" esvaziava o plantel na mesma
    // passagem. donorCounts limita quantas vezes um clube pode ser fonte de empréstimo/compra
    // nesta mesma passagem, independentemente de quem lhe pede — não conta promoções da própria
    // equipa B (isso é um movimento interno do clube, não um esvaziamento de um clube alheio).
    const donorCounts = new Map();
    // Índice de negociações pendentes construído uma única vez por passagem (ver
    // buildAiMarketPendingIndex, mais abaixo) — evita que cada candidato examinado, em cada
    // clube, volte a percorrer as listas inteiras de negociações pendentes.
    const pendingIndex = buildAiMarketPendingIndex();
    // Arrefecimento por clube (2026-09-17, pedido do utilizador: "continua a haver muitas
    // transferencias"): antes, TODOS os clubes de IA reavaliavam as suas carências TODOS os dias
    // (processAiToAiMarketDaily corre a partir de dailyConditionRecovery) — DONOR_CAP_PER_PASS só
    // limita quantas vezes um clube pode ser FONTE dentro de uma única passagem, nunca quantas
    // vezes tenta comprar ao longo da época. Um clube que já tentou preencher uma carência (com
    // sucesso ou sem êxito) só volta a ser reavaliado depois de AI_MARKET_COOLDOWN_DAYS dias,
    // exceto se algo relevante mudou entretanto — team.marketNeedDirty, marcado nos sítios que já
    // hoje abrem uma lacuna real de plantel: venda (applyAcceptedOffer), empréstimo de saída
    // (completeLoan), dispensa (releasePlayerToFreeAgency) e reforma (processRetirements). Não
    // toca em aiSquadNeed/aiRecruitmentFinanciallySafe (que já modelam "precisa E tem dinheiro")
    // nem em DONOR_CAP_PER_PASS — reduz só a FREQUÊNCIA com que cada clube tenta.
    const today = isoDate(state.currentDate||new Date());
    aiClubs.forEach(club=>{
      // Correção (pedido do utilizador, ver AI_MARKET_COOLDOWN_DAYS_FORA_JANELA acima): fora da
      // janela de inscrições, o arrefecimento só continua curto (6 dias) se houver uma das 3
      // razões raras — caso contrário passa a 21 dias, para reduzir drasticamente o volume de
      // "transferências" fora da altura em que, na realidade, os planteis quase não mudam.
      if(club.lastMarketAttemptDate && !club.marketNeedDirty){
        const daysSince=Math.round((new Date(today+"T00:00:00Z")-new Date(club.lastMarketAttemptDate+"T00:00:00Z"))/86400000);
        const need = aiSquadNeed(club);
        const dentroDaJanela = !!registrationWindowOpenFor(state.currentDate||new Date());
        const cooldown = (dentroDaJanela || !need || aiHasUrgentOutOfWindowReason(club, need))
          ? AI_MARKET_COOLDOWN_DAYS : AI_MARKET_COOLDOWN_DAYS_FORA_JANELA;
        if(daysSince<cooldown) return; // ainda em arrefecimento, nada relevante mudou
      }
      // Correção (pedido do utilizador: "às vezes vendem e não conseguem ir comprar pq os outros
      // clubes nem negoceiam"): antes, `attempted` ficava true mesmo que a única iteração deste
      // while falhasse logo (tryFillAiSquadNeed a devolver false, quebrando de imediato) — e a
      // linha final registava lastMarketAttemptDate=today e limpava marketNeedDirty de qualquer
      // forma. Resultado: um clube que vendia um jogador (o que marca marketNeedDirty=true, para
      // tentar repor de imediato) e falhava logo à primeira tentativa de reforço ficava com a
      // carência por resolver mas bloqueado até ao PRÓXIMO cooldown inteiro (6-21 dias), tal como se
      // tivesse tido sucesso. Passa a distinguir sucesso de falha: só entra em cooldown normal
      // quando teve sucesso ou já não tem carência; enquanto continuar "dirty" sem conseguir
      // resolver, tenta de novo já no dia seguinte (sem esperar pelo cooldown), até
      // AI_MARKET_DIRTY_RETRY_STREAK_MAX tentativas diárias seguidas, para nunca degenerar em
      // tentativas eternas para um clube estruturalmente incapaz de resolver a sua carência (ex.:
      // sem dinheiro, ou mesmo sem nenhum clube disposto a negociar nesse momento).
      const wasDirty = !!club.marketNeedDirty;
      let guard=0, succeeded=0;
      while(aiSquadNeed(club) && guard<5){
        const need = aiSquadNeed(club);
        if(!tryFillAiSquadNeed(club, need, aiClubs, movedThisPass, dealsLog, donorCounts, sourcePool, pendingIndex)) break;
        succeeded++; guard++;
      }
      const aindaComCarencia = !!aiSquadNeed(club);
      if(succeeded>0 || !aindaComCarencia){
        club.lastMarketAttemptDate=today; club.marketNeedDirty=false; club.marketDirtyFailStreak=0;
      } else if(wasDirty && (club.marketDirtyFailStreak||0) < AI_MARKET_DIRTY_RETRY_STREAK_MAX){
        // continua com a carência que motivou esta tentativa e não conseguiu resolvê-la agora — não
        // regista lastMarketAttemptDate nem limpa marketNeedDirty, para tentar de novo já amanhã sem
        // esperar pelo cooldown inteiro.
        club.marketDirtyFailStreak = (club.marketDirtyFailStreak||0)+1;
      } else {
        // esgotou as tentativas diárias seguidas sem sucesso (ou era só uma reavaliação periódica
        // normal, sem estar "dirty") — cai para o comportamento normal de cooldown.
        club.lastMarketAttemptDate=today; club.marketNeedDirty=false; club.marketDirtyFailStreak=0;
      }
    });
  }
  // Fase 2 do roadmap: a IA consulta o mercado mesmo quando o plantel já cumpre os mínimos.
  // Só contrata se houver melhoria concreta, rejuvenescimento justificável e margem financeira.
  function recordAiMarketDecision(team,player,type,reason,extra={}){
    if(!Array.isArray(state.marketDecisionHistory)) state.marketDecisionHistory=[];
    state.marketDecisionHistory.unshift({date:isoDate(state.currentDate||new Date()),season:state.season,teamId:team.id,playerId:player.id,type,reason,...extra});
  }
  function weakestComparablePlayer(team,candidate){
    const sameRole=team.players.filter(p=>p.pos===candidate.pos&&(candidate.pos==="GR"||p.linha===candidate.linha)&&!p.__provisional&&!p.emprestimo);
    return sameRole.sort((a,b)=>overall(a)-overall(b)||(b.age||0)-(a.age||0))[0]||null;
  }
  function activeFreeAgentUpgradeForClub(club,moved,dealsLog){
    if(isMarketPassiveTeam(club)||club.id===state.userTeamId) return false;
    initClubFinance(club);
    const ledger=aiRecruitmentLedger(club); if(ledger.entradas>=aiRecruitmentEntryLimit(club)) return false;
    const candidates=(state.freeAgents||[]).filter(p=>!moved.has(p.id)&&!(typeof scintReservado==="function"&&scintReservado(p))).map(p=>{
      const weak=weakestComparablePlayer(club,p); if(!weak)return null;
      const role=assignInitialRole(overall(p),p.age,p.potential,false),salary=freeAgentSalaryDemand(p,club,role);
      const qualityGain=overall(p)-overall(weak),ageGain=(weak.age||25)-(p.age||25),potentialGain=(p.potential||overall(p))-(weak.potential||overall(weak));
      const justified=qualityGain>=2||(qualityGain>=0&&ageGain>=5&&potentialGain>=2);
      const total=aiTotalRecruitmentCost(p,club,"livres",0,salary);
      if(!justified||!freeAgentCareerFit(p,club,role).ok||!aiRecruitmentFinanciallySafe(club,total,0,salary))return null;
      return {p,weak,role,salary,total,score:qualityGain*12+ageGain*2+potentialGain*3-aiCandidateStrategicScore(weak,club,{pos:p.pos,linha:p.linha},"livres",0,weak.contrato?.salarioMensal||0)*.02};
    }).filter(Boolean).sort((a,b)=>b.score-a.score);
    const chosen=candidates[0]; if(!chosen)return false;
    if(!canReleasePlayerFromTeam(club,chosen.weak).ok)return false;
    if(crisisSpendingBlock(club,"contratacao",chosen.salary,chosen.p))return false; // 2026-10-16: não dispensar se a contratação vai ser recusada
    if(!releasePlayerToFreeAgency(chosen.weak.id,club.id).ok)return false;
    if(!signFreeAgentToTeam(club,chosen.p,{papel:chosen.role,salarioMensal:chosen.salary,anos:randomRenewalContractYears()}))return false;
    moved.add(chosen.p.id); aiRegisterRecruitment(club,chosen.p,"livres",chosen.total);
    recordAiMarketDecision(club,chosen.p,"contratacao-livre","melhoria-ou-rejuvenescimento",{replacedPlayerId:chosen.weak.id,qualityGain:overall(chosen.p)-overall(chosen.weak),ageGain:(chosen.weak.age||0)-(chosen.p.age||0)});
    const upgradeText=`${teamLinkHtml(club.id)} contratou ${playerLinkHtml(club.id,chosen.p)} para substituir ${escapeHtml(chosen.weak.name)}.`;
    dealsLog.push(upgradeText);
    if(marketDealRelevantToUser(club)) pushNews(state.currentDate,upgradeText,"mercado",null,{teamId:club.id});
    return true;
  }
  function recoverInactiveForClub(club,moved,dealsLog){
    if(isMarketPassiveTeam(club)||club.id===state.userTeamId||!(state.inactivePlayers||[]).length)return false;
    const need=aiSquadNeed(club); if(!need)return false;
    const candidate=state.inactivePlayers.filter(p=>p.inactiveReason!=="abandono-precoce"&&p.age<38&&!moved.has(p.id)&&candidateMatchesNeed(p,need)&&aiCandidateQualityOk(p,club,false))
      .sort((a,b)=>aiRecruitmentScore(b,club,need,0)-aiRecruitmentScore(a,club,need,0))[0];
    if(!candidate)return false;
    const restored=JSON.parse(JSON.stringify(candidate)); delete restored.status; delete restored.inactiveReason; delete restored.inactiveSeason; delete restored.inactiveDate; delete restored.careerContext; delete restored.contractPrevious;
    const role=assignInitialRole(overall(restored),restored.age,restored.potential,false),salary=freeAgentSalaryDemand(restored,club,role);
    state.inactivePlayers=state.inactivePlayers.filter(p=>p.id!==candidate.id); state.freeAgents.push(restored);
    if(!signFreeAgentToTeam(club,restored,{papel:role,salarioMensal:salary,anos:randomRenewalContractYears()})){state.freeAgents=state.freeAgents.filter(p=>p.id!==restored.id);state.inactivePlayers.push(candidate);return false;}
    moved.add(restored.id); recordAiMarketDecision(club,restored,"reativacao","necessidade-de-plantel",{inactiveReason:candidate.inactiveReason});
    const reactivateText=`${teamLinkHtml(club.id)} reativou ${playerLinkHtml(club.id,restored)}.`;
    dealsLog.push(reactivateText);
    if(marketDealRelevantToUser(club)) pushNews(state.currentDate,reactivateText,"mercado",null,{teamId:club.id});
    return true;
  }
  function processAutomaticABPlanning(dealsLog, moved){
    Object.values(state.teams).filter(a=>a.equipaBId&&state.teams[a.equipaBId]&&!isUserControlledTeam(a)&&!isUserControlledTeam(a.equipaBId)).forEach(a=>{
      const b=state.teams[a.equipaBId];
      // Correção (pedido do utilizador, 2026-10-03: "estão jogadores a ser despromovidos e
      // promovidos logo a seguir em equipas da IA e que não fazem sentido") — esta função corre
      // sempre DEPOIS de runAiToAiMarketPass (chamada mais abaixo, em processAiToAiMarket), cujo
      // tryBTeam() pode ter acabado de promover um jogador da equipa B para esta mesma equipa A,
      // momentos antes, na mesma passagem — um jovem assim promovido fica, por definição,
      // não-titular e com 0 jogos na época nova, exactamente o perfil que este candidato procura,
      // e podia ser escolhido para descer de volta de imediato. `moved` (jogadores já envolvidos
      // nesta passagem) e `__promotedFromBSeason` (marca persistente, para o caso de
      // ensureBTeamMinimums correr depois, já fora desta passagem) protegem-no.
      const candidate=a.players.filter(p=>!p.emprestimo&&!p.titular&&p.age<=23&&!(moved&&moved.has(p.id))&&p.__promotedFromBSeason!==state.season&&(p.season.jogos||0)<=Math.max(2,Math.floor((state.currentRound||0)*.2))&&canReleasePlayerFromTeam(a,p).ok)
        .sort((x,y)=>(x.season.jogos||0)-(y.season.jogos||0)||overall(y)-overall(x))[0];
      if(!candidate||b.players.length>=20||!canAutomaticallyMovePlayer(a,b,candidate))return;
      a.players=a.players.filter(p=>p.id!==candidate.id);b.players.push(candidate);candidate.titular=false;
      const row={date:new Date(state.currentDate).toISOString(),season:state.season,playerId:candidate.id,player:candidate.name,from:a.name,to:b.name,fromId:a.id,toId:b.id,direction:"paraB",reason:"desenvolvimento-e-minutos",temporary:true,usageBefore:candidate.season.jogos||0,moral:0,satisfacao:0};
      state.internalTransferHistory.unshift(row);recordAiMarketDecision(a,candidate,"movimento-ab","desenvolvimento-e-minutos",{fromId:a.id,toId:b.id});
      // Correção (pedido do utilizador, 2026-10-03: "não podem aparecer notícias de despromoções
      // ou promoções de jogadores entre equipas A e B") — o movimento continua contabilizado em
      // dealsLog (para o resumo agregado "X movimento(s) registados", mais abaixo) e em
      // internalTransferHistory, só deixa de gerar uma notícia individual por jogador.
      dealsLog.push(`${candidate.name} desceu temporariamente de ${a.name} para ${b.name}.`);
    });
  }
  function processAiToAiMarket(){
    if(state.aiToAiMarketProcessedSeason===state.season) return;
    const dealsLog = [];
    const moved=new Set();
    runAiToAiMarketPass(dealsLog, moved);
    const aiClubs=Object.values(state.teams).filter(t=>t.id!==state.userTeamId&&!isMarketPassiveTeam(t)).sort((a,b)=>clubAppeal(b)-clubAppeal(a));
    aiClubs.forEach(club=>{ if(!recoverInactiveForClub(club,moved,dealsLog)) activeFreeAgentUpgradeForClub(club,moved,dealsLog); });
    processAutomaticABPlanning(dealsLog, moved);
    if(dealsLog.length) pushNews(state.currentDate, `Mercado de verão entre clubes: ${dealsLog.length} movimento(s) registados fora do teu clube.`, "mercado");
    state.aiToAiMarketProcessedSeason = state.season;
  }
  function processAiToAiMarketReactive(){
    const dealsLog = [];
    runAiToAiMarketPass(dealsLog, new Set());
    if(dealsLog.length) pushNews(state.currentDate, `Reação do mercado: ${dealsLog.length} clube(s) responderam a saídas recentes de jogadores.`, "mercado");
    return dealsLog.length;
  }
  // Passagem diária do mercado IA-contra-IA (2026-09-14): com compras, jogadores livres e
  // empréstimos entre clubes de IA agora a demorar dias a fechar-se (tryPurchase/tryFreeAgent/
  // tryLoan, mais acima, já não movem ninguém de imediato), uma única passagem no início do
  // defeso deixou de bastar — cada clube de IA precisa de voltar a tentar preencher carências
  // ainda por resolver, e de reagir a contrapropostas de fee ainda em aberto, à medida que os
  // dias passam. Chamada a partir de dailyConditionRecovery (09-fluxo-epoca.js), o mesmo ponto
  // único de avanço de dia que já resolve as negociações pendentes.
  function processAiToAiMarketDaily(){
    runAiToAiMarketPass([], new Set());
  }
  const DONOR_CAP_PER_PASS = 2; // um clube só pode ser fonte de empréstimo/compra 2 vezes por passagem
  const AI_MARKET_COOLDOWN_DAYS = 6; // dias de arrefecimento entre tentativas do mesmo clube (ver runAiToAiMarketPass)
  const AI_MARKET_DIRTY_RETRY_STREAK_MAX = 4; // tentativas diárias seguidas após uma venda sem sucesso, antes de cair para o cooldown normal (ver runAiToAiMarketPass)
  // Correção (pedido do utilizador: "estão a acontecer demasiadas transferências durante o ano
  // (depois de 15 outubro)... os planteis não são quase nada alterados durante a época, a não ser
  // que haja uma carência muito evidente, uma lesão de longa duração (rara), necessidade de dar
  // volta a resultados, ou cansaço"): fora da janela de inscrições, um clube de IA só devia voltar
  // a tentar reforçar-se com esta frequência curta (6 dias) numa dessas 3 razões raras — fora
  // delas, passa a esperar AI_MARKET_COOLDOWN_DAYS_FORA_JANELA dias. A carência estrutural em si
  // (aiSquadNeed) não muda — continua a ser sempre avaliada; isto só reduz a FREQUÊNCIA com que um
  // clube sem nenhuma dessas razões volta a tentar preenchê-la fora da janela.
  const AI_MARKET_COOLDOWN_DAYS_FORA_JANELA = 21;
  const AI_LONG_INJURY_DAYS_THRESHOLD = 61; // alinhado com o balde "longa" de GRAVE_INJURY_DURATION_BUCKETS (~2-6 meses)
  const AI_BAD_RUN_LOSSES_IN_LAST5 = 4; // 4 ou 5 derrotas nos últimos 5 jogos = "dar a volta a maus resultados"
  const AI_FATIGUE_AVG_CONDITION_THRESHOLD = 65; // condição média do plantel de campo abaixo disto = "cansaço"
  // Verifica se o clube tem uma das 3 razões raras que o utilizador considera válidas para ir ao
  // mercado fora da janela de inscrições (a 4ª razão, carência muito evidente, já é o que
  // aiSquadNeed deteta — sempre válida, sem precisar de alteração). Só a razão relacionada com a
  // carência em falta (need) conta para a lesão longa — não faz sentido reforçar a posição X por
  // ter um lesionado de longa duração na posição Y.
  function aiHasUrgentOutOfWindowReason(club, need){
    if(club.players.some(p => candidateMatchesNeed(p, need) &&
       (p.diasLesao||0) >= AI_LONG_INJURY_DAYS_THRESHOLD &&
       p.lesaoInfo && p.lesaoInfo.gravidade==="grave")) return true;
    const form = (club.recentResults||[]).slice(-5);
    if(form.length>=5 && form.filter(r=>r==="D").length>=AI_BAD_RUN_LOSSES_IN_LAST5) return true;
    const outfield = club.players.filter(p=>p.pos==="J");
    if(outfield.length){
      const avgCond = outfield.reduce((s,p)=>s+(p.condicao!=null?p.condicao:100),0)/outfield.length;
      if(avgCond < AI_FATIGUE_AVG_CONDITION_THRESHOLD) return true;
    }
    return false;
  }
  // Marco S (pedido do utilizador: "também deve ser criada uma lista de transferências... a IA
  // pode por jogadores à venda fora da janela... a IA tem de fazer uma gestão contínua e olhar
  // para o futuro"): os clubes de IA passam a rever periodicamente (cooldown jitterado por clube,
  // o ano inteiro, não só na janela de inscrições) a própria lista de transferências — descer
  // ligeiramente o preço de quem ainda não teve comprador, desmarcar quem já não devia estar à
  // venda (a situação mudou), e considerar no máximo um novo candidato por revisão.
  const AI_LISTING_REVIEW_COOLDOWN_MIN_DAYS = 5;
  const AI_LISTING_REVIEW_COOLDOWN_MAX_DAYS = 9;
  const AI_LISTING_PRICE_DECAY = 0.96; // -4% a cada revisão sem comprador
  const AI_LISTING_PRICE_FLOOR_RATIO = 0.90; // nunca desce abaixo de 90% do valor de mercado
  const AI_LISTING_SAFETY_MARGIN = 1; // margem de segurança por cima dos pisos de convocatória
  function reviewAllAiTransferListings(){
    Object.values(state.teams).filter(t=>!isUserControlledTeam(t) && !t.nuvemEuropeia && !t.selecaoNacional && !isMarketPassiveTeam(t)).forEach(reviewAiTransferListing);
    if(typeof reviewAllAiLoanListings==="function") reviewAllAiLoanListings(); // 0.4.12
  }
  function aiListingReviewCooldownDays(club){
    return seededRnd(makeSeededRng(`${club.id}|listagem-cooldown|${state.season||1}`), AI_LISTING_REVIEW_COOLDOWN_MIN_DAYS, AI_LISTING_REVIEW_COOLDOWN_MAX_DAYS);
  }
  // Um jogador já listado deixa de dever continuar à venda quando a situação do clube mudou desde
  // que foi colocado no mercado: já não há margem estrutural para o vender (canReleasePlayerFromTeam),
  // ou apareceu entretanto uma lesão grave de longa duração na mesma posição (o plantel precisa
  // dele de volta).
  function aiShouldKeepListed(p, club){
    if(!canReleasePlayerFromTeam(club, p).ok) return false;
    const graveInjuryInPos = club.players.some(o => o.id!==p.id && o.pos===p.pos &&
      !playerAvailableForMatch(o) && (o.diasLesao||0)>=AI_LONG_INJURY_DAYS_THRESHOLD &&
      o.lesaoInfo && o.lesaoInfo.gravidade==="grave");
    return !graveInjuryInPos;
  }
  // Escolhe (no máximo) um novo candidato a listar nesta revisão: joga pouco, tem OVR abaixo da
  // média do plantel na posição, ou é jovem sem margem de crescimento relevante — sempre com uma
  // margem de segurança por cima dos pisos estruturais já existentes (nunca esvaziar uma posição).
  // Um clube financeiramente em risco é mais permissivo (pode listar quem normalmente guardaria).
  function aiPickTransferListingCandidate(club){
    const pool = club.players.filter(p=>
      !p.transferListado && !p.emprestimo && !p.__provisional && !p.titular &&
      playerAvailableForMatch(p) && isSquadSurplus(p, club) && canReleasePlayerFromTeam(club, p).ok);
    if(!pool.length) return null;
    const eligible = pool.filter(p=>{
      const samePos = club.players.filter(o=>o.pos===p.pos);
      const neededCount = p.pos==="GR" ? CONVOCATORIA_MAX_GR : CONVOCATORIA_MAX_J;
      return samePos.length >= neededCount + AI_LISTING_SAFETY_MARGIN;
    });
    if(!eligible.length) return null;
    const risco = wageHealthTier(wageToBudgetRatio(club))==="risco";
    const posAvgOvr = {};
    ["GR","J"].forEach(pos=>{
      const grp = club.players.filter(p=>p.pos===pos);
      posAvgOvr[pos] = grp.length ? avg(grp.map(overall)) : 14;
    });
    const scored = eligible.map(p=>{
      const usage = p.season?.jogos||0;
      const belowAvg = overall(p) < posAvgOvr[p.pos];
      const semPotencialRelevante = p.age<=23 && ((p.potential||overall(p))-overall(p))<=1;
      let score = clamp(8-usage, 0, 8) + (belowAvg?4:0) + (semPotencialRelevante?3:0);
      return {p, score};
    }).sort((a,b)=>b.score-a.score);
    const best = scored.find(s=>risco || s.score>0);
    return best ? best.p : null;
  }
  function reviewAiTransferListing(club){
    const today = isoDate(state.currentDate||new Date());
    if(club.lastListingReviewDate){
      const dias = (new Date(today+"T00:00:00Z") - new Date(club.lastListingReviewDate+"T00:00:00Z"))/86400000;
      if(dias < aiListingReviewCooldownDays(club)) return;
    }
    club.lastListingReviewDate = today;
    club.players.filter(p=>p.transferListado && p.valorPedido).forEach(p=>{
      const floor = Math.round(playerMarketValue(p, club) * AI_LISTING_PRICE_FLOOR_RATIO);
      p.valorPedido = Math.max(floor, Math.round(p.valorPedido * AI_LISTING_PRICE_DECAY));
    });
    club.players.filter(p=>p.transferListado).forEach(p=>{
      if(!aiShouldKeepListed(p, club)){ p.transferListado=false; p.valorPedido=null; }
    });
    const candidate = aiPickTransferListingCandidate(club);
    if(candidate){
      const risco = wageHealthTier(wageToBudgetRatio(club))==="risco";
      const standout = playerSquadImportance(candidate, club).score>=80;
      const jitterRange = (standout && risco) ? [1.4,1.6] : [0.95,1.15];
      const jitter = seededRndFloat(makeSeededRng(`${candidate.id}|listagem-preco|${today}`), jitterRange[0], jitterRange[1]);
      candidate.transferListado = true;
      candidate.valorPedido = Math.max(500, Math.round(playerMarketValue(candidate, club) * jitter / 500) * 500);
    }
  }
  // Correção (pedido do utilizador: "recebo imensas propostas da ia por jogadores meus, incluindo
  // propostas seguidas da mesma equipa, depois de ter recusado"): generateAiOffersForUser só evitava
  // duplicar propostas PENDENTES do mesmo par (clube, jogador) — uma vez recusada, nada impedia o
  // mesmo clube de voltar a propor pelo mesmo jogador já no dia seguinte, e como a pontuação de
  // interesse (aiOfferTargetScore) é determinística por clube, o candidato escolhido tende a ser
  // sempre o mesmo. Passa a haver um período de "arrefecimento" de 14 dias por par (clube, jogador)
  // depois de uma recusa explícita do utilizador — não impede OUTRO clube de propor pelo mesmo
  // jogador, nem o mesmo clube de propor por OUTRO jogador.
  const AI_OFFER_REJECTION_COOLDOWN_DAYS = 14;
  function offerRecentlyRejectedByUser(fromTeamId, playerId){
    const hoje = state.currentDate||new Date();
    return (state.aiOffers||[]).some(o => o.fromTeamId===fromTeamId && o.playerId===playerId &&
      o.status==="recusada" && o.rejectedDate &&
      (new Date(isoDate(hoje)+"T00:00:00Z") - new Date(o.rejectedDate+"T00:00:00Z"))/86400000 < AI_OFFER_REJECTION_COOLDOWN_DAYS);
  }
  // Estratégia financeira do mercado IA:
  // clubes estáveis tentam primeiro comprar; depois equipa B, jogador livre e empréstimo.
  // Clubes sem margem financeira mantêm uma estratégia prudente, começando por soluções internas.
  function isFinanciallyStableForPurchase(team){
    initClubFinance(team);
    const f=team.financeiro;
    const wageBill=monthlyWageBill(team);
    const reserve=Math.max(wageBill*3, financeConfig(team).homeCost*4, 15000);
    return (f.divida||0)===0 && f.saldo>reserve && f.orcamentoTransferencias>0 && wageToBudgetRatio(team)<=0.82;
  }
  function aiRecruitmentMinimumOverall(team){
    const senior=team.players.filter(p=>!p.__provisional).map(overall).sort((a,b)=>b-a);
    if(!senior.length) return 5;
    const reference=avg(senior.slice(0,Math.min(8,senior.length)));
    const divisionFloor=PLAYOFF_DIVISION_CONFIG[team.divisaoAtual]?10:isSecondTierDivision(team.divisaoAtual)?7:5;
    const teamRep=normalizeClubReputation(team.reputacao, team);
    const reputationFloor=teamRep>=90?12:teamRep>=75?10:teamRep>=55?7:5;
    return Math.max(divisionFloor,reputationFloor,Math.floor(reference-3));
  }
  function aiCandidateQualityOk(player,team,fromB){
    const minimum=aiRecruitmentMinimumOverall(team);
    const current=overall(player);
    if(current>=minimum) return true;
    // Um jovem da própria equipa B pode subir como aposta de desenvolvimento, mas só quando
    // o potencial o aproxima realmente do nível exigido pelo plantel principal.
    return !!fromB && player.age<=21 && player.potential>=minimum-1 && current>=minimum-3;
  }
  function aiRecruitmentScore(player,team,need,value){
    const current=overall(player), age=player.age||25, potential=player.potential!=null?player.potential:current;
    const tactical=need==="CONSTRUTOR"&&playerProfile(player)==="construtor"?8:need==="AVC"&&player.linha==="Avancado"?6:3;
    const development=age<=23?Math.max(0,potential-current)*3:0;
    const ageFit=age<=28?6:age<=32?2:-Math.max(0,age-32)*2;
    const affordability=value?Math.max(-12,8-value/Math.max(1,team.financeiro.orcamentoTransferencias)*8):4;
    return current*8+development+ageFit+tactical+affordability;
  }
  function aiRecruitmentWindowKey(){return `${state.season}|${state.inDefeso?"defeso":"reativo"}`;}
  function aiRecruitmentLedger(team){
    const key=aiRecruitmentWindowKey();
    if(!team.aiRecruitmentLedger||team.aiRecruitmentLedger.key!==key)team.aiRecruitmentLedger={key,entradas:0,compras:0,livres:0,emprestimos:0,promocoesB:0,totalComprometido:0,playerIds:[]};
    return team.aiRecruitmentLedger;
  }
  function aiRecruitmentEntryLimit(team){
    const shortage=Math.max(0,2-team.players.filter(p=>p.pos==="GR").length)+Math.max(0,9-team.players.filter(p=>p.pos==="J").length);
    return clamp(2+shortage,2,5);
  }
  function aiRegisterRecruitment(team,player,type,totalCost){
    const l=aiRecruitmentLedger(team);l.entradas++;l[type]=(l[type]||0)+1;l.totalComprometido+=Math.round(totalCost||0);if(!l.playerIds.includes(player.id))l.playerIds.push(player.id);
    player.aiRecruitmentDecision={season:state.season,teamId:team.id,type,totalCost:Math.round(totalCost||0),need:aiSquadNeed(team)||null};
  }
  function aiContractYearsFor(player){return player.age>=33?1:player.age<=23?3:2;}
  function aiTotalRecruitmentCost(player,team,type,fee,salary){
    const years=aiContractYearsFor(player),wage=salary||freeAgentSalaryDemand(player,team,assignInitialRole(overall(player),player.age,player.potential,false));
    return Math.round((fee||0)+wage*12*years);
  }
  function aiSquadUpgradeValue(player,team,need){
    const relevant=team.players.filter(p=>candidateMatchesNeed(p,need)).map(overall).sort((a,b)=>b-a);
    const benchmark=relevant.length?relevant[Math.min(relevant.length-1,need==="GR"?1:Math.min(4,relevant.length-1))]:aiRecruitmentMinimumOverall(team);
    return overall(player)-benchmark;
  }
  function aiRecruitmentFinanciallySafe(team,totalCost,fee,monthlySalary){initClubFinance(team);const f=team.financeiro,st=financialState(team),policy=economicPolicy(team,monthlySalary,fee);if(st.level>=3&&fee>0)return false;if(!policy.canIncreaseWages||!policy.canPayFee)return false;if(monthlyWageBill(team)+monthlySalary>f.limiteSalarial*(st.level>=2?.82:.90))return false;const annualRoom=Math.max(0,(policy.income-policy.wages-monthlyStructureCost(team))*12);return totalCost<=Math.max(annualRoom,Math.min(f.orcamentoTransferencias||0,policy.available));}
  function aiCandidateStrategicScore(player,team,need,type,fee,salary){
    const quality=overall(player),potential=player.potential!=null?player.potential:quality,age=player.age||25,upgrade=aiSquadUpgradeValue(player,team,need);
    const tactical=need==="CONSTRUTOR"&&playerProfile(player)==="construtor"?14:need==="AVC"&&player.linha==="Avancado"?12:6;
    let development=age<=23?Math.max(0,potential-quality)*4:0,ageFit=age<=28?8:age<=32?3:-Math.max(0,age-32)*2;
    const total=aiTotalRecruitmentCost(player,team,type,fee,salary);
    let costPenalty=total/Math.max(1000,financeRecurringIncome(team)*12)*12;
    const career=type==="livres"?freeAgentCareerFit(player,team,assignInitialRole(quality,age,potential,false)).score*.35:0;
    // Staff — Treinadores (Fase 2, 2026-09-22, pedido do utilizador: "se compram este ou aquele
    // jogador"): o perfil de quem comanda o clube (o próprio gestor no clube do utilizador, o
    // treinador da IA em qualquer outro — ver activeCoachingStats, 08c-staff-treinadores.js)
    // inclina o TIPO de reforço perseguido, sem inverter a lógica de base — upgrade/tactical
    // continuam a decidir se o jogador sequer serve; isto só pesa juventude/experiência, ambição
    // e prudência financeira relativas entre candidatos que já fazem sentido.
    const coach=activeCoachingStats(team);
    if(coach){
      const youthBias=((coach.prefJuventude!=null?coach.prefJuventude:10)-10)/10; // -1 experiência .. +1 juventude
      development*=(1+youthBias*0.6);
      if(age>=29) ageFit-=youthBias*6; // prefere experiência (youthBias<0) vira bónus para jogadores mais velhos
      const ambitionBias=((coach.ambicaoNegocial!=null?coach.ambicaoNegocial:10)-10)/10;
      const prudenceBias=((coach.prudenciaFinanceira!=null?coach.prudenciaFinanceira:10)-10)/10;
      costPenalty*=clamp((1-ambitionBias*0.3)*(1+prudenceBias*0.4),0.4,1.8);
    }
    return quality*9+upgrade*10+tactical+development+ageFit+career-costPenalty;
  }
  // Jitter pequeno na pontuação de candidatos do mercado (2026-09-17, pedido do utilizador: "as
  // transferencias estao a repetir-se bastante cada vez que inicio o jogo"). Antes desta correção,
  // a escolha de candidato em tryPurchase/tryBTeam/tryFreeAgent/tryLoan era sempre
  // `.sort(score)[0]` — puramente determinística — sobre plantéis placeholder também 100%
  // determinísticos (makeSeededRng(id+"|"+nome), sem Math.random() nenhum). Estado inicial
  // idêntico + seleção sempre igual = quase os mesmos negócios em TODAS as carreiras novas.
  // state.gameSeed (gerado uma única vez por carreira em chooseClub, com Math.random()) entra
  // agora no desempate entre candidatos próximos, sem inverter escolhas claramente melhores — a
  // magnitude (±18 pontos) é pequena face à escala normal das diferenças de pontuação entre
  // candidatos bem distintos (tipicamente dezenas a centenas de pontos). Continua tudo
  // determinístico DENTRO da mesma carreira: mesma semente, mesmo dia, mesmo jogador ⇒ sempre o
  // mesmo jitter (um replay ou diagnóstico do mesmo save produz sempre o mesmo resultado).
  const AI_CANDIDATE_SCORE_JITTER = 18;
  function aiCandidateScoreJitter(playerId, extraKey){
    if(!state.gameSeed) return 0; // saves antigos sem gameSeed (ver migrateSaveObject) — sem jitter, comportamento antigo preservado
    const rng=makeSeededRng(`ai-candidate-jitter:${state.gameSeed}:${playerId}:${extraKey||""}:${isoDate(state.currentDate||new Date())}`);
    return seededRndFloat(rng,-AI_CANDIDATE_SCORE_JITTER,AI_CANDIDATE_SCORE_JITTER);
  }

  // Mercado IA-contra-IA com demora (2026-09-14, pedido do utilizador, reforçado por duas vezes:
  // "IA também tem de demorar a negociar entre eles e comigo"). Um jogador com QUALQUER negociação
  // pendente (fee entre clubes, termos pessoais ou empréstimo, de qualquer clube contra qualquer
  // outro) fica indisponível para novas propostas até essa negociação se resolver — evita que o
  // mesmo jogador receba propostas simultâneas de vários clubes de IA sem noção de qual "ganha"
  // (mesma preocupação já identificada no plano desta funcionalidade).
  // Correção de desempenho (2026-09-14, reportado pelo utilizador: "o jogo está lento cada vez
  // que se carrega para avançar 1 dia"): playerHasPendingDeal e aiPendingNegotiationCount eram
  // chamadas, sem qualquer cache, uma vez por CANDIDATO examinado (tryPurchase/tryFreeAgent/
  // tryLoan, mais abaixo) — cada chamada percorria de novo as 3 listas inteiras de negociações
  // pendentes (transferNegotiations/contractNegotiations/loanNegotiations), que só crescem ao
  // longo da carreira (só se apaga uma sessão quando o negócio FECHA, nunca quando é recusado ou
  // fica só à espera). Isto era razoável quando o mercado IA-contra-IA corria uma única vez por
  // época; agora que processAiToAiMarketDaily corre todos os dias, o mesmo custo repetia-se por
  // cada jogador de cada clube examinado, todos os dias. buildAiMarketPendingIndex constrói uma
  // única vez, por chamada a runAiToAiMarketPass, um Set/Map já resumido — playerHasPendingDeal e
  // aiPendingNegotiationCount passam a consultá-lo em O(1) quando lhes é passado. Sem o índice
  // (ex.: chamadas diretas via window.__HM2027_TEST__), mantêm exatamente o comportamento antigo,
  // sem qualquer alteração de resultado — é só uma otimização, não uma mudança de regras.
  function buildAiMarketPendingIndex(){
    const playerIds = new Set();
    const pendingCountByTeam = new Map();
    const bump = teamId => { if(teamId) pendingCountByTeam.set(teamId, (pendingCountByTeam.get(teamId)||0)+1); };
    if(state.transferNegotiations) Object.values(state.transferNegotiations).forEach(s=>{
      if(!s || s.estado!=="pendente") return;
      playerIds.add(s.playerId);
      if(s.aiMeta) bump(s.toTeamId);
    });
    if(state.contractNegotiations) Object.values(state.contractNegotiations).forEach(s=>{
      if(!s || !s.aguardaResposta) return;
      playerIds.add(s.playerId);
      if(s.aiMeta) bump(s.toTeamId);
    });
    if(state.loanNegotiations) Object.values(state.loanNegotiations).forEach(s=>{
      if(!s || s.estado!=="pendente") return;
      playerIds.add(s.playerId);
      if(s.aiMeta) bump(s.destinationId);
    });
    return { playerIds, pendingCountByTeam };
  }
  function playerHasPendingDeal(player, index){
    if(!player) return false;
    if(player.pendingTransferHold) return true;
    if(player.experiencia && !player.experiencia.concluida) return true; // à experiência no clube do utilizador (08h-experiencia.js)
    if(index) return index.playerIds.has(player.id);
    if(state.transferNegotiations && Object.values(state.transferNegotiations).some(s=>s&&s.estado==="pendente"&&s.playerId===player.id)) return true;
    if(state.contractNegotiations && Object.values(state.contractNegotiations).some(s=>s&&s.aguardaResposta&&s.playerId===player.id)) return true;
    if(state.loanNegotiations && Object.values(state.loanNegotiations).some(s=>s&&s.estado==="pendente"&&s.playerId===player.id)) return true;
    return false;
  }
  // Antes de as negociações demorarem dias, aiRecruitmentLedger.entradas (incrementado só quando
  // um negócio se FECHA) já limitava quantas contratações um clube de IA completa por época. Com
  // as negociações agora a demorar 1-4 dias por ronda (e o próprio mercado a correr todos os dias,
  // não só uma vez no defeso), esse limite deixaria de proteger enquanto os negócios ainda estão
  // pendentes — um clube podia abrir dezenas de negociações simultâneas antes de a primeira
  // fechar. Conta também as que já estão a decorrer (fee ainda em aberto ou termos pessoais à
  // espera de resposta) para o mesmo teto.
  function aiPendingNegotiationCount(club, index){
    if(index) return index.pendingCountByTeam.get(club.id)||0;
    let n=0;
    if(state.transferNegotiations) n+=Object.values(state.transferNegotiations).filter(s=>s&&s.estado==="pendente"&&s.aiMeta&&s.toTeamId===club.id).length;
    if(state.contractNegotiations) n+=Object.values(state.contractNegotiations).filter(s=>s&&s.aguardaResposta&&s.aiMeta&&s.toTeamId===club.id).length;
    if(state.loanNegotiations) n+=Object.values(state.loanNegotiations).filter(s=>s&&s.estado==="pendente"&&s.aiMeta&&s.destinationId===club.id).length;
    return n;
  }

  function tryFillAiSquadNeed(club, need, aiClubs, movedThisPass, dealsLog, donorCounts, sourcePool, pendingIndex){
    const pool=sourcePool||aiClubs;
    initClubFinance(club);
    const ledger=aiRecruitmentLedger(club),entryLimit=aiRecruitmentEntryLimit(club);
    if(ledger.entradas+aiPendingNegotiationCount(club, pendingIndex)>=entryLimit)return false;
    const stable=isFinanciallyStableForPurchase(club);
    // markNegotiationOpened: mantém pendingIndex (quando existe) atualizado com as negociações
    // que ESTE clube acabou de abrir NESTA MESMA passagem (ver buildAiMarketPendingIndex e o
    // guard<5 em runAiToAiMarketPass, que pode chamar esta função várias vezes seguidas para o
    // mesmo clube no mesmo dia) — sem isto, aiPendingNegotiationCount ficaria parado no valor de
    // início do dia até à passagem seguinte, deixando abrir mais negociações do que
    // aiRecruitmentEntryLimit permite dentro do mesmo dia. Não altera em nada o comportamento
    // quando pendingIndex não é passado (chamadas diretas de teste).
    function markNegotiationOpened(playerId){
      if(!pendingIndex) return;
      pendingIndex.playerIds.add(playerId);
      pendingIndex.pendingCountByTeam.set(club.id, (pendingIndex.pendingCountByTeam.get(club.id)||0)+1);
    }

    // Compra entre clubes de IA (2026-09-14, pedido do utilizador: "IA também tem de demorar a
    // negociar entre eles"). Já não move o jogador nem mexe em finanças diretamente — inicia (ou
    // continua) a mesma negociação de fee + termos pessoais em duas fases usada pelo utilizador
    // (negotiateWithClub, depois proposeContract), com a mesma demora de 1-4 dias por ronda. O
    // negócio só se concretiza mais tarde, quando resolvePendingContractNegotiations aceitar os
    // termos pessoais e chamar applyAcceptedOffer — nesse momento é que a ficha de recrutamento
    // (aiRegisterRecruitment) e as finanças são atualizadas, não aqui.
    function tryPurchase(){
      // Nota (2026-09-13): as transferências "impossíveis" reportadas pelo utilizador (Benfica a
      // vender o Zé Miranda/Nil Roca à OK Liga por uma fração do que valeriam, OC Barcelos a
      // vender o Luís Belchior ao CH Caldes) não eram um problema de "compras na 1ª época" — eram
      // compras sem qualquer verificação financeira nem de bom senso desportivo. Isso está
      // corrigido em purchaseGapBlocked (jogador de reputação alta não desce de dimensão de
      // clube) e em aiRecruitmentFinanciallySafe (o comprador tem mesmo de ter capacidade para
      // pagar) — sem qualquer restrição adicional por época.
      const reserve=Math.max(monthlyWageBill(club)*3,financeConfig(club).homeCost*4,15000);
      // "Raras": mesmo antes de chegar ao preço a dobrar (clubTransferDemand), um clube dos 3
      // grandes quase nunca sequer TENTA comprar a outro dos 3 grandes — só ~8% das vezes chega a
      // considerar a hipótese, o resto do tempo nem entra no leque de candidatos desta passagem.
      const candidates=pool.filter(other=>other.id!==club.id&&(donorCounts.get(other.id)||0)<DONOR_CAP_PER_PASS&&!purchaseGapBlocked(other,club)&&(!isBigThreeTransfer(other.id,club.id)||Math.random()<BIG_THREE_TRANSFER_CHANCE))
        .flatMap(other=>other.players.filter(player=>candidateMatchesNeed(player,need)&&!player.emprestimo&&!movedThisPass.has(player.id)&&!playerHasPendingDeal(player, pendingIndex)&&!playerTransferLimitReached(player)&& (playerSquadImportance(player,other).score<80||player.age<=23) && !aiSystemCriticalityBlock(other,player)&&aiCandidateQualityOk(player,club,false)&&!purchaseGapBlocked(other,club,player))
          .map(player=>{const value=playerMarketValue(player,other);
            // O jogador só assina por um clube claramente pior se for compensado com um salário
            // bem mais alto — mesma penalização (transferCareerPenalty) já usada quando é o
            // utilizador a negociar um contrato pessoal (contractDemand). Sem isto, o "salário
            // esperado" genérico não refletia a queda de dimensão do clube, e o teste de
            // sustentabilidade financeira (aiRecruitmentFinanciallySafe, mais abaixo) acabava por
            // deixar passar compras pouco realistas a clubes bem maiores.
            const baseSalary=Math.max(expectedSalary(player,club),player.contrato?.salarioMensal||0);
            const salary=Math.round(baseSalary*transferCareerPenalty(player,other,club));
            const total=aiTotalRecruitmentCost(player,club,"compras",value,salary);return {other,player,value,salary,total};}))
        .filter(c=>c.value<=club.financeiro.orcamentoTransferencias&&c.value<=club.financeiro.saldo-reserve&&canReleasePlayerFromTeam(c.other,c.player).ok&&!clubSaleRefusal(c.player,c.other,club,c.value)&&aiSquadUpgradeValue(c.player,club,need)>=-1&&aiRecruitmentFinanciallySafe(club,c.total,c.value,c.salary))
        .sort((a,b)=>(aiCandidateStrategicScore(b.player,club,need,"compras",b.value,b.salary)+aiCandidateScoreJitter(b.player.id,club.id))-(aiCandidateStrategicScore(a.player,club,need,"compras",a.value,a.salary)+aiCandidateScoreJitter(a.player.id,club.id)));
      const chosen=candidates[0];
      if(!chosen)return false;
      movedThisPass.add(chosen.player.id);
      // Fase 1: fee com o clube vendedor. Se já houver uma exigência conhecida de uma ronda
      // anterior (contraproposta), respeita-a em vez de repetir a proposta original — evita
      // ciclos sem fim de propostas sempre recusadas pelo mesmo valor.
      if(agreedTransferFee(chosen.player,chosen.other,club)==null){
        const feeKey=transferNegotiationKey(chosen.player,chosen.other,club);
        const existingFeeSession=state.transferNegotiations&&state.transferNegotiations[feeKey];
        const proposalAmount=existingFeeSession&&existingFeeSession.estado==="clube"&&existingFeeSession.exigencia?existingFeeSession.exigencia:chosen.value;
        if(proposalAmount>club.financeiro.orcamentoTransferencias||proposalAmount>club.financeiro.saldo-reserve)return false;
        const feeResult=negotiateWithClub(chosen.player.id,chosen.other.id,club.id,proposalAmount);
        if(feeResult.session&&!feeResult.session.aiMeta)feeResult.session.aiMeta={need,type:"compras"};
        const feePending=feeResult.outcome==="pendente";
        if(feePending){ markNegotiationOpened(chosen.player.id); donorCounts.set(chosen.other.id,(donorCounts.get(chosen.other.id)||0)+1); } // 2026-10-16: as compras também contam para o limite por clube dador
        return feePending;
      }
      // Fase 2: fee já acordado — falta negociar os termos pessoais com o jogador.
      const contractKey=negotiationSessionKey("transferencia",chosen.player,chosen.other,club);
      const existingContract=state.contractNegotiations&&state.contractNegotiations[contractKey];
      if(existingContract&&existingContract.aguardaResposta)return false;
      // Tal como na fase 1, uma contraproposta já conhecida do jogador (existingContract.counter)
      // é respeitada na ronda seguinte em vez de repetir a mesma oferta rejeitada — sem isto, a
      // negociação nunca convergia (evaluateContractOffer só aceita automaticamente uma proposta
      // igual ou superior à última contraproposta).
      const offer=existingContract&&existingContract.counter
        ? {...existingContract.counter}
        : {salarioMensal:chosen.salary,anos:aiContractYearsFor(chosen.player),papel:assignInitialRole(overall(chosen.player),chosen.player.age,chosen.player.potential,false)};
      const wageAfter=monthlyWageBill(club)+offer.salarioMensal;
      if(wageAfter>club.financeiro.limiteSalarial)return false; // exigência do jogador subiu acima do que o clube pode pagar — desiste deste candidato por agora
      const contractResult=proposeContract("transferencia",chosen.player.id,chosen.other.id,club.id,offer);
      if(contractResult.session&&!contractResult.session.aiMeta)contractResult.session.aiMeta={need,type:"compras"};
      const contractPending=contractResult.outcome==="pendente";
      if(contractPending) markNegotiationOpened(chosen.player.id);
      return contractPending;
    }
    function tryBTeam(){
      if(!club.equipaBId||!state.teams[club.equipaBId])return false;
      const bTeam=state.teams[club.equipaBId];
      const candidate=bTeam.players.filter(p=>candidateMatchesNeed(p,need)&&!p.emprestimo&&!movedThisPass.has(p.id)&&aiCandidateQualityOk(p,club,true)&&aiSquadUpgradeValue(p,club,need)>=-2&&canReleasePlayerFromTeam(bTeam,p).ok)
        .sort((a,b)=>(aiRecruitmentScore(b,club,need,0)+aiCandidateScoreJitter(b.id,club.id))-(aiRecruitmentScore(a,club,need,0)+aiCandidateScoreJitter(a.id,club.id)))[0];
      if(!candidate)return false;
      bTeam.players=bTeam.players.filter(p=>p.id!==candidate.id);club.players.push(candidate);
      candidate.titular=false;movedThisPass.add(candidate.id);
      // Correção (pedido do utilizador, 2026-10-03: "estão jogadores a ser despromovidos e
      // promovidos logo a seguir em equipas da IA e que não fazem sentido") — marca este jogador
      // para que processAutomaticABPlanning/ensureBTeamMinimums (as duas despromoções automáticas
      // A→B) não o escolham de volta para a equipa B ainda na mesma época em que subiu.
      candidate.__promotedFromBSeason=state.season;
      aiRegisterRecruitment(club,candidate,"promocoesB",0);
      // Correção (pedido do utilizador, 2026-10-03: "não podem aparecer notícias de despromoções
      // ou promoções de jogadores entre equipas A e B") — continua registado em dealsLog (conta
      // para o resumo agregado do mercado), mas deixa de gerar uma notícia individual.
      dealsLog.push(`${candidate.name} promovido de ${teamLinkHtml(bTeam.id)} para ${teamLinkHtml(club.id)}.`);
      return true;
    }
    // Assinatura de jogador livre entre clubes de IA: mesma demora de 1-4 dias que o utilizador
    // já tem via proposeContract("livre-sign",...) — não há fee a negociar (é livre), só termos
    // pessoais. Executa-se sozinha (applyAcceptedOffer) quando resolvePendingContractNegotiations
    // aceitar a proposta.
    function tryFreeAgent(){
      const candidates=(state.freeAgents||[]).filter(p=>{if(playerHasPendingDeal(p, pendingIndex)||playerTransferLimitReached(p)||(typeof scintReservado==="function"&&scintReservado(p)))return false;const role=assignInitialRole(overall(p),p.age,p.potential,false),salary=freeAgentSalaryDemand(p,club,role),total=aiTotalRecruitmentCost(p,club,"livres",0,salary);return candidateMatchesNeed(p,need)&&!movedThisPass.has(p.id)&&aiCandidateQualityOk(p,club,false)&&aiSquadUpgradeValue(p,club,need)>=-1&&freeAgentCareerFit(p,club,role).ok&&aiRecruitmentFinanciallySafe(club,total,0,salary);})
        .sort((a,b)=>{
          const rb=assignInitialRole(overall(b),b.age,b.potential,false),ra=assignInitialRole(overall(a),a.age,a.potential,false);
          const sb=aiCandidateStrategicScore(b,club,need,"livres",0,freeAgentSalaryDemand(b,club,rb))+aiCandidateScoreJitter(b.id,club.id);
          const sa=aiCandidateStrategicScore(a,club,need,"livres",0,freeAgentSalaryDemand(a,club,ra))+aiCandidateScoreJitter(a.id,club.id);
          return sb-sa;
        });
      const player=candidates[0];if(!player)return false;
      movedThisPass.add(player.id);
      const existingKey=negotiationSessionKey("livre-sign",player,null,club);
      const existing=state.contractNegotiations&&state.contractNegotiations[existingKey];
      if(existing&&existing.aguardaResposta)return false;
      // Tal como na compra (tryPurchase, fase 2), uma contraproposta já conhecida do jogador é
      // respeitada na ronda seguinte em vez de repetir a mesma oferta rejeitada.
      const role=existing&&existing.counter?existing.counter.papel:assignInitialRole(overall(player),player.age,player.potential,false);
      const projectedSalary=existing&&existing.counter?existing.counter.salarioMensal:freeAgentSalaryDemand(player,club,role);
      if(monthlyWageBill(club)+projectedSalary>club.financeiro.limiteSalarial*0.9)return false;
      const anos=existing&&existing.counter?existing.counter.anos:randomRenewalContractYears();
      const result=proposeContract("livre-sign",player.id,null,club.id,{salarioMensal:projectedSalary,papel:role,anos});
      if(result.session&&!result.session.aiMeta)result.session.aiMeta={need,type:"livres"};
      const freeAgentPending=result.outcome==="pendente";
      if(freeAgentPending) markNegotiationOpened(player.id);
      return freeAgentPending;
    }
    // Empréstimo entre clubes de IA (2026-09-14, pedido do utilizador: empréstimos também passam
    // a ter demora). Usa a mesma fila de proposeLoan/resolvePendingLoanNegotiations do utilizador.
    function tryLoan(){
      const candidates=pool.filter(other=>other.id!==club.id&&(donorCounts.get(other.id)||0)<DONOR_CAP_PER_PASS)
        .flatMap(other=>other.players.filter(p=>candidateMatchesNeed(p,need)&&!movedThisPass.has(p.id)&&!playerHasPendingDeal(p, pendingIndex)&&canLoanPlayer(p,other,club).ok&&!loanRefusalRecent(p,club.id)&&!aiSystemCriticalityBlock(other,p)&&aiCandidateQualityOk(p,club,false)&&aiSquadUpgradeValue(p,club,need)>=-1).map(p=>({other,p})))
        .sort((a,b)=>(aiCandidateStrategicScore(b.p,club,need,"emprestimos",0,(b.p.contrato?.salarioMensal||0)*.5)+aiCandidateScoreJitter(b.p.id,club.id)+(b.p.emprestimoListado?4:0))-(aiCandidateStrategicScore(a.p,club,need,"emprestimos",0,(a.p.contrato?.salarioMensal||0)*.5)+aiCandidateScoreJitter(a.p.id,club.id)+(a.p.emprestimoListado?4:0)));
      const chosen=candidates[0];if(!chosen)return false;
      const profile=loanEligibilityProfile(chosen.p,chosen.other);
      movedThisPass.add(chosen.p.id);
      const loanKeyExisting=loanNegotiationKey(chosen.p,chosen.other,club);
      const existingLoan=state.loanNegotiations&&state.loanNegotiations[loanKeyExisting];
      if(existingLoan&&existingLoan.estado==="pendente")return false;
      // Tal como na compra e no jogador livre, uma contraproposta já conhecida do clube
      // proprietário é respeitada na ronda seguinte em vez de repetir a mesma oferta rejeitada.
      const share=existingLoan&&existingLoan.counter?existingLoan.counter.salaryShare:50;
      const role=existingLoan&&existingLoan.counter?existingLoan.counter.role:(profile==="jovem"?"Titular":"Rotacao");
      const result=proposeLoan(chosen.p.id,chosen.other.id,club.id,share,role,existingLoan&&existingLoan.counter?existingLoan.counter.clausulas:undefined); // 2026-10-16: manter as cláusulas da contraproposta
      if(result.outcome==="pendente"){
        const key=loanNegotiationKey(chosen.p,chosen.other,club);
        const s=state.loanNegotiations&&state.loanNegotiations[key];
        if(s&&!s.aiMeta)s.aiMeta={need,type:"emprestimos"};
        donorCounts.set(chosen.other.id,(donorCounts.get(chosen.other.id)||0)+1);
        markNegotiationOpened(chosen.p.id);
      }
      return result.outcome==="pendente";
    }

    // Ordem pedida: com estabilidade financeira, compra > equipa B > livre > empréstimo.
    if(stable)return tryPurchase()||tryBTeam()||tryFreeAgent()||tryLoan();
    // Sem estabilidade: protege a tesouraria e só tenta uma compra no fim, se ainda for sustentável.
    return tryBTeam()||tryFreeAgent()||tryLoan()||tryPurchase();
  }
  // Aplica um fee de venda já acordado (aceitação direta ou contraproposta aceite pelo clube —
  // ver resolvePendingAiOfferCounters). Correção (2026-09-17, pedido do utilizador: "o processo
  // de venda de um jogador tem de passar pelos mesmos prazos: depois da aceitação da proposta, a
  // IA tem de apresentar contrato. isto demora dias e nem sempre tem de ser aceite pelo
  // jogador"): antes, aceitar uma proposta de IA movia o jogador de imediato — sem qualquer
  // negociação pessoal, ao contrário de QUALQUER outra transferência do jogo (tryPurchase,
  // AI-a-AI; wireExternalTransferPanel, quando é o utilizador a comprar). Passa a escrever o fee
  // acordado na mesma representação usada em todo o resto do jogo (state.transferNegotiations),
  // e a chamar proposeContract tal como tryPurchase já faz na sua fase 2 — reaproveita por
  // inteiro a demora, a possibilidade real de recusa do jogador e a notícia final, sem duplicar
  // nada disso aqui.
  function acceptAiOfferFee(offer, agreedValue){
    const buyer=state.teams[offer.fromTeamId],user=myTeam(),player=user&&user.players.find(p=>p.id===offer.playerId);
    if(!buyer||!user||!player) return {ok:false};
    const check=canReleasePlayerFromTeam(user,player);if(!check.ok)return check;
    initClubFinance(buyer);
    if(buyer.financeiro.saldo<agreedValue||agreedValue>buyer.financeiro.orcamentoTransferencias) return {ok:false,reason:"O clube interessado já não dispõe do valor."};
    if(!state.transferNegotiations) state.transferNegotiations={};
    const key=transferNegotiationKey(player,user,buyer);
    const existing=state.transferNegotiations[key];
    state.transferNegotiations[key]={
      estado:"contrato", playerId:player.id, fromTeamId:user.id, toTeamId:buyer.id,
      valorAcordado:Math.round(agreedValue), rondaClube:(existing&&existing.rondaClube)||1,
      exigencia:clubTransferDemand(player,user,buyer),
      prazoResposta:isoDate(registrationWindowCloseDate(state.currentDate||new Date())),
    };
    const salary=Math.round(Math.max(expectedSalary(player,buyer),player.contrato?.salarioMensal||0)*transferCareerPenalty(player,user,buyer));
    const contractOffer={salarioMensal:salary,anos:aiContractYearsFor(player),papel:assignInitialRole(overall(player),player.age,player.potential,false)};
    const result=proposeContract("transferencia",player.id,user.id,buyer.id,contractOffer);
    if(result.outcome==="recusa"){
      // O acordo de fee ficou fechado, mas o clube não conseguiu sequer propor contrato (ex.:
      // diferença de dimensão bloqueada, limite salarial) — a proposta original não volta a ficar
      // disponível, o negócio termina aqui.
      offer.status="desistiu";
      pushNews(state.currentDate,`O ${teamLinkHtml(buyer.id)} chegou a acordo pelo passe de ${playerLinkHtml(user.id,player)}, mas desistiu antes de propor contrato: ${result.reason}`,"proposta","Negociação encerrada",{autoAdvanceStop:true,teamId:buyer.id});
      return {ok:true};
    }
    if(result.session&&!result.session.aiMeta) result.session.aiMeta={need:null,type:"compras",userSaleFollowUp:true};
    offer.status="fee-acordado";
    return {ok:true};
  }
  function respondToAiOffer(id,action,counter){
    const offer=state.aiOffers.find(o=>o.id===id);if(!offer)return{ok:false};
    if(offer.status!=="pendente") return {ok:false,reason:"Esta proposta já não está à espera de resposta."};
    const buyer=state.teams[offer.fromTeamId],user=myTeam(),player=user.players.find(p=>p.id===offer.playerId);if(!player)return{ok:false};
    if(action==="recusar"){offer.status="recusada";offer.rejectedDate=isoDate(state.currentDate||new Date());return{ok:true};}
    if(action==="contrapropor"){
      // Correção (2026-09-17, pedido do utilizador: "quando faço uma contraproposta a um clube,
      // tem de sair uma noticia e tambem tem de demorar alguns dias. o clube pode recusar a
      // contraproposta e decidir nao continuar com as negociações"): antes, contrapropor era
      // instantâneo, sem notícia, e ficava para sempre preso — a guarda no início desta função
      // exigia sempre status==="pendente", e contrapropor mudava logo para "contraproposta",
      // impedindo qualquer ação futura (nem aceitar, nem recusar, nem nova contraproposta).
      // Passa a ter demora de 1-4 dias (mesmo padrão de negotiateWithClub), notícia própria, e um
      // resolvedor dedicado (resolvePendingAiOfferCounters, chamado a partir de
      // dailyConditionRecovery) que pode aceitar, melhorar a proposta original, ou desistir de
      // vez — nunca mais fica preso.
      const d=state.currentDate||new Date();
      const rng=makeSeededRng(`ai-offer-counter:${offer.id}:${offer.counterRound||0}:${isoDate(d)}`);
      const dias=seededRnd(rng,1,4),responseDate=addDays(d,dias);
      offer.status="contraproposta-enviada";
      offer.counterRound=(offer.counterRound||0)+1;
      offer.counterSubmittedDate=isoDate(d);offer.counterResponseDate=isoDate(responseDate);
      if(offer.type==="compra") offer.counterValue=Math.max(1000,Math.round(counter.value||offer.value));
      else{offer.counterSalaryShare=clamp(counter.salaryShare,0,100);offer.counterPapel=counter.papel||offer.papel;offer.counterClausulas=empNormalizarClausulas(counter.clausulas);}
      pushNews(d,`Enviámos uma contraproposta ao ${teamLinkHtml(buyer.id)} pelo passe de ${playerLinkHtml(user.id,player)}. Resposta prevista para ${fmtDateShort(responseDate)}.`,"proposta","Contraproposta enviada",{autoAdvanceStop:true,teamId:buyer.id});
      return{ok:true};
    }
    // Correção: uma proposta recebida durante o defeso ficava "pendente" indefinidamente se o
    // utilizador não respondesse logo — nada impedia aceitá-la mais tarde, já a época em curso
    // e o mercado fechado, concluindo uma transferência fora da janela. As propostas por
    // responder expiram agora ao fechar o mercado (expirePendingAiOffers), mas este é o
    // travão direto, no próprio aceite.
    // Correção (2026-09-17, mesmo bug de generateAiOffersForUser): marketPeriodForDate(...) é o
    // conceito antigo, fixo a Junho-Agosto, e nunca é "defeso" durante o verdadeiro defeso do
    // jogo (que começa em Setembro — seasonStartDate).
    // Segunda correção (2026-09-17, mesmo dia): state.inDefeso também não é o sinal certo — é a
    // bandeira curta do ecrã de defeso, que desliga muito antes de a janela real de inscrições
    // fechar (ver generateAiOffersForUser, acima, mesma correção). Usa agora
    // registrationWindowOpenFor, o mesmo sinal que expirePendingAiOffers passa a usar.
    if(!registrationWindowOpenFor(state.currentDate)) return {ok:false,reason:"A janela de inscrições está fechada — esta proposta já não pode ser aceite."};
    if(playerTransferLimitReached(player)) return {ok:false,reason:"Este jogador já foi transferido esta época — só pode voltar a mudar de clube na época seguinte."};
    if(offer.type==="emprestimo"){
      // 0.4.12: o jogador tem de aceitar o empréstimo — responde em 1-3 dias (resolveLoanConsents).
      const chk=canLoanPlayer(player,user,buyer);if(!chk.ok)return{ok:false,reason:chk.reason};
      const rel=canReleasePlayerFromTeam(user,player);if(!rel.ok)return rel;
      loanOfferToPlayerConsult(offer,player,user,buyer);return{ok:true};
    }
    return acceptAiOfferFee(offer, offer.value);
  }
  // Resolve as contrapropostas do utilizador a propostas de IA (ver respondToAiOffer) cuja data
  // de resposta já chegou. Reavalia a capacidade financeira REAL do clube comprador no momento da
  // resposta (não a fixa no momento do pedido — mesmo princípio já usado em
  // resolvePendingClubNegotiations/resolvePendingDirectionInvestments).
  function resolvePendingAiOfferCounters(date){
    (state.aiOffers||[]).forEach(offer=>{
      if(!offer||offer.status!=="contraproposta-enviada")return;
      if(new Date(date)<new Date(offer.counterResponseDate+"T00:00:00Z"))return;
      const buyer=state.teams[offer.fromTeamId],user=myTeam(),player=user&&user.players.find(p=>p.id===offer.playerId);
      if(!buyer||!user||!player){offer.status="expirada";return;}
      initClubFinance(buyer);
      if(offer.type==="compra"){
        const counterValue=offer.counterValue,reserve=Math.max(monthlyWageBill(buyer)*3,financeConfig(buyer).homeCost*4,15000);
        // Correção (2026-10-16): só verificava se o clube conseguia pagar — uma contraproposta de 45×
        // o valor do jogador era aceite desde que coubesse no orçamento. Teto: o maior entre 1,5× a
        // proposta atual e 1,4× o valor de mercado.
        const tetoContra=Math.round(Math.max((offer.value||0)*1.5, playerMarketValue(player,user)*1.4)/500)*500;
        const affordable=counterValue<=tetoContra&&counterValue<=buyer.financeiro.orcamentoTransferencias&&counterValue<=buyer.financeiro.saldo-reserve;
        if(affordable){
          const rAceite=acceptAiOfferFee(offer,counterValue);
          if(rAceite&&rAceite.ok===false){ // 2026-10-16: antes a proposta ficava presa em "contraproposta-enviada"
            offer.status="desistiu";
            pushNews(date,`O ${teamLinkHtml(buyer.id)} já não pôde avançar pelo passe de ${playerLinkHtml(user.id,player)}${rAceite.reason?`: ${rAceite.reason}`:"."}`,"proposta","Negociação encerrada",{autoAdvanceStop:true,teamId:buyer.id});
            return;
          }
          if(offer.status==="fee-acordado")pushNews(date,`O ${teamLinkHtml(buyer.id)} aceitou a tua contraproposta de ${fmtMoney(counterValue)} pelo passe de ${playerLinkHtml(user.id,player)}.`,"proposta","Contraproposta aceite",{autoAdvanceStop:true,teamId:buyer.id});
        } else if((offer.counterRound||1)<3 && offer.value<counterValue){
          // Não consegue pagar a totalidade, mas ainda vale a pena melhorar a proposta original em
          // vez de desistir logo — mesmo espírito do ramo "contraproposta parcial" já usado em
          // resolvePendingClubNegotiations.
          const mid=Math.min(tetoContra,Math.round(((offer.value+counterValue)/2)/500)*500);
          offer.value=Math.max(offer.value,Math.min(mid,buyer.financeiro.orcamentoTransferencias));
          offer.status="pendente";
          pushNews(date,`O ${teamLinkHtml(buyer.id)} respondeu com uma nova proposta de ${fmtMoney(offer.value)} pelo passe de ${playerLinkHtml(user.id,player)}.`,"proposta","Nova proposta do clube",{autoAdvanceStop:true,teamId:buyer.id});
        } else {
          offer.status="desistiu";
          pushNews(date,`O ${teamLinkHtml(buyer.id)} decidiu não continuar a negociação pelo passe de ${playerLinkHtml(user.id,player)}.`,"proposta","Negociação encerrada",{autoAdvanceStop:true,teamId:buyer.id});
        }
      } else {
        // 2026-10-16: um empréstimo não pode concluir-se com a janela de inscrições fechada
        // (completeLoan não tem verificação de janela nem adiamento TRF).
        if(!state.inDefeso && !registrationWindowOpenFor(new Date(date))){ offer.status="expirada"; pushNews(date,`A proposta de empréstimo do ${teamLinkHtml(buyer.id)} por ${playerLinkHtml(user.id,player)} caducou: a janela de inscrições fechou.`,"proposta","Proposta caducada",{teamId:buyer.id}); return; }
        // Empréstimo: mesma tolerância já usada em evaluateLoanOffer (aceita subidas até 25
        // pontos percentuais acima da última proposta do clube).
        const counterShare=offer.counterSalaryShare;
        // Cláusulas: o clube interessado pondera-as do seu lado — tirar-lhe uma opção de compra
        // barata ou impor-lhe utilização mínima/chamada de volta reduz a margem salarial que tolera.
        const delta=empPrecoDestino(offer.counterClausulas||offer.clausulas,player,user)-empPrecoDestino(offer.clausulas,player,user);
        if(counterShare<=offer.salaryShare+25+delta*1.2){
          offer.salaryShare=counterShare;offer.papel=offer.counterPapel||offer.papel;offer.clausulas=empNormalizarClausulas(offer.counterClausulas||offer.clausulas);
          // 0.4.12: o clube aceitou a contraproposta — falta o jogador decidir.
          pushNews(date,`O ${teamLinkHtml(buyer.id)} aceitou a tua contraproposta de empréstimo por ${playerLinkHtml(user.id,player)}.`,"proposta","Contraproposta aceite",{autoAdvanceStop:true,teamId:buyer.id});
          loanOfferToPlayerConsult(offer,player,user,buyer);
        } else if((offer.counterRound||1)<3){
          offer.salaryShare=Math.min(100,Math.round((offer.salaryShare+counterShare)/2));
          offer.status="pendente";
          pushNews(date,`O ${teamLinkHtml(buyer.id)} respondeu com uma nova proposta de empréstimo: ${offer.salaryShare}% do salário.`,"proposta","Nova proposta do clube",{autoAdvanceStop:true,teamId:buyer.id});
        } else {
          offer.status="desistiu";
          pushNews(date,`O ${teamLinkHtml(buyer.id)} decidiu não continuar a negociação de empréstimo por ${playerLinkHtml(user.id,player)}.`,"proposta","Negociação encerrada",{autoAdvanceStop:true,teamId:buyer.id});
        }
      }
    });
  }
  // Quando o JOGADOR contrapropõe os termos pessoais de uma venda iniciada por uma proposta de
  // IA (acceptAiOfferFee, acima, marca a sessão com aiMeta.userSaleFollowUp), não há ninguém do
  // lado do clube comprador para responder manualmente — aceita a contraproposta automaticamente
  // se couber no limite salarial do clube, tal como tryPurchase já faz sozinho, dia após dia, ao
  // reaproveitar existingContract.counter nas compras inteiramente entre clubes de IA. Sem isto, a
  // negociação de termos pessoais ficava parada para sempre à espera de uma resposta que nunca
  // chegaria (o botão "Responder à contraproposta →" só existe quando é o UTILIZADOR quem
  // controla o clube comprador — ver evaluateContractOffer/contractNegOpenButtonHtml).
  function resolvePendingAiOfferContractCounters(date){
    if(!state.contractNegotiations)return;
    Object.values(state.contractNegotiations).forEach(session=>{
      if(!session||session.aguardaResposta||!session.counter||session.kind!=="transferencia")return;
      if(!session.aiMeta||!session.aiMeta.userSaleFollowUp)return;
      const toTeam=state.teams[session.toTeamId];if(!toTeam)return;
      const wageAfter=monthlyWageBill(toTeam)+session.counter.salarioMensal;
      if(wageAfter>toTeam.financeiro.limiteSalarial){session.counter=null;return;} // não volta a tentar — a negociação fica encerrada, sem contrato
      // Não limpa session.counter aqui: proposeContract volta a colocar aguardaResposta=true e
      // guarda esta mesma oferta em session.pendingOffer, sem tocar em session.counter. É esse
      // valor que, ao ser reavaliado por evaluateContractOffer no próximo dia (via
      // resolvePendingContractNegotiations), faz `acceptedCounter` disparar — a oferta enviada é,
      // por construção, exatamente igual à última contraproposta do jogador. Mesma técnica já
      // usada em tryPurchase (fase 2, "existingContract.counter"), só que aqui aplicada de
      // imediato porque não há ninguém do lado do comprador para decidir esperar mais um dia.
      proposeContract("transferencia",session.playerId,session.fromTeamId,session.toTeamId,{...session.counter});
    });
  }
  // Expira as propostas por responder quando a janela real de inscrições fecha — sem isto, uma
  // proposta recebida e ignorada ficava "pendente" para sempre, podendo ser aceite meses depois,
  // já fora de qualquer janela real.
  // Correção (2026-09-17, mesmo bug de generateAiOffersForUser/respondToAiOffer, apontada pelo
  // utilizador: "não estão a aparecer no separador mercado, o que impossibilita a resposta"):
  // esta função era chamada uma única vez, no preciso instante em que a bandeira CURTA
  // state.inDefeso desligava (fim do ecrã de defeso) — dias antes de a janela real de inscrições
  // (registrationWindowOpenFor, até 15 de Outubro) sequer estar perto de fechar. Isto apagava de
  // imediato qualquer proposta ainda por responder assim que o utilizador saía do ecrã de defeso,
  // muito antes de o mercado realmente fechar. Passa a correr todos os dias a partir de
  // dailyConditionRecovery (09-fluxo-epoca.js, mesmo ponto único de avanço de dia que já resolve o
  // resto do mercado), só expirando de facto quando `date` está mesmo fora de uma janela real.
  function expirePendingAiOffers(date){
    if(date!=null && registrationWindowOpenFor(date)) return; // janela ainda aberta — nada a expirar
    // "contraproposta" era o estado antigo (ver respondToAiOffer) — substituído por
    // "contraproposta-enviada", que também expira aqui se a janela fechar antes de o clube responder.
    (state.aiOffers||[]).forEach(o=>{ if(o.status==="pendente"||o.status==="contraproposta-enviada") o.status="expirada"; });
  }
  // Lembrete "proposta por responder" (2026-09-17, pedido do utilizador: "nao está a aparecer o
  // e-mail a avisar que tenho respostas por dar, 3 dias depois. deve interromper o
  // processamento, conforme já definido") — mesmo molde e mesmo prazo de
  // resolvePendingContractCounterReminders, agora aplicado às propostas de clubes de IA pelos
  // jogadores do utilizador (state.aiOffers). Sem isto, uma proposta ignorada durante dias a fio
  // nunca mais dava notícia de si — só aparecia (silenciosamente) no separador Mercado — até
  // expirar com o fecho do mercado. Cada oferta só gera um lembrete (offerReminderSent).
  function resolvePendingAiOfferReminders(date){
    (state.aiOffers||[]).forEach(o=>{
      if(!o||o.status!=="pendente"||o.offerReminderSent||!o.date)return;
      if(new Date(date)<addDays(new Date(o.date+"T00:00:00Z"),3))return;
      const toTeam=state.teams[o.toTeamId];
      if(!toTeam||!isUserControlledTeam(toTeam))return; // só interessa ao utilizador quando é ele quem tem de responder
      const fromTeam=state.teams[o.fromTeamId],player=toTeam.players.find(p=>p.id===o.playerId);
      if(!fromTeam||!player)return;
      o.offerReminderSent=true;
      pushNews(date,`Ainda não respondeste à proposta de ${o.type==="compra"?"compra":"empréstimo"} do ${teamLinkHtml(fromTeam.id)} por ${playerLinkHtml(toTeam.id,player)}. Consulta o separador Mercado para aceitar, contrapropor ou recusar.`,"proposta","Proposta por responder",{autoAdvanceStop:true, teamId:fromTeam.id});
    });
  }
  function renderAiOffersSection(team){
    const panelBody=document.querySelector("#viewMercado .panel-body");if(!panelBody)return;let box=document.getElementById("aiOffersBox");if(!box){box=document.createElement("div");box.id="aiOffersBox";panelBody.insertBefore(box,panelBody.firstChild);}
    // Correção (2026-09-17): "contraproposta" era o estado antigo, instantâneo e sem saída
    // (ver respondToAiOffer) — já não é atribuído a nenhuma proposta. O estado novo,
    // "contraproposta-enviada", continua a aparecer na lista (para o utilizador ver que está à
    // espera) mas sem os três botões de resposta, já que a bola está do lado do clube.
    const offers=(state.aiOffers||[]).filter(o=>o.status==="pendente"||o.status==="contraproposta-enviada"||o.status==="jogador-a-decidir");
    box.innerHTML=`<div class="eyebrow" style="margin-bottom:8px;">Propostas recebidas (${offers.length})</div>${offers.map(o=>{const club=state.teams[o.fromTeamId],p=team.players.find(x=>x.id===o.playerId);if(!p)return'';
      const termos=o.type==="compra"?`Compra: ${fmtMoney(o.value)}`:`Empréstimo: ${o.salaryShare}% salário · ${ROLE_LABELS[o.papel]||o.papel} · ${empClausulasTexto(o.clausulas)}`;
      if(o.status==="jogador-a-decidir"){
        return `<div class="fixture-row ai-offer-row" data-offer="${o.id}" style="grid-template-columns:2fr 2fr auto;"><div><b>${escapeHtml(club.name)}</b><br>${playerNameHtml(p)}</div><div>${termos}</div><div class="market-status ok">Acordo com o clube — a aguardar a decisão do jogador (resposta prevista para ${fmtDateShort(new Date(o.playerResponseDate+"T00:00:00Z"))})</div></div>`;
      }
      if(o.status==="contraproposta-enviada"){
        const termosContra=o.type==="compra"?`Contraproposta enviada: ${fmtMoney(o.counterValue)}`:`Contraproposta enviada: ${o.counterSalaryShare}% salário · ${empClausulasTexto(o.counterClausulas)}`;
        return `<div class="fixture-row ai-offer-row" data-offer="${o.id}" style="grid-template-columns:2fr 2fr auto;"><div><b>${escapeHtml(club.name)}</b><br>${playerNameHtml(p)}</div><div>${termos}</div><div class="market-status ok">${termosContra} — resposta prevista para ${fmtDateShort(new Date(o.counterResponseDate+"T00:00:00Z"))}.</div></div>`;
      }
      return `<div class="fixture-row ai-offer-row" data-offer="${o.id}" style="grid-template-columns:2fr 2fr auto auto;"><div><b>${escapeHtml(club.name)}</b><br>${playerNameHtml(p)}</div><div>${termos}${o.type==="emprestimo"?`<div class="meta">${loanConsentHintHtml(p,team,club,o.salaryShare,o.papel)}</div>`:""}</div><button class="btn btn-primary ai-accept">Aceitar</button><span><button class="btn btn-ghost ai-counter${o.type==="emprestimo"?" emp-contrapropor":""}" data-offer="${o.id}">Contrapropor</button><button class="btn btn-ghost ai-reject">Recusar</button></span></div>`;}).join("")||'<p class="helptext">Sem propostas recebidas.</p>'}`;
    box.querySelectorAll('.ai-accept').forEach(b=>b.onclick=()=>{const r=respondToAiOffer(b.closest('[data-offer]').dataset.offer,'aceitar',{});if(!r.ok)alert(r.reason||'Não foi possível aceitar.');renderTransferMarket();renderRoster();});
    box.querySelectorAll('.ai-counter').forEach(b=>b.onclick=()=>{const id=b.closest('[data-offer]').dataset.offer,o=state.aiOffers.find(x=>x.id===id);if(o.type==="compra"){const value=parseInt(prompt("Valor da contraproposta (€):",o.value),10);if(value)respondToAiOffer(id,"contrapropor",{value});}else{return;}renderTransferMarket();});
    box.querySelectorAll('.ai-reject').forEach(b=>b.onclick=()=>{respondToAiOffer(b.closest('[data-offer]').dataset.offer,'recusar',{});renderTransferMarket();});
  }

  // Pedido do utilizador: "deve ser possivel as outras equipas poderem pedir jogadores de equipas
  // B emprestados". Um jogador de equipa B de OUTRO clube nunca podia ser abordado de forma
  // nenhuma — a ficha do jogador mostrava sempre um bloqueio total. Mas o motor de empréstimos
  // (canLoanPlayer/evaluateLoanOffer, mais acima neste ficheiro) já tratava uma equipa B como
  // proprietária legítima e normal ("emprestar de uma equipa B é sempre normal... isento do
  // limite de distância entre clubes") — só faltava a interface deixar lá chegar. Só o
  // EMPRÉSTIMO fica disponível — nunca compra definitiva nem pré-contrato: um jogador de equipa B
  // continua a não poder ser comprado a outro clube, só emprestado, tal como no mercado interno
  // A/B do próprio utilizador.
  // Corpo do formulário de empréstimo, partilhado entre externalTransferPanelHtml e
  // externalLoanOnlyPanelHtml — mostra o estado "à espera de resposta" quando já há um pedido
  // pendente (2026-09-14: empréstimos também passam a ter demora de 1-4 dias).
  function loanPanelBodyHtml(player,fromTeam,toTeam){
    const key=loanNegotiationKey(player,fromTeam,toTeam),session=(state.loanNegotiations||{})[key];
    if(session&&session.estado==="pendente"){
      return `<div class="market-status ok">Pedido de empréstimo enviado — resposta prevista para ${fmtDateShort(new Date(session.responseDate+"T00:00:00Z"))}.</div>`;
    }
    if(session&&session.estado==="jogador-a-decidir"){
      return `<div class="market-status ok">O clube aceitou — a aguardar a decisão do jogador (resposta prevista para ${fmtDateShort(new Date(session.playerResponseDate+"T00:00:00Z"))}).</div>`;
    }
    const counterNote=session&&session.estado==="clube"&&session.counter?`<div class="loan-result"><span style="color:#8a6d00;font-weight:700;">Contraproposta anterior: ${session.counter.salaryShare}% do salário, papel ${ROLE_LABELS[session.counter.role]||session.counter.role}, ${empClausulasTexto(session.counter.clausulas)}.</span></div>`:`<div class="loan-result"></div>`;
    return `<div style="display:grid;grid-template-columns:1fr 1fr auto;gap:8px;align-items:end;"><label>Salário suportado<select class="loan-share"><option>0</option><option>25</option><option selected>50</option><option>75</option><option>100</option></select></label><label>Papel<select class="loan-role"><option value="Titular">Titular</option><option value="Rotacao" selected>Rotação</option><option value="Desenvolvimento">Desenvolvimento</option></select></label><button class="btn btn-ghost loan-send">Pedir empréstimo</button></div>${empEditorHtml(player,fromTeam,session&&session.counter?session.counter.clausulas:null)}${counterNote}`;
  }
  function externalLoanOnlyPanelHtml(player,fromTeam,toTeam){
    if(!toTeam) return "";
    const loanSess=(state.loanNegotiations||{})[loanNegotiationKey(player,fromTeam,toTeam)];
    return `<div class="helptext" style="margin-bottom:8px;">Jogador de equipa B de outro clube — só pode ser abordado por empréstimo, nunca por transferência definitiva.</div>
      ${loanSess&&loanSess.estado==="pendente"?`<div class="market-status ok">Pedido de empréstimo enviado — resposta prevista para ${fmtDateShort(new Date(loanSess.responseDate+"T00:00:00Z"))}.</div>`:""}
      ${loanSess&&loanSess.estado==="jogador-a-decidir"?`<div class="market-status ok">O clube aceitou — a aguardar a decisão do jogador (resposta prevista para ${fmtDateShort(new Date(loanSess.playerResponseDate+"T00:00:00Z"))}).</div>`:""}
      <button class="btn btn-primary nm-open-loan" data-from="${fromTeam.id}" data-to="${toTeam.id}" data-player="${player.id}" style="width:100%;">Pedir empréstimo →</button>`;
  }
  // Painel contextual na ficha do jogador: 1) acordo com o clube; 2) contrato com o jogador.
  // 2026-09-14 (pedido do utilizador): negociar passa a ser possível o ano inteiro, não só no
  // defeso — marketPeriodForDate continua a servir só a elegibilidade de pré-contratos (regra
  // real, distinta). O que já não é imediato é o efeito de uma transferência fechada fora de uma
  // janela real de inscrição (etiqueta TRF, ver applyAcceptedOffer/registrationWindowOpenFor).
  function externalTransferPanelHtml(player,fromTeam,toTeam){
    if(!toTeam) return "";
    const period=marketPeriodForDate(state.currentDate),stage=careerStage(player);
    if(player.pendingTransferHold){
      return `<div class="market-status ok">${contractStatusLabel(player)}.</div>`;
    }
    if(period==="pre-contratos"){
      if(!isFinalContractYear(player)) return `<div class="market-status no">Ainda tem contrato e não está elegível para pré-contrato.</div>`;
      return `<div class="eyebrow">Abordagem direta ao jogador</div>${negotiationCardHtml("pre-contrato",player,fromTeam,toTeam,"Pré-contrato",{forceOpen:true,hideToggle:true})}`;
    }
    const key=transferNegotiationKey(player,fromTeam,toTeam),session=(state.transferNegotiations||{})[key],fee=session&&session.estado==="contrato"?session.valorAcordado:null;
    if(session&&session.estado==="pendente"){
      return `<div class="market-status ok">Proposta de ${fmtMoney(session.ultimaProposta||0)} enviada ao ${escapeHtml(fromTeam.name)} — resposta prevista para ${fmtDateShort(new Date(session.pendingResponseDate+"T00:00:00Z"))}.</div>`;
    }
    const estimate=clubTransferDemand(player,fromTeam,toTeam),salary=expectedSalary(player,toTeam),cost=transferCostSummary(player,fromTeam,toTeam,salary,2);
    if(fee!=null){
      return `<div class="market-status ok"><b>Acordo com ${escapeHtml(fromTeam.name)}:</b> ${fmtMoney(fee)}</div>
        <div class="pm-postmatch-grid" style="margin:8px 0;"><div><b>Fase da carreira</b><br>${stage.label}</div><div><b>Custo salarial indicativo (2 anos)</b><br>${fmtMoney(cost.wages)}</div><div><b>Compromisso indicativo</b><br>${fmtMoney(cost.total)}</div></div>
        ${negotiationCardHtml("transferencia",player,fromTeam,toTeam,"Negociação de contrato",{forceOpen:true,hideToggle:true})}`;
    }
    const loanSess=(state.loanNegotiations||{})[loanNegotiationKey(player,fromTeam,toTeam)];
    return `<div class="eyebrow">Negociar com ${escapeHtml(fromTeam.name)}</div>
      <div class="pm-postmatch-grid" style="margin:8px 0;"><div><b>Fase da carreira</b><br>${stage.label}</div><div><b>Valor de mercado</b><br>${fmtMoney(playerMarketValue(player,fromTeam))}</div><div><b>Pedido estimado do clube</b><br>${fmtMoney(estimate)}</div></div>
      ${player.emprestimoListado?`<div class="market-status ok">Disponível para empréstimo — ${escapeHtml(loanMotivoTexto(player.emprestimoMotivo))}.</div>`:""}
      ${loanSess&&loanSess.estado==="pendente"?`<div class="market-status ok">Pedido de empréstimo enviado — resposta prevista para ${fmtDateShort(new Date(loanSess.responseDate+"T00:00:00Z"))}.</div>`:""}
      ${loanSess&&loanSess.estado==="jogador-a-decidir"?`<div class="market-status ok">O clube aceitou — a aguardar a decisão do jogador (resposta prevista para ${fmtDateShort(new Date(loanSess.playerResponseDate+"T00:00:00Z"))}).</div>`:""}
      <button class="btn btn-primary nm-open-club" data-from="${fromTeam.id}" data-to="${toTeam.id}" data-player="${player.id}" style="width:100%;margin-top:6px;">Fazer proposta →</button>
      <div class="helptext" style="margin-top:6px;">Compra ou empréstimo, e depois o contrato com o jogador — tudo numa janela de negociação.</div>`;
  }
  function wireExternalTransferPanel(container,player,fromTeam,toTeam,onChanged){
    const clubBtn=container.querySelector(".nm-open-club");
    if(clubBtn) clubBtn.addEventListener("click",()=>openNegotiationModal({kind:"transferencia",playerId:player.id,fromId:fromTeam.id,toId:toTeam.id,step:"clube",onChanged}));
    const loanBtn=container.querySelector(".nm-open-loan");
    if(loanBtn) loanBtn.addEventListener("click",()=>openNegotiationModal({kind:"transferencia",playerId:player.id,fromId:fromTeam.id,toId:toTeam.id,step:"clube",loanOnly:true,onChanged}));
    if(container.querySelector(".neg-open")) wireNegotiationCards(container,onChanged);
  }

  // ---- Negociação inline (Fase 13) — substitui a compra direta por proposta/resposta ----
  // Correção: o campo de salário sugerido, e as recusas na negociação pessoal, não davam
  // qualquer pista de que um jogador vindo de um clube bem maior exige uma compensação salarial
  // acima do normal para aceitar descer de patamar (transferCareerPenalty, já aplicado em
  // contractDemand) — o utilizador só descobria isso a tentar e a levar recusas genéricas, sem
  // perceber que o entrave é a relutância do PRÓPRIO JOGADOR, não um preço arbitrário. Mostra
  // agora esse aviso sempre que a diferença de apelo entre clubes for significativa.
  const DOWNSTEP_APPEAL_NOTE_THRESHOLD = 10;
  function negotiationCardHtml(kind, player, fromTeam, toTeam, contextLabel, opts){
    opts=opts||{};
    const negKey=negotiationSessionKey(kind,player,fromTeam,toTeam);
    const pendingSession=(state.contractNegotiations||{})[negKey];
    const isExternal = kind!=="renovacao" && fromTeam && toTeam && fromTeam.id!==toTeam.id;
    // 2026-09-14 (pedido do utilizador): a resposta do jogador passa a demorar 1-4 dias — enquanto
    // aguarda, o cartão mostra o estado em vez do formulário/toggle de sempre.
    if(pendingSession&&pendingSession.aguardaResposta){
      const displayOvrPending=isExternal?visibleOverall(player,fromTeam):kind==="livre-sign"?experienciaOvrTexto(player):overall(player);
      return `<div class="market-card negotiation-card" data-negid="${player.id}|${kind}">
        <div><b>${playerNameHtml(player)}</b><div class="market-meta">${contextLabel} · ${player.age} anos · ${linhaAbbrev(player)}</div></div>
        <div>OVR ${displayOvrPending}</div>
        <div class="market-status ok">Proposta enviada — resposta prevista para ${fmtDateShort(new Date(pendingSession.pendingResponseDate+"T00:00:00Z"))}.</div>
      </div>`;
    }
    const isOpen = opts.forceOpen!=null ? opts.forceOpen : state.uiNegotiationOpenId===player.id+"|"+kind;
    // 0.3.2: o formulário passou para a janela de negociação (08zf-negociacao-modal.js). Quando o
    // utilizador acaba de pedir para negociar (botão Renovar/Propor, ligação de uma notícia), a
    // janela abre sozinha uma única vez.
    const autoOpen = state.uiNegotiationOpenId===player.id+"|"+kind || state.uiNegotiationOpenId==="renov-"+player.id;
    // Correção (mesmo pedido do utilizador sobre o OVR aparecer "à cabeça"): um cartão de
    // negociação externa (transferência/pré-contrato de um jogador de outro clube) mostrava sempre
    // o OVR REAL, ignorando por completo o nevoeiro de scouting já usado na ficha do jogador e agora
    // também na tabela de Equipas. Renovação (jogador já nosso) e assinatura de agente livre
    // (sem clube de origem, sem mecanismo de scouting definido) continuam a mostrar o valor real.
    const displayOvr = isExternal ? visibleOverall(player, fromTeam) : kind==="livre-sign" ? experienciaOvrTexto(player) : overall(player);
    // Correção (2026-09-16, reportado pelo utilizador: "quando faço proposta pelo valor da sua
    // contraproposta, ele volta a fazer contraproposta"): assim que o jogador responde com uma
    // contraproposta (session.counter), o formulário reabria sempre com os valores GENÉRICOS de
    // sempre — salário calculado do zero, e o papel pré-selecionado era o do CONTRATO ATUAL do
    // jogador (no clube de origem), não o papel que ele próprio pediu na contraproposta. Sem ver
    // os valores exatos já pré-preenchidos, era fácil o utilizador "combinar" o salário certo mas
    // deixar o papel ou a duração por acertar — e isso, para o motor de negociação, é uma proposta
    // nova, não uma aceitação, daí voltar sempre a contrapropor. O formulário passa agora a abrir
    // sempre pré-preenchido com a última contraproposta do jogador, quando existe uma.
    const activeCounter = pendingSession && pendingSession.counter ? pendingSession.counter : null;
    const suggestedSalary = activeCounter ? activeCounter.salarioMensal
      : kind==="renovacao" ? (player.contrato?player.contrato.salarioMensal:expectedSalary(player,toTeam))
      : Math.round(contractDemand(player,fromTeam,toTeam,null,kind).salarioMensal);
    const suggestedAnos = activeCounter ? activeCounter.anos : (kind==="renovacao" ? (player.contrato?player.contrato.anos:2) : 2);
    const suggestedPapel = activeCounter ? activeCounter.papel : (player.contrato?player.contrato.papel:null);
    const counterNote = activeCounter
      ? `<div class="helptext" style="grid-column:1/-1;color:#8a6d00;">↩️ Contraproposta do jogador: ${fmtMoney(activeCounter.salarioMensal)}/mês, ${activeCounter.anos} ano(s), papel ${ROLE_LABELS[activeCounter.papel]||activeCounter.papel}. O formulário já vem preenchido com estes valores — para aceitar, basta enviar sem alterar.</div>` : '';
    const appealDrop = isExternal ? Math.round((clubAppeal(fromTeam)-clubAppeal(toTeam))*10)/10 : 0;
    const downstepNote = appealDrop>DOWNSTEP_APPEAL_NOTE_THRESHOLD
      ? `<div class="helptext" style="grid-column:1/-1;color:#8a6d00;">⚠️ Vem de um clube maior — só assina aqui por um salário bem acima do habitual para o seu nível.</div>` : '';
    // Liga espanhola (2026-09-06): quando a assinatura muda o jogador de país, o salário sugerido
    // já inclui o prémio de deslocação (ver DISPLACEMENT_WAGE_PREMIUM/contractDemand) — este aviso
    // só explica ao utilizador porquê, e adianta que há ainda um custo de alojamento mensal à parte.
    const displacementNote = (toTeam && isPlayerDisplaced(player,toTeam))
      ? `<div class="helptext" style="grid-column:1/-1;color:#8a6d00;">🌍 Jogador deslocado do país de origem — exige salário mais alto por estar longe da família, e o clube pagará ainda ${fmtMoney(playerHousingCost(player))}/mês de alojamento, à parte do salário.</div>` : '';
    const roleOptions = PLAYER_ROLES.map(r=>`<option value="${r}" ${(suggestedPapel===r)?'selected':''}>${ROLE_LABELS[r]}</option>`).join("");
    const anosOptions = [1,2,3].map(n=>`<option value="${n}" ${suggestedAnos===n?'selected':''}>${n}</option>`).join("");
    const actionLabel = kind==="renovacao" ? "Propor renovação" : kind==="pre-contrato" ? "Propor pré-contrato" : "Propor transferência";
    return `<div class="market-card negotiation-card" data-negid="${player.id}|${kind}">
      <div><b>${playerNameHtml(player)}</b><div class="market-meta">${contextLabel} · ${player.age} anos · ${linhaAbbrev(player)}</div></div>
      <div>OVR ${displayOvr}</div>
      <div class="market-status">${contractStatusLabel(player)}</div>
      ${opts.hideToggle?'':`<button class="btn btn-ghost neg-toggle" data-negid="${player.id}|${kind}">${isOpen?'Fechar':actionLabel}</button>`}
      ${isOpen?`<button class="btn btn-primary neg-open" data-kind="${kind}" data-player="${player.id}" data-from="${fromTeam?fromTeam.id:''}" data-to="${toTeam.id}" ${autoOpen?'data-auto="1"':''} style="grid-column:1/-1;">${kind==="renovacao"?"Negociar renovação":kind==="pre-contrato"?"Abordar o jogador":kind==="livre-sign"?"Negociar contrato":"Negociar contrato com o jogador"} →</button>`:''}
    </div>`;
  }
  function wireNegotiationCards(container, onChanged){
    const openNeg=btn=>openNegotiationModal({kind:btn.getAttribute("data-kind"),playerId:btn.getAttribute("data-player"),fromId:btn.getAttribute("data-from")||null,toId:btn.getAttribute("data-to"),onChanged});
    container.querySelectorAll(".neg-open").forEach(btn=>btn.addEventListener("click",()=>openNeg(btn)));
    const autoBtn=container.querySelector(".neg-open[data-auto]");
    if(autoBtn){state.uiNegotiationOpenId=null;setTimeout(()=>openNeg(autoBtn),0);}
    container.querySelectorAll(".neg-toggle").forEach(btn=>btn.addEventListener("click",()=>{
      const id=btn.getAttribute("data-negid");
      state.uiNegotiationOpenId = state.uiNegotiationOpenId===id ? null : id;
      onChanged();
    }));
    container.querySelectorAll(".neg-send").forEach(btn=>btn.addEventListener("click",()=>{
      const card=btn.closest(".negotiation-card");
      const offer={
        salarioMensal: Math.max(0, parseInt(card.querySelector(".neg-salario").value,10)||0),
        anos: parseInt(card.querySelector(".neg-anos").value,10)||1,
        papel: card.querySelector(".neg-papel").value,
      };
      const kind=btn.getAttribute("data-kind"), playerId=btn.getAttribute("data-player"), fromId=btn.getAttribute("data-from")||null, toId=btn.getAttribute("data-to");
      const result=proposeContract(kind, playerId, fromId, toId, offer);
      const resultBox=card.querySelector(".neg-result");
      if(result.outcome==="pendente"){
        resultBox.innerHTML=`<span style="color:#8a6d00;font-weight:700;">Proposta enviada — resposta prevista para ${fmtDateShort(new Date(result.responseDate+"T00:00:00Z"))}.</span>`;
        onChanged();
      } else {
        resultBox.innerHTML=`<span style="color:var(--vermelho);font-weight:700;">Recusado: ${escapeHtml(result.reason||"sem interesse")}</span>`;
      }
    }));
  }
  function renderContractsCenter(team){
    const panelBody=document.querySelector("#viewMercado .panel-body");
    if(!panelBody) return;
    let box=document.getElementById("contractsCenterBox");
    if(!box){
      box=document.createElement("div");
      box.id="contractsCenterBox";
      panelBody.insertBefore(box, panelBody.firstChild);
    }
    // Jogadores emprestados a este clube não têm aqui nada para gerir — o contrato continua a
    // pertencer ao clube de origem, por isso ficam fora da Central de Contratos.
    const sorted=team.players.filter(p=>!p.emprestimo).slice().sort((a,b)=>contractYearsRemaining(a.contrato)-contractYearsRemaining(b.contrato));
    const period=marketPeriodForDate(state.currentDate);
    const expiring=sorted.filter(p=>contractYearsRemaining(p.contrato)<=1.05);
    const ratio=wageRevenueRatio(team);
    const contractAlert=expiring.length ? `<div class="market-status ${ratio>1?'no':'ok'}" style="margin-bottom:10px;"><b>${expiring.length} contrato(s) terminam no final da época.</b> Rácio salarial atual: ${Math.round(ratio*100)}% das receitas recorrentes. ${ratio>1?'São permitidas reduções, renovações neutras e exceções para jogadores indispensáveis ou mínimos de plantel.':'Planeia as renovações antes do defeso.'}</div>` : "";
    box.innerHTML = `
      <div class="eyebrow" style="margin-bottom:8px;">Janela de mercado</div>
      <div class="market-status ${period==='epoca'?'no':'ok'}" style="margin-bottom:4px;">${marketPeriodLabel(period)}</div>
      <div class="market-status ${registrationWindowOpenFor(state.currentDate)?'ok':'no'}" style="margin-bottom:14px;">${registrationWindowStatusLabel(state.currentDate)}</div>
      ${contractAlert}
      <div class="eyebrow" style="margin-bottom:8px;">Central de Contratos — ${team.name}</div>
      <div id="contractsCenterList">
      ${sorted.map(p=>{
        const yrs=contractYearsRemaining(p.contrato);
        const urgent = yrs<=1.05;
        const imp=playerSquadImportance(p,team);
        return `<div class="fixture-row" style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr auto auto;gap:8px;align-items:center;">
          <div>${playerNameHtml(p)} <span style="color:var(--texto-mute);font-size:11px;">${ROLE_LABELS[p.contrato?.papel]||'—'} · ${imp.label}</span></div>
          <div>${fmtMoney(p.contrato?.salarioMensal||0)}/mês</div>
          <div style="color:${urgent?'var(--vermelho)':'inherit'};">${p.contrato?p.contrato.dataFim:'—'}</div>
          <div>${contractStatusLabel(p)}</div>
          <button class="btn btn-ghost contract-renew-toggle" data-id="${p.id}">${state.uiNegotiationOpenId==='renov-'+p.id?'Fechar':'Renovar'}</button>
          <button class="btn btn-ghost contract-release" data-id="${p.id}">Dispensar</button>
        </div>
        ${state.uiNegotiationOpenId==='renov-'+p.id ? negotiationCardHtml("renovacao", p, team, team, "Renovação", {forceOpen:true, hideToggle:true}).replace('<div class="market-card negotiation-card"','<div class="market-card negotiation-card" style="margin-top:4px;"') : ''}`;
      }).join("") || '<p class="helptext">Sem jogadores no plantel.</p>'}
      </div>`;
    box.querySelectorAll(".contract-renew-toggle").forEach(btn=>btn.addEventListener("click",()=>{
      const id="renov-"+btn.getAttribute("data-id");
      state.uiNegotiationOpenId = state.uiNegotiationOpenId===id ? null : id;
      renderTransferMarket();
    }));
    wireNegotiationCards(box, renderTransferMarket);
    box.querySelectorAll(".contract-release").forEach(btn=>btn.addEventListener("click",()=>{
      if(!confirm("Dispensar este jogador? Ele fica disponível no mercado de jogadores livres.")) return;
      const r=releasePlayerToFreeAgency(btn.getAttribute("data-id"), team.id);
      if(!r.ok) alert(r.reason);
      renderTransferMarket(); renderRoster();
    }));
  }
  function renderFreeAgentsSection(team){
    const panelBody=document.querySelector("#viewMercado .panel-body");
    if(!panelBody) return;
    let box=document.getElementById("freeAgentsBox");
    if(!box){
      box=document.createElement("div");
      box.id="freeAgentsBox";
      const marketList=document.getElementById("marketList");
      panelBody.insertBefore(box, marketList ? marketList.nextSibling : null);
    }
    const agents=(state.freeAgents||[]);
    box.innerHTML = `<div class="eyebrow" style="margin:18px 0 8px;">Jogadores livres (${agents.length})</div>
      ${experienciaHeaderHtml()}
      ${agents.length ? agents.map(p=>negotiationCardHtml("livre-sign", p, null, team, "Livre")+experienciaRowHtml(p, team)).join("") : '<p class="helptext">Sem jogadores livres disponíveis de momento.</p>'}`;
    // 2026-10-16: antes assinava de imediato (signFreeAgentToTeam), sem aceitação do jogador, limite salarial,
    // limite de transferências ou propostas pendentes — a IA e a ficha do jogador já passam por
    // proposeContract("livre-sign"). Agora o Mercado faz o mesmo: proposta com resposta em 1-4 dias.
    wireNegotiationCards(box, renderTransferMarket);
  }
  // Secção "Negociações em curso" (2026-09-14, pedido do utilizador): agora que as propostas
  // demoram 1-4 dias a ter resposta, o utilizador precisa de ver o que está em aberto quando
  // volta ao Mercado — mesmo padrão já usado em renderAiOffersSection, para propostas enviadas
  // em vez de recebidas.
  function renderPendingNegotiationsSection(team){
    const clubPending=Object.values(state.transferNegotiations||{}).filter(n=>n&&n.estado==="pendente"&&(n.fromTeamId===team.id||n.toTeamId===team.id));
    const contractPending=Object.values(state.contractNegotiations||{}).filter(n=>n&&n.aguardaResposta&&(n.toTeamId===team.id||n.fromTeamId===team.id));
    const loanPending=Object.values(state.loanNegotiations||{}).filter(n=>n&&(n.estado==="pendente"||n.estado==="jogador-a-decidir")&&(n.ownerId===team.id||n.destinationId===team.id));
    const rows=[
      ...clubPending.map(n=>{const other=state.teams[n.fromTeamId===team.id?n.toTeamId:n.fromTeamId],player=state.teams[n.fromTeamId]&&state.teams[n.fromTeamId].players.find(p=>p.id===n.playerId);return {label:`${player?player.name:'Jogador'} — proposta de fee a ${other?other.name:'clube'}`,date:n.pendingResponseDate};}),
      ...contractPending.map(n=>{const toTeam=state.teams[n.toTeamId],player=toTeam&&(state.teams[n.fromTeamId]||toTeam).players.find(p=>p.id===n.playerId);return {label:`${player?player.name:'Jogador'} — proposta de contrato (${n.kind})`,date:n.pendingResponseDate};}),
      ...loanPending.map(n=>{const owner=state.teams[n.ownerId],player=owner&&owner.players.find(p=>p.id===n.playerId);return {label:`${player?player.name:'Jogador'} — ${n.estado==="jogador-a-decidir"?"empréstimo à espera da decisão do jogador":"pedido de empréstimo"}`,date:n.estado==="jogador-a-decidir"?n.playerResponseDate:n.responseDate};}),
    ].sort((a,b)=>String(a.date).localeCompare(String(b.date)));
    return `<div class="eyebrow" style="margin:16px 0 8px;">Negociações em curso (${rows.length})</div>
      ${rows.length?rows.map(r=>`<div class="fixture-row"><div>${escapeHtml(r.label)}</div><div>Resposta prevista para ${fmtDateShort(new Date(r.date+"T00:00:00Z"))}</div></div>`).join(""):'<p class="helptext">Sem negociações à espera de resposta.</p>'}`;
  }
  // 2026-10-12 (pedido do utilizador): o Mercado passa a ter sub-separadores. As secções são desenhadas
  // por funções diferentes (algumas criam a sua própria caixa no topo do painel); em vez de as reescrever,
  // cada caixa recebe um data-mtab e só a do separador ativo fica visível. Subir/descer jogadores entre a
  // equipa A e a B já não aparece aqui — só na ficha do jogador.
  const MERCADO_SEPARADORES = [
    { id:"negociacoes", label:"Propostas e negociações" },
    { id:"contratos",   label:"Contratos" },
    { id:"emprestimos", label:"Empréstimos" },
    { id:"livres",      label:"Jogadores livres" },
    { id:"lista",       label:"Lista de transferências" },
    { id:"listaEmp",    label:"Lista de empréstimos" },
    { id:"scouting",    label:"Scouting" },
    { id:"movimentos",  label:"Movimentos" }
  ];
  const MERCADO_CAIXAS = { aiOffersBox:"negociacoes", contractsCenterBox:"contratos", emprestimosBox:"emprestimos", freeAgentsBox:"livres" };
  let mercadoSeparadorAtivo = "negociacoes";
  function mercadoOrganizarSeparadores(){
    const body=document.querySelector("#viewMercado .panel-body"), bar=document.getElementById("mercadoSubtabs");
    if(!body||!bar) return;
    Object.keys(MERCADO_CAIXAS).forEach(id=>{ const el=document.getElementById(id); if(el) el.setAttribute("data-mtab", MERCADO_CAIXAS[id]); });
    if(body.firstChild!==bar) body.insertBefore(bar, body.firstChild);   // a barra fica sempre por cima das caixas (as caixas inserem-se antes dela)
    if(!MERCADO_SEPARADORES.some(x=>x.id===mercadoSeparadorAtivo)) mercadoSeparadorAtivo="negociacoes";
    bar.innerHTML=MERCADO_SEPARADORES.map(x=>`<button class="tactic-btn${x.id===mercadoSeparadorAtivo?" active":""}" data-mtab-btn="${x.id}">${x.label}</button>`).join("");
    body.querySelectorAll("[data-mtab]").forEach(el=>el.classList.toggle("hidden", el.getAttribute("data-mtab")!==mercadoSeparadorAtivo));
    bar.querySelectorAll("[data-mtab-btn]").forEach(b=>b.onclick=()=>{ mercadoSeparadorAtivo=b.getAttribute("data-mtab-btn"); mercadoOrganizarSeparadores(); });
  }
  // Abre o Mercado já no separador certo (ex.: "Responder →" numa proposta recebida vai a "Propostas e negociações").
  // Tem de ser chamado ANTES de setView("mercado"), que é quem desenha o separador ativo.
  function mercadoIrPara(id){ if(MERCADO_SEPARADORES.some(x=>x.id===id)) mercadoSeparadorAtivo=id; }
  function renderTransferMarket(){
    const t=myTeam();if(!t)return;initClubFinance(t);refreshTransferMarket();
    document.getElementById("marketSeasonLabel").textContent=`Época ${seasonLabel(state.season)}`;
    document.getElementById("marketBudgetLabel").textContent=`Orçamento: ${fmtMoney(t.financeiro.orcamentoTransferencias)}`;
    document.getElementById("marketClubAppeal").textContent=`Atratividade: ${Math.round(clubAppeal(t))}/99`;
    generateAiOffersForUser(false);renderAiOffersSection(t);renderEmprestimosSection(t);renderContractsCenter(t);
    const l=document.getElementById("marketList");
    // Correção (2026-09-14, pedido do utilizador: "isto não me interessa ver"): esta lista
    // mostrava TODOS os acordos de fee do jogo inteiro (qualquer par de clubes de IA, sem
    // qualquer relação com o utilizador) e nunca era limpa depois de o negócio se concretizar
    // (agora corrigido em applyAcceptedOffer, que apaga a sessão assim que o jogador muda de
    // clube) — confirmado por teste dedicado: 82 entradas numa simulação de 25 dias, 0 do
    // próprio clube, 45 já obsoletas. Passa a mostrar só os acordos do PRÓPRIO clube (comprador
    // ou vendedor) cujo jogador ainda não mudou de clube — os únicos genuinamente acionáveis.
    const active=Object.values(state.transferNegotiations||{}).filter(n=>{
      if(!n||n.estado!=="contrato") return false;
      if(n.fromTeamId!==t.id && n.toTeamId!==t.id) return false;
      const fromTeam=state.teams[n.fromTeamId];
      return fromTeam && fromTeam.players.some(p=>p.id===n.playerId);
    });
    l.innerHTML=`<div class="market-status ok"><b>Pesquisa por clubes e jogadores</b><br>Abre Competições, escolhe a competição e a equipa, e entra na ficha do jogador. A proposta é iniciada diretamente na ficha. Negociar é possível o ano inteiro — ${registrationWindowStatusLabel(state.currentDate)}</div>
      <div class="eyebrow" style="margin:16px 0 8px;">Acordos com clubes à espera de contrato (${active.length})</div>
      ${active.length?active.map(n=>{const fromTeam=state.teams[n.fromTeamId],toTeam=state.teams[n.toTeamId],player=fromTeam.players.find(p=>p.id===n.playerId);return `<div class="fixture-row"><div>${playerLinkHtml(fromTeam.id,player)}</div><div>${fmtMoney(n.valorAcordado)}</div><div>${n.toTeamId===t.id?`Comprado ao ${escapeHtml(fromTeam.name)}`:`Vendido ao ${escapeHtml(toTeam.name)}`} — fase contratual disponível na ficha do jogador</div></div>`;}).join(""):'<p class="helptext">Sem acordos pendentes.</p>'}
      ${renderPendingNegotiationsSection(t)}`;
    renderFreeAgentsSection(t);
    // Correção (2026-09-17, pedido do utilizador: "tenho uma quantidade absurda de
    // transferencias. isto nao é a realidade do hoquei"): esta lista mostrava TODOS os negócios
    // fechados no jogo inteiro — os ~125 clubes das 3 competições (Portugal, OK Liga, Serie A1)
    // misturados sem distinção nenhuma (confirmado: 70 entradas numa simulação de 25 dias, das
    // quais 35 em Espanha/Itália, um país que o utilizador nem sequer joga). Um adepto português
    // não acompanha o mercado espanhol e italiano misturado com o seu — mesmo critério já usado
    // acima em "Acordos com clubes à espera de contrato" (só o que é relevante para o utilizador).
    // Passa a mostrar só negócios com pelo menos um clube do MESMO país do utilizador.
    const userCountry=teamCountry(t);
    const nameToTeamHist={};Object.values(state.teams).forEach(tm=>{nameToTeamHist[tm.name]=tm;});
    const relevantHistory=state.transferHistory.filter(x=>{
      const ft=nameToTeamHist[x.from],tt=nameToTeamHist[x.to];
      return (ft&&teamCountry(ft)===userCountry)||(tt&&teamCountry(tt)===userCountry);
    });
    const countryLabelHist=(COMPETITION_VIEW_GROUPS.find(g=>g.pais===userCountry)||{}).label||"";
    const marketHistoryLabelEl=document.getElementById("marketHistoryLabel");
    if(marketHistoryLabelEl) marketHistoryLabelEl.textContent=`Movimentos recentes${countryLabelHist?` — ${countryLabelHist}`:""}`;
    document.getElementById("marketHistory").innerHTML=relevantHistory.slice(0,40).map(x=>`<div class="fixture-row"><div>${x.player}</div><div>${x.from} → ${x.to}</div><div>${fmtMoney(x.value)}</div></div>`).join("")||"Sem movimentos.";
    renderTransferListSection(t);
    if(typeof renderLoanListSection==="function") renderLoanListSection(t);
    renderScoutingReportsSection(t);
    if(typeof scintRender==="function") scintRender(t);
    mercadoOrganizarSeparadores();
  }
  // Marco T: submenu "Lista de Transferências" — mostra todos os jogadores que OUTROS clubes (nunca
  // os do próprio utilizador) colocaram no mercado (transferListado), com valor de mercado e valor
  // pedido lado a lado. Mesmo critério de "relevância" já usado no resto do Mercado (só o país do
  // utilizador — ver renderTransferMarket acima) e mesmo padrão de nomes clicáveis (playerLinkHtml/
  // teamLinkHtml, com listener global já existente, sem precisar de registar nada aqui).
  function renderTransferListSection(t){
    const box = document.getElementById("transferListSection");
    if(!box) return;
    const userCountry = teamCountry(t);
    const entries = [];
    Object.values(state.teams).forEach(club=>{
      if(!club || club.id===t.id || club.id===t.equipaBId) return; // nunca os do próprio utilizador
      if(club.nuvemEuropeia||club.selecaoNacional) return;
      if(teamCountry(club)!==userCountry) return;
      (club.players||[]).filter(p=>p.transferListado && p.valorPedido && !p.emprestimo).forEach(p=>{
        entries.push({ player:p, club, marketValue: playerMarketValue(p, club) });
      });
    });
    entries.sort((a,b)=> (b.player.valorPedido||0) - (a.player.valorPedido||0));
    if(!entries.length){
      box.innerHTML = '<p class="helptext">Nenhum clube colocou jogadores no mercado neste momento.</p>';
      return;
    }
    box.innerHTML = entries.map(e=>{
      const p=e.player;
      return `<div class="fixture-row">
        <div>${playerLinkHtml(e.club.id,p)}<div class="meta">${teamLinkHtml(e.club.id)} · ${linhaAbbrev(p)} · ${p.age} anos</div></div>
        <div>Valor de mercado: ${fmtMoney(e.marketValue)}</div>
        <div>Pedido: ${fmtMoney(p.valorPedido)}</div>
      </div>`;
    }).join("");
  }

  // ============================= Fase 15: Direção, sustentabilidade e orçamento =============================
  function evaluateSponsorObjective(objetivo, finalPos, totalTeams, champion, relegated){
    const text=(objetivo||"").toLowerCase();
    if(text.includes("campeonato")||text.includes("título")) return !!champion;
    if(text.includes("descida")||text.includes("descer")) return !relegated;
    if(text.includes("manter")||text.includes("consolidar")||text.includes("manutenç")) return !relegated;
    if(text.includes("primeiros")){
      const m=text.match(/(\d+)/); const n=m?parseInt(m[1],10):6;
      return finalPos!=null && finalPos<=n;
    }
    if(text.includes("metade")) return finalPos!=null && totalTeams>0 && finalPos<=Math.ceil(totalTeams/2);
    return finalPos!=null && totalTeams>0 && finalPos<=Math.ceil(totalTeams/2);
  }
  // Objetivo da Taça de Portugal: a fasquia varia com a dimensão do clube — um gigante deve
  // pelo menos chegar aos Quartos, um clube médio aos Oitavos, os restantes só precisam de
  // passar dos 32 Avos (ou da Pré-Eliminatória, quando aplicável). Equipas B não participam na
  // Taça (regulamento), por isso não têm este objetivo.
  function tacaTargetPhaseIndex(team){
    const rep=normalizeClubReputation(team.reputacao, team);
    if(rep>=75) return TACA_FASES.indexOf("quartos");
    if(rep>=55) return TACA_FASES.indexOf("oitavos");
    return TACA_FASES.indexOf("32avos");
  }
  function tacaProgressReachedIndex(teamId){
    const tp=state.tacaPortugal; if(!tp) return -1;
    const alvoId=teamId||state.userTeamId;
    let reached=-1;
    TACA_FASES.forEach((fase,idx)=>{
      const jogoDoClube=(tp.jogos[fase]||[]).find(j=>j.home===alvoId||j.away===alvoId);
      if(jogoDoClube && jogoDoClube.played && tacaTieWinner(jogoDoClube)===alvoId) reached=idx;
    });
    return reached;
  }
  // Barómetro contínuo de confiança da direção (pedido do utilizador, 2026-09-14): "um indicador
  // que sobe/desce jogo a jogo (como já acontece com o moral dos jogadores) dava aviso do risco
  // antes do 'penhasco' do fim de época" — hoje evaluateDirectionGoals só corre uma vez por ano.
  // Decidido explicitamente: fica só como aviso, sem poder despedir a meio da época — o
  // despedimento continua a decidir-se só em checkManagerSacking, no fim da época, sem alterações
  // a essa regra. O que mexe na confiança, também por decisão explícita: o resultado do jogo mais
  // o desempenho face à posição-alvo do objetivo da época (mesmo texto de
  // financeiro.sponsorObjetivo já usado em evaluateSponsorObjective), não só vitória/derrota
  // simples como acontece com o moral dos jogadores.
  function directionObjectiveTargetPosition(team, totalTeams){
    const total = totalTeams>0 ? totalTeams : 14;
    const presAlvo = typeof presAlvoPosicao==="function" ? presAlvoPosicao(team, total) : null;
    if(presAlvo!=null) return presAlvo;
    const text = ((team.financeiro && team.financeiro.sponsorObjetivo) || "").toLowerCase();
    if(text.includes("campeonato") || text.includes("título")) return 1;
    if(text.includes("primeiros")){
      const m = text.match(/(\d+)/);
      return m ? clamp(parseInt(m[1],10), 1, total) : Math.ceil(total/2);
    }
    if(text.includes("metade")) return Math.ceil(total/2);
    // "não descer"/"manter"/"consolidar"/"manutenção" (este último é o texto real gerado por
    // genericObjetivoDesportivo para clubes de reputação mais baixa — ver 04-financas.js:198):
    // a fasquia real é só evitar a descida — folga de 3 posições acima da zona de despromoção,
    // para não pintar de vermelho um empate tranquilo.
    if(text.includes("manter") || text.includes("consolidar") || text.includes("manutenç") || text.includes("descida") || text.includes("descer")) return Math.max(1, total-3);
    return Math.ceil(total/2);
  }
  function directionConfidenceTier(value){
    if(value>=75) return { label:"Muito confiante", cls:"ok" };
    if(value>=50) return { label:"Confiante", cls:"ok" };
    if(value>=30) return { label:"Preocupada", cls:"no" };
    return { label:"Muito descontente", cls:"no" };
  }
  // Generalizado (2026-09-23, mercado de treinadores): passou a correr para TODOS os clubes, não
  // só o do utilizador — chamado agora a partir de registerTreinadorMatchResult
  // (08c-staff-treinadores.js), o ponto único e universal de registo de resultados (liga, taça,
  // playoff, para ambos os lados de qualquer jogo). É o barómetro contínuo que alimenta o gatilho
  // de despedimento por falta de confiança dos treinadores da IA (ver processTreinadorConfiancaMonthly).
  function updateDirectionConfidenceAfterMatch(team, result){
    if(!team) return;
    initClubFinance(team);
    if(team.confiancaDirecao==null) team.confiancaDirecao = 60;
    const comp = Object.values(state.competitions).find(c=>c.teamIds.includes(team.id));
    const tb = comp ? standingsForCompetition(comp.id) : [];
    const pos = tb.length ? (tb.findIndex(x=>x.id===team.id)+1||null) : null;
    const total = tb.length || 14;
    const target = directionObjectiveTargetPosition(team, total);
    const resultDelta = result==="V" ? 2 : result==="E" ? 0 : -2.5;
    // A posição na tabela só é um sinal fiável a partir de algumas jornadas — com 0-2 jogos
    // disputados todos os clubes estão empatados a pontos e a posição vem só do desempate (em
    // grande parte arbitrário), o que produziria oscilações sem sentido (ex: a 1ª vitória da
    // época a "baixar" a confiança só por causa da posição de pré-época). Por isso o fator de
    // posição só entra em jogo a partir da 3ª jornada (encontrado durante a verificação desta
    // funcionalidade, 2026-09-14).
    const jogosDisputados = team.stats ? (team.stats.J||0) : 0;
    // posGap positivo = estás melhor classificado do que o objetivo pede; negativo = pior.
    const posGap = (pos!=null && jogosDisputados>=3) ? (target-pos) : 0;
    const posDelta = clamp(posGap*0.35, -3, 3);
    const delta = clamp(resultDelta+posDelta, -4, 3);
    const deltaPerfil = typeof presMultConfianca==="function" ? presMultConfianca(team, delta) : delta;
    team.confiancaDirecao = roundDecimal(clamp(team.confiancaDirecao+deltaPerfil, 0, 100));
  }
  // ===== Reação da direção aos resultados (pedido do utilizador, 2026-10-05) =====
  // "quero que a direção envie emails a demonstrar desagrado ou encantado por determinado
  // resultado, seja contra um clube de divisão superior ou inferior, um resultado dilatado contra
  // um adversário difícil ou um derbi. deve mexer ligeiramente na avaliação da direção."
  // Só para o clube do utilizador (a equipa principal) e só para resultados que merecem reação —
  // a maior parte dos jogos (vitória normal em casa, derrota normal, empate banal) não gera
  // email nenhum, para a caixa não ficar entupida. No máximo UM email por jogo (a situação mais
  // notável ganha), e o ajuste à confiança da direção é sempre pequeno (entre -1,5 e +1,5, a
  // somar ao que updateDirectionConfidenceAfterMatch já ajustou por V/E/D e posição).
  const DIRECAO_MARGEM_DILATADA = 4;      // diferença de golos que conta como resultado "dilatado"
  const DIRECAO_DIFICIL_REP_GAP = 6;      // pontos de reputação acima do nosso = adversário "difícil"
  function directionPickVariant(list, seed){
    let h = 0; const str = String(seed);
    for(let i=0;i<str.length;i++) h = (h*31 + str.charCodeAt(i)) >>> 0;
    return list[h % list.length];
  }
  // Núcleo puro e testável: dado o contexto de um jogo do utilizador, devolve a reação da direção
  // ({tom, delta, titulo, texto}) ou null se o resultado não merece reação.
  function directionMatchReaction(ctx){
    const { me, opp, gf, ga, venceu, perdeu, derby, seed } = ctx;
    const margem = Math.abs(gf-ga);
    const tierMe = DIVISION_TIER[me.divisaoAtual] || 1, tierOpp = DIVISION_TIER[opp.divisaoAtual] || 1;
    const oppSuperior = tierOpp < tierMe, oppInferior = tierOpp > tierMe;
    const repGap = (opp.reputacaoClube||50) - (me.reputacaoClube||50);
    const dificil = oppSuperior || repGap >= DIRECAO_DIFICIL_REP_GAP;
    const dilatado = margem >= DIRECAO_MARGEM_DILATADA;
    const placar = `${gf}-${ga}`, opn = opp.name;
    const V = (list)=>directionPickVariant(list, seed);
    // 1) Derbi — o jogo que mais importa aos adeptos.
    if(derby){
      if(venceu){
        const forte = margem>=3;
        return { tom:"agrado", delta: forte?1.3:1.0,
          titulo: V(["Derbi ganho — a direção está encantada","Vitória no derbi: os adeptos em festa"]),
          texto: V([
            `Ganhar o derbi frente ao ${opn} (${placar}) é o melhor resultado possível${forte?", e de forma tão categórica":""}. A direção quer felicitar publicamente o plantel e a equipa técnica — os adeptos vão falar disto durante semanas.`,
            `O ${placar} frente ao ${opn} caiu muito bem em toda a estrutura do clube. Num derbi, vencer vale por muito mais do que três pontos. Parabéns, treinador.`]) };
      }
      if(perdeu){
        const forte = margem>=3;
        return { tom:"desagrado", delta: forte?-1.5:-1.2,
          titulo: V(["Derbi perdido — a direção está desagradada","Derrota no derbi: os adeptos exigem uma reação"]),
          texto: V([
            `Perder o derbi frente ao ${opn} (${placar}) é um resultado que a direção não aceita facilmente${forte?", sobretudo com esta diferença":""}. Os adeptos estão revoltados e esperamos uma reação imediata da equipa.`,
            `O ${placar} no derbi com o ${opn} deixou a direção muito preocupada. Este é o jogo que não se pode perder. Contamos consigo para virar a página já na próxima jornada.`]) };
      }
      return { tom:"neutro", delta:0,
        titulo:"Empate no derbi",
        texto:`O empate (${placar}) no derbi frente ao ${opn} sabe a pouco. A direção compreende que num jogo destes o equilíbrio é grande, mas esperava mais do nosso lado.` };
    }
    // 2) Adversário de outra divisão.
    if(oppSuperior && venceu){
      return { tom:"agrado", delta: dilatado?1.4:1.0,
        titulo:"Vitória contra um clube de divisão superior",
        texto: V([
          `Vencer o ${opn}, de uma divisão acima da nossa (${placar}), é um feito de que o clube se vai orgulhar. A direção está encantada com a atitude de todo o grupo.`,
          `Um clube de escalão superior, o ${opn}, e uma vitória por ${placar}. A direção quer deixar um agradecimento especial ao plantel e à equipa técnica por esta exibição.`]) };
    }
    if(oppInferior && perdeu){
      return { tom:"desagrado", delta: dilatado?-1.5:-1.2,
        titulo:"Derrota contra um clube de divisão inferior",
        texto: V([
          `Perder frente ao ${opn}, de uma divisão abaixo da nossa (${placar}), é inaceitável. A direção está muito desagradada e exige explicações sobre a preparação deste jogo.`,
          `O ${placar} frente ao ${opn}, um clube de escalão inferior, é um resultado que mancha a imagem do clube. A direção espera uma resposta forte já na próxima partida.`]) };
    }
    if(oppInferior && !venceu && !perdeu){
      return { tom:"desagrado", delta:-0.5,
        titulo:"Empate contra um clube de divisão inferior",
        texto:`Empatar com o ${opn} (${placar}), de uma divisão abaixo da nossa, soube a derrota. A direção esperava mais de uma equipa com a nossa ambição.` };
    }
    // 3) Resultado dilatado.
    if(dilatado && venceu && dificil){
      return { tom:"agrado", delta:1.2,
        titulo:"Goleada frente a um adversário difícil",
        texto: V([
          `Um ${placar} frente ao ${opn}, um adversário desta dimensão, é uma exibição de gala. A direção está encantada e quer felicitar todo o grupo.`,
          `Poucos esperavam uma vitória tão larga (${placar}) contra o ${opn}. A direção sente-se muito satisfeita com a qualidade e a ambição demonstradas.`]) };
    }
    if(dilatado && perdeu){
      if(dificil){
        return { tom:"desagrado", delta:-1.0,
          titulo:"Derrota pesada frente a um adversário forte",
          texto:`Sabíamos que o ${opn} era um adversário difícil, mas um ${placar} é uma diferença excessiva. A direção está preocupada com a forma como a equipa se desmoronou.` };
      }
      return { tom:"desagrado", delta:-1.5,
        titulo:"Derrota pesada — a direção exige explicações",
        texto: V([
          `Perder por ${placar} frente ao ${opn} é um resultado vexatório. A direção está profundamente desagradada e espera uma reação imediata da equipa.`,
          `O ${placar} frente ao ${opn} não se pode repetir. A direção quer uma conversa séria sobre o que correu mal e sobre o que vai mudar.`]) };
    }
    return null;
  }
  // Ponto de ligação ao jogo: chamado por applyStandings (06-motor-jogo.js) para QUALQUER
  // resultado registado; só reage quando um dos lados é a equipa principal do utilizador.
  function directionReactToUserMatch(homeId, awayId, hs, as, soWinner){
    const uid = state.userTeamId;
    if(!uid || (homeId!==uid && awayId!==uid)) return null;
    const me = state.teams[uid], opp = state.teams[homeId===uid ? awayId : homeId];
    if(!me || !opp || opp.equipaPrincipalId || opp.nuvemEuropeia || opp.selecaoNacional || me.selecaoNacional) return null;
    const gf = homeId===uid ? hs : as, ga = homeId===uid ? as : hs;
    let venceu = gf>ga, perdeu = gf<ga;
    if(gf===ga && soWinner){ venceu = (soWinner==="home")===(homeId===uid); perdeu = !venceu; }
    const reacao = directionMatchReaction({ me, opp, gf, ga, venceu, perdeu, derby: (typeof derbyNivel==="function" ? derbyNivel(uid, opp.id)!==2 && derbyNivel(uid, opp.id)>0 : isDerby(uid, opp.id)), seed: `${isoDate(state.currentDate)}|${uid}|${opp.id}` });
    if(!reacao) return null;
    initClubFinance(me);
    if(me.confiancaDirecao==null) me.confiancaDirecao = 60;
    me.confiancaDirecao = roundDecimal(clamp(me.confiancaDirecao + reacao.delta, 0, 100));
    pushNews(state.currentDate, reacao.texto, "direcao", reacao.titulo, { teamId: uid });
    return reacao;
  }
  function evaluateDirectionGoals(team){
    initClubFinance(team);
    // Presidentes e objetivos (2026-10-14, 08y-presidentes.js): para os clubes principais, a direção
    // fixa 1 objetivo principal + secundários em cada época; substituem as metas fixas antigas
    // (saldo, massa salarial, sub-23, patrocinador, Taça), que continuam abaixo só para equipas B
    // e como reserva. O objetivo do patrocinador continua a ser avaliado (sponsorOk) para os bónus.
    if(typeof presAvaliar==="function" && presElegivelNaEpoca(team)){
      const r=presAvaliar(team);
      const compP=seasonEndCompetitionOf(team.id);
      const tbP=compP?seasonEndTable(compP.id):[];
      const sponsorOkP=evaluateSponsorObjective(team.financeiro.sponsorObjetivo, r.snap.finalPos, tbP.length, r.snap.champion, r.snap.relegated);
      return { goals:r.goals, passed:r.passed, total:r.total, taxa:r.taxa, principalOk:r.principalOk, sponsorOk:sponsorOkP, finalPos:r.snap.finalPos, champion:r.snap.champion, relegated:r.snap.relegated, wageRatio:r.snap.wageRatio };
    }
    const comp=seasonEndCompetitionOf(team.id);
    const tb=comp?seasonEndTable(comp.id):[];
    const finalPos=tb.findIndex(x=>x.id===team.id)+1||null;
    const champion=state.placardChampion===team.id || state.okLigaChampion===team.id || state.serieA1Champion===team.id;
    const relegated=!!(state.promotionEvent && ((state.promotionEvent.relegated||[]).includes(team.id) || (state.promotionEvent.relegatedToThird||[]).includes(team.id) || (state.promotionEvent.relegatedEs||[]).includes(team.id)));
    const wageRatio=wageToBudgetRatio(team);
    const usedSub23=team.players.some(p=>p.age<=23 && (p.season.jogos||0)>0);
    const sponsorOk=evaluateSponsorObjective(team.financeiro.sponsorObjetivo, finalPos, tb.length, champion, relegated);
    const goals=[
      {label:"Saldo positivo", ok: team.financeiro.saldo>=0},
      {label:"Massa salarial abaixo de 70%", ok: wageRatio<0.7},
      {label:`Objetivo do patrocinador (${team.financeiro.sponsorObjetivo})`, ok: sponsorOk},
      {label:"Utilizar pelo menos um sub-23", ok: usedSub23},
    ];
    // Clubes estrangeiros (OK Liga/Espanha, Serie A1/Itália) não participam na Taça de Portugal —
    // sem esta exceção, ficariam sempre com este objetivo por cumprir (falso "falhanço" permanente).
    if(!team.equipaPrincipalId && teamCountry(team)==="pt"){
      const alvo=tacaTargetPhaseIndex(team);
      const alcancado=tacaProgressReachedIndex(team.id);
      goals.push({label:`Taça de Portugal — chegar a ${TACA_FASE_LABEL[TACA_FASES[alvo]].replace('Taça de Portugal — ','')}`, ok: alcancado>=alvo});
    }
    return { goals, passed: goals.filter(g=>g.ok).length, total: goals.length, finalPos, champion, relegated, wageRatio };
  }
  function recordDirectionEvaluation(team){
    const result=evaluateDirectionGoals(team);
    if(!Array.isArray(team.avaliacaoDirecao)) team.avaliacaoDirecao=[];
    team.avaliacaoDirecao.unshift({ epoca: seasonLabel(state.season), ...result });
    if(result.taxa!=null && typeof presFimDeEpoca==="function") presFimDeEpoca(team,result);
    if(team.avaliacaoDirecao.length>10) team.avaliacaoDirecao.length=10;
    return result;
  }
  function directionHealthTier(team){
    initClubFinance(team);
    const wageTier=wageHealthTier(wageToBudgetRatio(team));
    if(team.financeiro.divida>0 || wageTier==="risco") return "risco";
    if(team.financeiro.saldo<50000 || wageTier==="atencao") return "atencao";
    return "saudavel";
  }
  // ============================= Investimento em infraestrutura (pedido à direção) =============================
  // Pedido do utilizador (2026-09-05): subir as condições de treino ou a capacidade do pavilhão
  // não devia ser uma ação instantânea e livre do utilizador — devia passar por um pedido formal à
  // direção, que demora pelo menos duas semanas a responder (resposta binária: aprova ou recusa) e
  // que só pode voltar a ser pedido 8 meses depois. Corre de forma simétrica para clubes de IA.
  function ensureTeamDirecaoInvestimentos(team){
    team.direcaoInvestimentos=team.direcaoInvestimentos&&typeof team.direcaoInvestimentos==="object"?team.direcaoInvestimentos:{pedidos:[]};
    team.direcaoInvestimentos.pedidos=Array.isArray(team.direcaoInvestimentos.pedidos)?team.direcaoInvestimentos.pedidos:[];
    return team.direcaoInvestimentos;
  }
  // "scouting" (2026-09-05): subir o nível do departamento de scouting junta-se aqui aos outros
  // dois tipos de investimento — mesmo prazo de resposta, mesma aprovação binária, mesmo
  // cooldown de 8 meses entre pedidos do mesmo tipo.
  const DIRECAO_INVESTIMENTO_TIPO_LABEL = { treino:"condições de treino", pavilhao:"capacidade do pavilhão", scouting:"departamento de scouting", medico:"departamento médico", obra:"obras no pavilhão" };
  function nextTrainingLevel(team){const i=TRAINING_LEVELS.indexOf(team.condicoesTreino);return i>=0&&i<TRAINING_LEVELS.length-1?TRAINING_LEVELS[i+1]:null;}
  function trainingUpgradeCost(team){
    const next=nextTrainingLevel(team);if(!next)return null;
    const delta=(TRAINING_MONTHLY_COST[next]||0)-(TRAINING_MONTHLY_COST[team.condicoesTreino]||0);
    return Math.max(1000,Math.round(delta*DIRECAO_INVESTIMENTO_CONFIG.treinoMesesCusto*clubFinancialStructureFactor(team)));
  }
  function pavilionUpgradeStep(team){initClubFinance(team);return Math.max(50,Math.round((team.financeiro.capacidadePavilhao||1000)*DIRECAO_INVESTIMENTO_CONFIG.pavilhaoPassoFrac));}
  function pavilionUpgradeCost(team){
    const step=pavilionUpgradeStep(team);
    return Math.max(2000,Math.round(step*DIRECAO_INVESTIMENTO_CONFIG.pavilhaoCustoPorLugar*clubFinancialStructureFactor(team)));
  }
  function directionInvestmentLastRequest(team,tipo,obraTipo){
    const store=ensureTeamDirecaoInvestimentos(team);
    return store.pedidos.filter(p=>p.tipo===tipo&&(tipo!=="obra"||p.obraTipo===obraTipo)).sort((a,b)=>new Date(b.dataPedido)-new Date(a.dataPedido))[0]||null;
  }
  // extra.obraTipo (tipo "obra", 2026-10-12): obras do pavilhão (piso, iluminação, conforto, bar, camarotes) —
  // nunca arrancam por decisão do treinador: a direção avalia e aprova sempre, como nos restantes investimentos.
  function requestDirectionInvestment(team,tipo,date,extra){
    ensureTeamDirecaoInvestimentos(team);initClubFinance(team);
    const d=date||state.currentDate||new Date(),store=team.direcaoInvestimentos;
    const obraTipo=tipo==="obra"&&extra?extra.obraTipo:null;
    const last=directionInvestmentLastRequest(team,tipo,obraTipo);
    if(last){
      const diasDesde=Math.round((new Date(d)-new Date(last.dataPedido))/86400000);
      if(diasDesde<DIRECAO_INVESTIMENTO_CONFIG.cooldownDias)return{outcome:"recusa",reason:`A direção só volta a avaliar este tipo de investimento passados 8 meses do último pedido (faltam cerca de ${Math.ceil((DIRECAO_INVESTIMENTO_CONFIG.cooldownDias-diasDesde)/30)} meses).`};
    }
    if(store.pedidos.some(p=>p.tipo===tipo&&p.estado==="pendente"&&(tipo!=="obra"||p.obraTipo===obraTipo)))return{outcome:"recusa",reason:"Já há um pedido deste tipo à espera de resposta da direção."};
    if(tipo==="obra"&&store.pedidos.some(p=>p.tipo==="obra"&&p.estado==="pendente"))return{outcome:"recusa",reason:"A direção já está a avaliar outro pedido de obras no pavilhão."};
    let custo,detalhe;
    if(tipo==="obra"){
      const chk=pavilhaoPodeIniciarObra(team,obraTipo);
      if(!chk.ok)return{outcome:"recusa",reason:chk.reason};
      custo=chk.custo!=null?chk.custo:pavilhaoCustoObra(team,obraTipo);detalhe={obraTipo,obraLabel:PAV_OBRAS[obraTipo].label};
    }else if(tipo==="treino"){
      const next=nextTrainingLevel(team);
      if(!next)return{outcome:"recusa",reason:"As condições de treino já estão no nível máximo (Excelentes)."};
      custo=trainingUpgradeCost(team);detalhe={alvoNivel:next};
    }else if(tipo==="pavilhao"){
      if(team.pavilhao&&team.pavilhao.obra)return{outcome:"recusa",reason:"Já há uma obra em curso no pavilhão."};
      const step=pavilionUpgradeStep(team);
      custo=pavilionUpgradeCost(team);detalhe={incremento:step,alvoCapacidade:(team.financeiro.capacidadePavilhao||0)+step};
    }else if(tipo==="scouting"){
      const next=nextScoutingLevel(team);
      if(next==null)return{outcome:"recusa",reason:"O departamento de scouting já está no nível máximo."};
      custo=scoutingLevelUpgradeCost(team);detalhe={alvoNivel:next};
    }else if(tipo==="medico"){
      const next=nextMedicalLevel(team);
      if(next==null)return{outcome:"recusa",reason:"O departamento médico já está no nível máximo."};
      custo=medicalLevelUpgradeCost(team);detalhe={alvoNivel:next};
    }else return{outcome:"recusa",reason:"Tipo de investimento desconhecido."};
    const f=team.financeiro;
    if((f.divida||0)>0)return{outcome:"recusa",reason:"O clube tem dívida por regularizar — a direção não autoriza investimentos de capital nesta condição."};
    const reserva=financeSurvivalReserve(team,DIRECAO_INVESTIMENTO_CONFIG.reservaMesesSobrevivencia);
    if((f.saldo||0)-custo<reserva)return{outcome:"recusa",reason:"Este investimento poria em causa a reserva mínima de sobrevivência do clube."};
    const rng=makeSeededRng(`direcao-investimento:${team.id}:${tipo}:${isoDate(d)}`);
    const dias=Math.round(seededRnd(rng,DIRECAO_INVESTIMENTO_CONFIG.respostaMinDias,DIRECAO_INVESTIMENTO_CONFIG.respostaMaxDias));
    const dataResposta=addDays(d,dias);
    const pedido={id:`${team.id}:${tipo}${obraTipo?":"+obraTipo:""}:${isoDate(d)}`,tipo,dataPedido:isoDate(d),dataResposta:isoDate(dataResposta),estado:"pendente",custo,...detalhe};
    store.pedidos.unshift(pedido);if(store.pedidos.length>30)store.pedidos=store.pedidos.slice(0,30);
    // Correção (2026-09-17, apontada pelo utilizador): este email tem de vir DA direção a
    // confirmar receção, não do próprio treinador (era isso que managerEmailAddress fazia,
    // por engano copiado do padrão de "proposta enviada" do mercado, onde faz sentido ser o
    // próprio a falar). O remetente por omissão de resolveNewsSender("direcao",...) já é
    // direcao@<clube>.<tld>.
    if(isUserControlledTeam(team))pushNews(d,`Recebemos o teu pedido de investimento em ${DIRECAO_INVESTIMENTO_TIPO_LABEL[tipo]}${detalhe&&detalhe.obraLabel?` (${detalhe.obraLabel})`:""} e vamos analisá-lo. Resposta prevista para ${fmtDateShort(dataResposta)}.`,"direcao","Pedido de investimento recebido");
    return{outcome:"pendente",pedido};
  }
  function resolvePendingDirectionInvestments(date){
    Object.values(state.teams).forEach(team=>{
      if(team.equipaPrincipalId)return;
      const store=ensureTeamDirecaoInvestimentos(team);
      store.pedidos.forEach(p=>{
        if(p.estado!=="pendente")return;
        if(new Date(date)<new Date(p.dataResposta))return;
        initClubFinance(team);const f=team.financeiro,tier=directionHealthTier(team);
        let aprovado=true,motivo=null;
        if((f.divida||0)>0){aprovado=false;motivo="O clube acumulou dívida entretanto.";}
        else if(tier==="risco"){aprovado=false;motivo="A saúde financeira do clube deteriorou-se durante a avaliação.";}
        else{
          const reserva=financeSurvivalReserve(team,DIRECAO_INVESTIMENTO_CONFIG.reservaMesesSobrevivencia);
          if((f.saldo||0)-p.custo<reserva){aprovado=false;motivo="O clube deixou de ter fundos suficientes para este investimento.";}
          else if(tier==="atencao"){
            const ultima=(team.avaliacaoDirecao||[])[0],taxa=ultima?presTaxaAvaliacao(ultima):1;
            const minTaxa=typeof presInvestimentoMinTaxa==="function"?presInvestimentoMinTaxa(team):DIRECAO_INVESTIMENTO_CONFIG.atencaoMinTaxaObjetivos;
            if(taxa<minTaxa){aprovado=false;motivo="A direção quer ver mais objetivos cumpridos antes de autorizar este investimento.";}
          }
        }
        if(aprovado&&p.tipo==="obra"){
          // As obras do pavilhão só arrancam depois de aprovadas: a 1.ª metade do custo é paga agora, a 2.ª no fim.
          const ro=pavilhaoIniciarObra(team,p.obraTipo,{});
          if(ro.ok){
            p.estado="aprovado";
            if(isUserControlledTeam(team))pushNews(date,`A direção aprovou as obras no pavilhão: ${escapeHtml(p.obraLabel||p.obraTipo)} (${fmtMoney(ro.custo)}).`,"direcao","Investimento aprovado pela direção",{autoAdvanceStop:true});
          }else{
            p.estado="recusado";p.motivoRecusa=ro.reason;
            if(isUserControlledTeam(team))pushNews(date,`A direção recusou o pedido de investimento em ${DIRECAO_INVESTIMENTO_TIPO_LABEL.obra}: ${ro.reason}`,"direcao","Investimento recusado pela direção",{autoAdvanceStop:true});
          }
          return;
        }
        if(aprovado){
          const descricao=p.tipo==="treino"?`Obras de melhoria das condições de treino (para ${p.alvoNivel})`:p.tipo==="pavilhao"?`Ampliação da capacidade do pavilhão (+${p.incremento} lugares)`:p.tipo==="medico"?`Reforço do departamento médico (para o nível ${p.alvoNivel})`:`Reforço do departamento de scouting (para o nível ${p.alvoNivel})`;
          addFinanceMovement(team,"despesa","Investimento",descricao,p.custo,date);
          if(p.tipo==="treino")team.condicoesTreino=p.alvoNivel;
          else if(p.tipo==="pavilhao"){const ro=pavilhaoIniciarObra(team,"ampliacao",{custoPago:true,custo:p.custo,alvoCapacidade:p.alvoCapacidade});if(!ro.ok)f.capacidadePavilhao=p.alvoCapacidade;}
          else if(p.tipo==="scouting")ensureTeamScouting(team).departamento.nivel=p.alvoNivel;
          else if(p.tipo==="medico"){ensureTeamMedico(team).nivel=p.alvoNivel;team.medico.gerido=true;}
          p.estado="aprovado";
          const msgAprovado=p.tipo==="treino"?`A direção aprovou o investimento nas condições de treino — o clube sobe para "${p.alvoNivel}".`:p.tipo==="pavilhao"?`A direção aprovou a ampliação do pavilhão para ${p.alvoCapacidade} lugares.`:p.tipo==="medico"?`A direção aprovou o reforço do departamento médico — sobe para o nível ${p.alvoNivel}.`:`A direção aprovou o reforço do departamento de scouting — sobe para o nível ${p.alvoNivel}.`;
          if(isUserControlledTeam(team))pushNews(date,msgAprovado,"direcao","Investimento aprovado pela direção",{autoAdvanceStop:true});
        }else{
          p.estado="recusado";p.motivoRecusa=motivo;
          if(isUserControlledTeam(team))pushNews(date,`A direção recusou o pedido de investimento em ${DIRECAO_INVESTIMENTO_TIPO_LABEL[p.tipo]}: ${motivo}`,"direcao","Investimento recusado pela direção",{autoAdvanceStop:true});
        }
      });
    });
  }
  // Simetria para clubes de IA: quando saudáveis e sem pedido recente/pendente de um dado tipo,
  // arriscam periodicamente um pedido próprio (probabilidade modesta por mês, para não subirem
  // todos em bloco assim que ficam elegíveis).
  function maybeAiRequestDirectionInvestment(team,date){
    if(isUserControlledTeam(team)||team.equipaPrincipalId)return;
    initClubFinance(team);
    if(directionHealthTier(team)!=="saudavel")return;
    const rng=makeSeededRng(`direcao-investimento-ia:${team.id}:${isoDate(date)}`);
    ["treino","pavilhao"].forEach(tipo=>{
      if(seededRndFloat(rng,0,1)>0.2)return;
      requestDirectionInvestment(team,tipo,date);
    });
  }

  // ============================= Carreira do treinador =============================
  // Pedido do utilizador (2026-09-05): "implementa os dois" — nível 1 (segurança no cargo: maus
  // resultados desportivos continuados levam a um despedimento) e nível 2 (reputação pessoal do
  // treinador, propostas de outros clubes, e candidaturas do próprio utilizador, sempre avaliadas
  // pela direção do clube candidatado). Distinto e independente do "game over" por falência (esse
  // mantém-se inalterado, só a insolvência financeira termina definitivamente a carreira). Um
  // despedimento por resultados NÃO tira de imediato o clube ao utilizador (evita deixar
  // state.userTeamId sem clube válido, o que partiria dezenas de ecrãs que assumem sempre um
  // myTeam() válido) — fica "em fim de vínculo" até aceitar uma proposta ou uma candidatura sua
  // ser aprovada, altura em que a troca de clube acontece de facto.
  function ensureManagerCareer(){
    state.gestor=state.gestor&&typeof state.gestor==="object"?state.gestor:{reputacao:50,empregado:true,dataInicioClube:null,epocaInicioClube:state.season,reputacaoMaxima:50,dataDespedimento:null,historico:[],candidaturas:[],ofertas:[]};
    const g=state.gestor;
    g.reputacao=Number.isFinite(g.reputacao)?g.reputacao:50;
    g.empregado=g.empregado!==false;
    g.dataInicioClube=g.dataInicioClube||null;g.dataDespedimento=g.dataDespedimento||null;
    // Nível 3 (2026-09-05): época em que o mandato atual começou, para atribuir títulos e
    // temporadas a este mandato especificamente (ver titlesWonAtClubForTenure/seasonsAtClubForTenure).
    // Saves anteriores ao Nível 3 não têm este campo — assume-se, de forma permissiva mas segura,
    // que o mandato em curso começou "agora" (só afeta a atribuição de títulos/temporadas passadas
    // do mandato em curso nesses saves antigos; não corrompe nada, é apenas menos retroativo).
    g.epocaInicioClube=Number.isFinite(g.epocaInicioClube)?g.epocaInicioClube:(state.season||0);
    g.reputacaoMaxima=Math.max(Number.isFinite(g.reputacaoMaxima)?g.reputacaoMaxima:0,g.reputacao);
    g.historico=Array.isArray(g.historico)?g.historico:[];
    g.historico.forEach(h=>{h.titulos=Array.isArray(h.titulos)?h.titulos:[];h.temporadas=Array.isArray(h.temporadas)?h.temporadas:[];});
    g.candidaturas=Array.isArray(g.candidaturas)?g.candidaturas:[];
    g.ofertas=Array.isArray(g.ofertas)?g.ofertas:[];
    // Staff — Treinadores (2026-09-22, pedido do utilizador: "O utilizador também tem perfil
    // com stats"): o gestor humano ganha o mesmo tipo de ficha que qualquer treinador da IA —
    // 12 stats 0-20 (geradas uma única vez, de forma determinística por semente da carreira, e
    // guardadas — nunca regeneradas), nacionalidade e data de nascimento. Backfill seguro para
    // saves anteriores a esta funcionalidade (idempotente, tal como o resto desta função).
    if(!g.stats || typeof g.stats!=="object"){
      const rngStats=makeSeededRng("gestor-humano-stats|"+(state.gameSeed||"semente"));
      const teamRef=state.teams[state.userTeamId]||{reputacao:60};
      g.stats=generateTreinadorStats(teamRef,rngStats);
    }
    if(!g.dataNascimento){
      const rngNasc=makeSeededRng("gestor-humano-nascimento|"+(state.gameSeed||"semente"));
      const idadeGestor=seededRnd(rngNasc,30,60);
      g.dataNascimento=makeBirthDate(rngNasc,idadeGestor,state.currentDate?new Date(state.currentDate):undefined);
    }
    g.paisOrigem=g.paisOrigem||"pt";
    g.nacionalidade=g.nacionalidade||nationalityForCountry(g.paisOrigem);
    // Mandato em curso — contador persistente de jogos/V/E/D (ver registerTreinadorMatchResult,
    // 08c-staff-treinadores.js). Corrige o CV do gestor: registerManagerClubExit passa a ler
    // daqui em vez de careerSnapshot (que só reflectia a época actual — qualquer mandato com
    // mais de uma época acumulava sempre errado antes desta correção).
    if(!g.mandatoAtual || typeof g.mandatoAtual!=="object"){
      g.mandatoAtual=defaultTreinadorMandato(g.epocaInicioClube,g.dataInicioClube);
    }
    // Selecção Nacional — Acumulação de Cargo (2026-10-03): três campos aditivos, mesma lógica de
    // backfill idempotente do resto desta função — nunca regenerados se já existirem. g.selecaoAtual
    // guarda o mandato EM CURSO na selecção (paralelo a g.mandatoAtual, do clube — nunca os dois se
    // misturam); g.selecaoHistorico guarda mandatos de selecção já terminados (despedimento ou
    // demissão); g.convitesSelecao guarda os convites recebidos (mesma forma de g.ofertas, acima).
    // Ver 08c-staff-treinadores.js para toda a lógica (convites, aceitação, despedimento).
    if(!g.selecaoAtual || typeof g.selecaoAtual!=="object") g.selecaoAtual=null;
    g.selecaoHistorico=Array.isArray(g.selecaoHistorico)?g.selecaoHistorico:[];
    g.convitesSelecao=Array.isArray(g.convitesSelecao)?g.convitesSelecao:[];
    return g;
  }
  // Nível 3 — CV completo / "hall da fama" (2026-09-05): os títulos (team.titulosClube) e as
  // avaliações anuais (team.avaliacaoDirecao) pertencem ao CLUBE, não ao treinador — um clube pode
  // ter sido gerido por outra pessoa (a IA) antes ou depois do utilizador. Por isso qualquer
  // atribuição ao mandato do utilizador tem de ser filtrada pelo intervalo de épocas desse mandato
  // (epocaInicioClube até à época atual), nunca pelo histórico completo do clube.
  function seasonNumberFromEpocaLabel(label){
    const m=/^(\d{4})\//.exec(String(label||""));
    return m?(parseInt(m[1],10)-2025):null;
  }
  function titlesWonAtClubForTenure(team,fromSeason){
    if(!team||!Number.isFinite(fromSeason))return[];
    return (team.titulosClube||[]).filter(t=>{const n=seasonNumberFromEpocaLabel(t.epoca);return n!=null&&n>=fromSeason&&n<=state.season;})
      .map(t=>({competicao:t.competicao,nome:t.nome,epoca:t.epoca}));
  }
  function seasonsAtClubForTenure(team,fromSeason){
    if(!team||!Number.isFinite(fromSeason))return[];
    return (team.avaliacaoDirecao||[]).filter(e=>{const n=seasonNumberFromEpocaLabel(e.epoca);return n!=null&&n>=fromSeason&&n<=state.season;})
      .map(e=>({epoca:e.epoca,posicaoFinal:e.finalPos||null,campeao:!!e.champion,descida:!!e.relegated}))
      .sort((a,b)=>(seasonNumberFromEpocaLabel(a.epoca)||0)-(seasonNumberFromEpocaLabel(b.epoca)||0));
  }
  // CV agregado: junta o historial de mandatos já terminados com o mandato em curso (calculado ao
  // vivo, nunca guardado — só se "fecha" e entra no historico quando o treinador sai do clube).
  function managerCareerTotals(){
    const g=ensureManagerCareer();
    const team=state.teams[state.userTeamId]||null;
    const fromSeason=Number.isFinite(g.epocaInicioClube)?g.epocaInicioClube:state.season;
    const mandatoAtual=team?{clubId:team.id,clubName:team.name,emCurso:true,dataInicio:g.dataInicioClube,titulos:titlesWonAtClubForTenure(team,fromSeason),temporadas:seasonsAtClubForTenure(team,fromSeason)}:null;
    const mandatos=mandatoAtual?g.historico.concat([mandatoAtual]):g.historico.slice();
    const totalTitulos=mandatos.reduce((s,m)=>s+(m.titulos||[]).length,0);
    const totalTemporadas=mandatos.reduce((s,m)=>s+(m.temporadas||[]).length,0);
    const totalClubes=new Set(mandatos.map(m=>m.clubId).filter(Boolean)).size;
    const vezesCampeao=mandatos.reduce((s,m)=>s+(m.temporadas||[]).filter(t=>t.campeao).length,0);
    const descidas=mandatos.reduce((s,m)=>s+(m.temporadas||[]).filter(t=>t.descida).length,0);
    let melhorPosicao=null;
    mandatos.forEach(m=>(m.temporadas||[]).forEach(t=>{if(Number.isFinite(t.posicaoFinal)&&(melhorPosicao==null||t.posicaoFinal<melhorPosicao))melhorPosicao=t.posicaoFinal;}));
    const todosTitulos=mandatos.flatMap(m=>(m.titulos||[]).map(t=>({...t,clubName:m.clubName,emCurso:!!m.emCurso})));
    return {clubesTreinados:totalClubes,epocasComoTreinador:totalTemporadas,titulosConquistados:totalTitulos,vezesCampeao,descidas,melhorPosicaoFinal:melhorPosicao,reputacaoAtual:g.reputacao,reputacaoMaxima:g.reputacaoMaxima,todosTitulos,mandatos};
  }
  // 3ª Divisão fica de fora: nunca foi pensada como clube diretamente gerível pelo utilizador
  // (ver clubDefinitionCompetitionId, 05-ui-navegacao.js — "nunca escolhível").
  function managerEligibleClubs(){
    // Correção (achado ao verificar a exclusão da nuvem europeia do mercado de transferências):
    // os clubes da nuvem não têm competição doméstica nenhuma (não entram em
    // state.competitions[...].teamIds, só existem para dar volume às competições europeias) —
    // sem esta exclusão, uma oferta de emprego de treinador podia teoricamente apontar para um
    // clube sem liga, calendário nem separador "Equipas" navegável.
    return Object.values(state.teams).filter(t=>!t.equipaPrincipalId&&t.id!==state.userTeamId&&!t.nuvemEuropeia&&!t.selecaoNacional);
  }
  function registerManagerClubExit(team,date,motivo){
    const g=ensureManagerCareer();
    const fromSeason=Number.isFinite(g.epocaInicioClube)?g.epocaInicioClube:state.season;
    // Correção (2026-09-22, descoberta ao construir o mandatoAtual dos treinadores): antes,
    // jogos/vitorias/empates/derrotas vinham de careerSnapshot(team,date), que só reflecte a
    // época ACTUAL (state.competitions[...].fixtures e team.stats são recriados todas as épocas
    // — ver resetStats/finalizeNewSeason) — qualquer mandato com mais de uma época ficava
    // sempre registado com só os números da última época. g.mandatoAtual é o contador
    // persistente, incrementado jogo a jogo desde que o mandato começou (ver
    // registerTreinadorMatchResult, 08c-staff-treinadores.js), por isso reflecte o mandato
    // completo correctamente.
    const m=g.mandatoAtual||{jogos:0,vitorias:0,empates:0,derrotas:0};
    g.historico.unshift({clubId:team.id,clubName:team.name,epocaSaida:seasonLabel(state.season),jogos:m.jogos,vitorias:m.vitorias,empates:m.empates,derrotas:m.derrotas,motivoSaida:motivo,data:isoDate(date),titulos:titlesWonAtClubForTenure(team,fromSeason),temporadas:seasonsAtClubForTenure(team,fromSeason)});
    if(g.historico.length>30)g.historico=g.historico.slice(0,30);
  }
  // O único ponto onde state.userTeamId muda a meio da carreira. state.fixtures/currentRound/
  // playoff são getters derivados de state.userCompetitionId (ver 02-estado.js) — mudar
  // userCompetitionId já os redireciona sozinho, sem qualquer manuseamento manual de calendários.
  function switchManagerToClub(newTeam,date,motivoEntrada){
    const g=ensureManagerCareer();
    const oldTeam=state.teams[state.userTeamId];
    if(oldTeam&&oldTeam.id!==newTeam.id){
      // 2026-10-16: se foi despedido, sackManager já registou a saída — registar outra vez duplicava a
      // passagem pelo clube no currículo (títulos e épocas contados duas vezes).
      if(g.empregado!==false) registerManagerClubExit(oldTeam,date,"saida-voluntaria");
      // Eventos Narrativos — Fase 3 ("A Dinastia", 09b-eventos-narrativos.js): este é o único
      // ponto onde o gestor humano deixa mesmo um clube (ver comentário abaixo) — se esse mandato
      // já tinha sido anunciado como uma dinastia, guarda aqui o eco duradouro do seu estilo,
      // antes de g.epocaInicioClube ser reposto para o novo clube já a seguir.
      if(oldTeam.dinastiaAnunciada && !oldTeam.legadoDinastia) narrativeDinastiaFimDeEra(oldTeam,g,date);
      // 2026-10-16: o clube que o utilizador deixa fica com vaga aberta (antes ficava sem treinador
      // indefinidamente — resolvePendingTreinadorVacancies só trata clubes com treinadorVacancia).
      if(!oldTeam.treinador && !oldTeam.treinadorVacancia) oldTeam.treinadorVacancia={ desde: isoDate(date), motivo: "saida-gestor", resolverEm: isoDate(addDays(date, 14)) };
    }
    state.userTeamId=newTeam.id;
    // 0.4.18: a competição vem da pertença real do clube (como na transição de época), e não da
    // divisão original do clube — assumir um clube que entretanto subiu/desceu (ex.: recém-promovido
    // ao Placard) deixava o jogo na competição errada e a época encravava ("nextGameDate" nulo).
    const compReal=Object.values(state.competitions).find(c=>c&&Array.isArray(c.teamIds)&&c.teamIds.includes(newTeam.id)&&!/apuramento|taca|europa|supertaca/i.test(c.id));
    state.userCompetitionId=compReal?compReal.id:inferCompetitionIdForTeamId(newTeam.id,state.teams);
    state.viewedCompetitionId=state.userCompetitionId;
    state.plantelViewTeamId=null;state.plantelViewMode=null;state.convocadosSelecionados=null;state.uiNegotiationOpenId=null;
    g.empregado=true;g.dataInicioClube=isoDate(date);g.epocaInicioClube=state.season;g.dataDespedimento=null;
    // Novo mandato, novo contador de jogos/V/E/D (ver registerTreinadorMatchResult) — sem isto,
    // o CV do próximo clube arrancaria a somar aos números do clube anterior.
    g.mandatoAtual=defaultTreinadorMandato(state.season,date);
    // Mercado de treinadores (2026-09-23): se o clube que o utilizador está a assumir tinha uma
    // vaga em aberto (candidatura aprovada por managerVacantEligibleClubs, ou proposta aceite
    // depois de um despedimento na IA), essa vaga fica resolvida — quem manda ali passa a ser o
    // utilizador (ver activeCoachingStats, 08c-staff-treinadores.js, que já ignora team.treinador
    // para o clube do próprio utilizador). Reinicia também os contadores de segurança no cargo,
    // para o novo ciclo não herdar uma crise de confiança que já não lhe diz respeito.
    newTeam.treinadorVacancia=null;
    newTeam.treinadorConfiancaBaixaMeses=0;
    newTeam.treinadorAvisoEmitido=false;
    g.candidaturas.forEach(c=>{if(c.estado==="pendente"){c.estado="cancelada";c.motivoRecusa="Aceitaste outro cargo.";}});
    g.ofertas.forEach(o=>{if(o.estado==="pendente")o.estado="cancelada";});
    pushNews(date,`Assumiste o comando técnico do ${teamLinkHtml(newTeam.id)} (${motivoEntrada==="oferta"?"proposta aceite":motivoEntrada==="candidatura"?"candidatura aceite":"novo desafio"}).`,"gestor","Novo clube",{autoAdvanceStop:true, teamId:newTeam.id});
    setView("clube");renderAll();
  }
  function sackManager(team,date){
    const g=ensureManagerCareer();
    registerManagerClubExit(team,date,"despedido");
    g.reputacao=clamp(g.reputacao-15,15,99);
    g.empregado=false;g.dataDespedimento=isoDate(date);
    pushNews(date,`A direção do ${teamLinkHtml(team.id)} anunciou o fim do vínculo com o treinador — resultados desportivos abaixo do exigido.`,"gestor","Despedido pela direção",{autoAdvanceStop:true, teamId:team.id});
  }
  function updateManagerReputationAfterSeason(team){
    const g=ensureManagerCareer();
    const last=(team.avaliacaoDirecao||[])[0];if(!last)return;
    const ratio=presTaxaAvaliacao(last);
    let delta=(ratio-.5)*20;
    if(last.champion)delta+=8;if(last.relegated)delta-=6;
    // 0.4.18: subir de divisão é mérito do treinador, mesmo que a direção tenha fixado objectivos
    // exigentes (antes, uma subida com 0/3 objectivos custava -10 de reputação). Sem isto, a carreira
    // "3.ª divisão → grande do Placard" era praticamente impossível: subir dava ~+3 e ficava longe dos ~80
    // necessários para as propostas dos três grandes.
    const pe=state.promotionEvent;
    const promoted=!!(pe&&pe.epoca===last.epoca&&["promoted","promotedFromThird","promotedEs","promotedIt"].some(k=>Array.isArray(pe[k])&&pe[k].includes(team.id)));
    if(promoted&&!last.relegated)delta=Math.max(delta,0)+5;
    g.reputacao=clamp(Math.round(g.reputacao+delta),15,99);
    // 0.4.18: a experiência do treinador cresce com as épocas completas ao comando (+1) e com os
    // êxitos (+1 por título ou subida), até ao teto de 20. Estava fixa desde a criação da carreira
    // (função só do clube inicial), pelo que quem começava num clube pequeno podia nunca atingir o
    // mínimo para convites de selecção (experiência ≥ 10).
    if(g.stats&&Number.isFinite(g.stats.reputacaoExperiencia)){
      g.stats.reputacaoExperiencia=Math.min(20,g.stats.reputacaoExperiencia+1+((last.champion||promoted)&&!last.relegated?1:0));
    }
    if(!Array.isArray(g.serieReputacao))g.serieReputacao=[];
    const ixRep=g.serieReputacao.findIndex(x=>x.epoca===last.epoca);
    if(ixRep>=0)g.serieReputacao[ixRep].rep=g.reputacao;else g.serieReputacao.push({epoca:last.epoca,rep:g.reputacao});
    g.serieReputacao=g.serieReputacao.slice(-40);
  }
  // Segurança no cargo: duas épocas seguidas com menos de 40% dos objetivos da direção cumpridos,
  // ou duas descidas de divisão seguidas, custam o lugar.
  function checkManagerSacking(team,date){
    const evals=team.avaliacaoDirecao||[];
    if(evals.length<2)return false;
    const [a,b]=evals;
    const limiteMau=typeof presLimiteDespedimento==="function"?presLimiteDespedimento(team):.4;   // o presidente decide a paciência
    const bad=e=>presTaxaAvaliacao(e)<limiteMau;
    if((bad(a)&&bad(b))||(a.relegated&&b.relegated)){sackManager(team,date);return true;}
    return false;
  }
  function processManagerCareerSeasonEnd(date){
    ensureManagerCareer();
    const team=state.teams[state.userTeamId];if(!team)return;
    const gEnd=ensureManagerCareer();
    // 2026-10-16: já despedido (à espera de novo clube) — não volta a ser avaliado/despedido pelo mesmo clube.
    if(gEnd.empregado!==false){ updateManagerReputationAfterSeason(team); checkManagerSacking(team,date); }
    maybeGenerateManagerJobOffers(date);
    // Selecção Nacional — Acumulação de Cargo (2026-10-03): avaliado uma vez por época, a par das
    // propostas de clube — ver maybeGenerateSelecaoInvites (08c-staff-treinadores.js).
    maybeGenerateSelecaoInvites(date);
  }
  // Propostas de outros clubes (sondagem espontânea): mais frequentes e menos exigentes em termos
  // de reputação enquanto o treinador está desempregado (procura ativa de substituto), raras e só
  // para clubes ao alcance da reputação atual enquanto empregado (assédio pontual).
  function maybeGenerateManagerJobOffers(date){
    const g=ensureManagerCareer();
    // 0.4.18: um treinador que acaba de ser campeão é cobiçado — o dobro das sondagens (10 % por
    // clube ao alcance, em vez de 5 %). Sem isto, mesmo com reputação de topo, as propostas dos
    // três grandes dependiam de uma sorte de 5 % por clube e por época.
    const ultimaAv=((state.teams[state.userTeamId]||{}).avaliacaoDirecao||[])[0];
    const chanceBase=g.empregado?(ultimaAv&&ultimaAv.champion?.10:.05):.35;
    const rng=makeSeededRng(`gestor-ofertas:${isoDate(date)}`);
    managerEligibleClubs().forEach(team=>{
      if(seededRndFloat(rng,0,1)>chanceBase)return;
      if(team.reputacaoClube>g.reputacao+15)return;
      if(g.ofertas.some(o=>o.clubId===team.id&&o.estado==="pendente"))return;
      const oferta={id:`${team.id}:${isoDate(date)}`,clubId:team.id,clubName:team.name,dataOferta:isoDate(date),expiraEm:isoDate(addDays(date,21)),estado:"pendente"};
      g.ofertas.unshift(oferta);if(g.ofertas.length>20)g.ofertas=g.ofertas.slice(0,20);
      pushNews(date,`O ${teamLinkHtml(team.id)} contactou-te com uma proposta para assumires o comando técnico.`,"gestor","Proposta de outro clube",{autoAdvanceStop:true, teamId:team.id});
    });
  }
  // Candidatura do utilizador — pedido explícito: "tem de ser bem analisada pela direcção desse
  // clube". Resolução em resolvePendingManagerCareerEvents, considerando a saúde financeira do
  // clube-alvo e a distância entre a reputação desse clube e a reputação pessoal do treinador.
  function applyForManagerJob(teamId,date){
    const g=ensureManagerCareer();
    const team=state.teams[teamId];
    if(!team)return{outcome:"recusa",reason:"Clube inválido."};
    if(team.equipaPrincipalId)return{outcome:"recusa",reason:"Não é possível candidatar-se a uma equipa B."};
    if(team.id===state.userTeamId)return{outcome:"recusa",reason:"Já treinas este clube."};
    // Mercado de treinadores (2026-09-23, pedido explícito do utilizador): "Não deve ser possível
    // ao utilizador concorrer a clubes com treinador" — só clubes com uma vaga em aberto (ver
    // fireTreinador/hireTreinadorForVacancy, 08c-staff-treinadores.js) podem ser alvo de
    // candidatura. Verificação feita aqui também (e não só ao construir a lista da UI), para
    // cobrir qualquer chamada directa (testes, ficha do clube).
    if(team.treinador)return{outcome:"recusa",reason:"Este clube já tem treinador — só é possível candidatar-se a clubes sem treinador."};
    if(g.candidaturas.some(c=>c.clubId===team.id&&c.estado==="pendente"))return{outcome:"recusa",reason:"Já tens uma candidatura pendente a este clube."};
    const rng=makeSeededRng(`gestor-candidatura:${team.id}:${isoDate(date)}`);
    const dias=Math.round(seededRnd(rng,10,21));
    const candidatura={id:`${team.id}:${isoDate(date)}`,clubId:team.id,clubName:team.name,dataPedido:isoDate(date),dataResposta:isoDate(addDays(date,dias)),estado:"pendente"};
    g.candidaturas.unshift(candidatura);if(g.candidaturas.length>20)g.candidaturas=g.candidaturas.slice(0,20);
    // Pedido do utilizador (2026-09-16): "e quando concorro a um lugar noutro clube?" — a
    // candidatura enviada por ti precisa da mesma notícia dedicada que as outras propostas que
    // partem de ti (fee, contrato, empréstimo, investimento), com o teu endereço pessoal como
    // remetente, já que és tu quem a envia.
    pushNews(date,`Candidatura enviada ao ${teamLinkHtml(team.id)} para o cargo de treinador principal. Resposta prevista para ${fmtDateShort(addDays(date,dias))}.`,"gestor","Candidatura enviada",{sender:managerEmailAddress(state.userTeamId)});
    return{outcome:"pendente",candidatura};
  }
  function respondToManagerJobOffer(offerId,accept,date){
    const g=ensureManagerCareer();
    const o=g.ofertas.find(x=>x.id===offerId&&x.estado==="pendente");
    if(!o)return{outcome:"recusa",reason:"Proposta não encontrada ou já respondida."};
    if(new Date(date)>new Date(o.expiraEm)){o.estado="expirada";return{outcome:"recusa",reason:"Esta proposta já expirou."};}
    if(!accept){o.estado="recusada-pelo-utilizador";return{outcome:"recusada"};}
    const team=state.teams[o.clubId];
    if(!team){o.estado="expirada";return{outcome:"recusa",reason:"Clube já não está disponível."};}
    o.estado="aceite";
    switchManagerToClub(team,date,"oferta");
    return{outcome:"aceite"};
  }
  function resolvePendingManagerCareerEvents(date){
    const g=ensureManagerCareer();
    g.candidaturas.forEach(c=>{
      if(c.estado!=="pendente")return;
      if(new Date(date)<new Date(c.dataResposta))return;
      const team=state.teams[c.clubId];
      if(!team){c.estado="recusado";c.motivoRecusa="O clube deixou de estar disponível.";return;}
      const tier=directionHealthTier(team),gap=team.reputacaoClube-g.reputacao;
      let aprovado=true,motivo=null;
      if(team.treinador&&!team.treinadorVacancia){aprovado=false;motivo="A vaga já foi preenchida por outro treinador.";} // 2026-10-16: evitava dois treinadores no mesmo clube
      else if(tier==="risco"){aprovado=false;motivo="O clube está a atravessar uma crise financeira e não está a contratar.";}
      else if(gap>20){aprovado=false;motivo="A direção considera que ainda não tens currículo para um clube desta dimensão.";}
      else{
        const chance=clamp(.75-Math.max(0,gap)*.02,.1,.9);
        const rng=makeSeededRng(`gestor-candidatura-resposta:${c.id}`);
        if(seededRndFloat(rng,0,1)>chance){aprovado=false;motivo="A direção optou por outro candidato.";}
      }
      if(aprovado){
        c.estado="aceite";
        switchManagerToClub(team,date,"candidatura");
        pushNews(date,`A direção do ${teamLinkHtml(team.id)} aceitou a tua candidatura — assumes o comando técnico.`,"gestor","Candidatura aceite",{autoAdvanceStop:true, teamId:team.id});
      }else{
        c.estado="recusado";c.motivoRecusa=motivo;
        pushNews(date,`A direção do ${teamLinkHtml(team.id)} recusou a tua candidatura: ${motivo}`,"gestor","Candidatura recusada",{autoAdvanceStop:true, teamId:team.id});
      }
    });
    g.ofertas.forEach(o=>{
      if(o.estado!=="pendente")return;
      if(new Date(date)>new Date(o.expiraEm))o.estado="expirada";
    });
  }
  function renderDirectionPanel(){
    const box=document.getElementById("directionContent");
    if(!box) return;
    const team=myTeam(); if(!team){ box.innerHTML='<p class="helptext">Escolhe primeiro um clube.</p>'; return; }
    initClubFinance(team);
    const live=evaluateDirectionGoals(team);
    const tier=directionHealthTier(team);
    const wages=monthlyWageBill(team);
    const monthsLeft=Math.max(1,12-((new Date(state.currentDate).getMonth()+4)%12));
    const receitaAnualPrevista=(team.financeiro.receitaMensalPatrocinio+team.financeiro.receitaMensalQuotas+team.financeiro.receitaMensalApoioMunicipal+team.financeiro.receitaMensalComercial)*12;
    const despesaAnualPrevista=(wages+monthlyTrainingCost(team))*12;
    const resultadoPrevisto=receitaAnualPrevista-despesaAnualPrevista;
    const tesourariaProjetada=team.financeiro.saldo+resultadoPrevisto*(monthsLeft/12);
    document.getElementById("directionSeasonLabel").textContent=`Época ${seasonLabel(state.season)}`;
    const invStore=ensureTeamDirecaoInvestimentos(team);
    const nextTreino=nextTrainingLevel(team),custoTreino=nextTreino?trainingUpgradeCost(team):null;
    const passoPavilhao=pavilionUpgradeStep(team),custoPavilhao=pavilionUpgradeCost(team);
    const scoutingStore=ensureTeamScouting(team),scoutingCfg=scoutingLevelConfig(team);
    const nextScouting=nextScoutingLevel(team),custoScouting=nextScouting!=null?scoutingLevelUpgradeCost(team):null;
    const nextMedico=nextMedicalLevel(team),custoMedico=nextMedico!=null?medicalLevelUpgradeCost(team):null,medCfg=medicalLevelConfig(team),medNivel=ensureTeamMedico(team).nivel;
    const pedidosOrdenados=invStore.pedidos.slice().sort((a,b)=>new Date(b.dataPedido)-new Date(a.dataPedido));
    const estadoLabel={pendente:"Pendente",aprovado:"Aprovado",recusado:"Recusado"};
    const confianca = team.confiancaDirecao!=null ? team.confiancaDirecao : 60;
    const confiancaTier = directionConfidenceTier(confianca);
    box.innerHTML = `
      <div class="eyebrow" style="margin-bottom:8px;">Saúde financeira</div>
      <div class="market-status ${tier==='saudavel'?'ok':'no'}" style="margin-bottom:14px;font-weight:700;">${tier==='saudavel'?'Saudável':tier==='atencao'?'Atenção':'Risco'} · Massa salarial ${Math.round(live.wageRatio*100)}% do limite · Dívida ${fmtMoney(team.financeiro.divida||0)}</div>
      <div class="eyebrow" style="margin-bottom:8px;">Confiança da direção (indicador contínuo — o despedimento continua só a decidir-se no fim da época)</div>
      <div class="market-status ${confiancaTier.cls}" style="margin-bottom:14px;font-weight:700;display:flex;align-items:center;gap:10px;">
        <span>${confiancaTier.label} · ${Math.round(confianca)}/100</span>
        <span style="flex:1;max-width:220px;height:10px;background:rgba(255,255,255,.25);border-radius:5px;overflow:hidden;"><span style="display:block;height:100%;width:${Math.round(confianca)}%;background:currentColor;"></span></span>
      </div>
      ${typeof presPainelHtml==="function"?presPainelHtml(team):""}
      <div class="eyebrow" style="margin-bottom:8px;">Orçamento anual (projeção)</div>
      <div class="pm-postmatch-grid" style="margin-bottom:16px;">
        <div><b>Receitas previstas</b><br>${fmtMoney(receitaAnualPrevista)}</div>
        <div><b>Despesas previstas</b><br>${fmtMoney(despesaAnualPrevista)}</div>
        <div><b>Resultado previsto</b><br><span class="${resultadoPrevisto<0?'money-neg':''}">${fmtMoney(resultadoPrevisto)}</span></div>
        <div><b>Projeção de tesouraria</b><br>${fmtMoney(tesourariaProjetada)}</div>
      </div>
      <div class="eyebrow" style="margin-bottom:8px;">Avaliação anual da direção — últimas épocas</div>
      <table class="stat-list"><thead><tr><th>Época</th><th class="num">Objetivos cumpridos</th><th>Posição final</th><th>Descida</th></tr></thead><tbody>
        ${(team.avaliacaoDirecao||[]).map(a=>`<tr><td>${escapeHtml(a.epoca)}</td><td class="num">${a.passed}/${a.total}</td><td>${a.finalPos||'—'}</td><td>${a.relegated?'Sim':'Não'}</td></tr>`).join("") || '<tr><td colspan="4" class="helptext">Ainda sem avaliações — a primeira surge no fim desta época.</td></tr>'}
      </tbody></table>
      ${pavilhaoPanelHtml(team)}${patrocinioPanelHtml(team)}${disciplinaPanelHtml(team)}${arbitroPanelHtml(team)}${satPanelHtml(team)}
      <div class="eyebrow" style="margin:16px 0 8px;">Pedidos de investimento em infraestrutura</div>
      <div class="pm-postmatch-grid" style="margin-bottom:12px;">
        <div><b>Condições de treino</b><br>${escapeHtml(team.condicoesTreino)}${nextTreino?` → ${escapeHtml(nextTreino)} (${fmtMoney(custoTreino)})`:' (nível máximo)'}</div>
        <div><b>Capacidade do pavilhão</b><br>${team.financeiro.capacidadePavilhao} lugares → +${passoPavilhao} (${fmtMoney(custoPavilhao)})</div>
        <div><b>Departamento de scouting</b><br>Nível ${scoutingStore.departamento.nivel} (máx. ${scoutingCfg.capacidade} pedido${scoutingCfg.capacidade>1?'s':''} em curso${scoutingCfg.completoDisponivel?'':', só relatório rápido'})${nextScouting!=null?` → nível ${nextScouting} (${fmtMoney(custoScouting)})`:' (nível máximo)'}</div>
        <div><b>Encargo mensal de scouting</b><br>${fmtMoney(monthlyScoutingCost(team))}${scoutingStore.valesCompletos>0?` · ${scoutingStore.valesCompletos} relatório${scoutingStore.valesCompletos>1?'s':''} completo${scoutingStore.valesCompletos>1?'s':''} grátis por usar`:''}</div>
        <div><b>Departamento médico</b><br>Nível ${medNivel} · ${medCfg.label}${nextMedico!=null?` → nível ${nextMedico} (${fmtMoney(custoMedico)})`:' (nível máximo)'}</div>
        <div><b>Encargo mensal do departamento médico</b><br>${fmtMoney(monthlyMedicalCost(team))}</div>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;">
        <button class="btn btn-ghost" id="direcaoPedirTreinoBtn"${nextTreino?'':' disabled'}>Pedir subida das condições de treino</button>
        <button class="btn btn-ghost" id="direcaoPedirPavilhaoBtn">Pedir ampliação do pavilhão</button>
        <button class="btn btn-ghost" id="direcaoPedirScoutingBtn"${nextScouting!=null?'':' disabled'}>Pedir reforço do departamento de scouting</button>
        <button class="btn btn-ghost" id="direcaoPedirMedicoBtn"${nextMedico!=null?'':' disabled'}>Pedir reforço do departamento médico</button>
      </div>
      <table class="stat-list"><thead><tr><th>Tipo</th><th>Pedido em</th><th>Resposta</th><th>Estado</th><th>Detalhe</th></tr></thead><tbody>
        ${pedidosOrdenados.map(p=>`<tr><td>${DIRECAO_INVESTIMENTO_TIPO_LABEL[p.tipo]||p.tipo}${p.obraLabel?` — ${escapeHtml(p.obraLabel)}`:""}</td><td>${p.dataPedido}</td><td>${p.dataResposta}</td><td>${estadoLabel[p.estado]||p.estado}</td><td>${p.estado==="recusado"?escapeHtml(p.motivoRecusa||""):p.tipo==="treino"?escapeHtml(p.alvoNivel||""):p.tipo==="pavilhao"?`+${p.incremento||0} lugares`:`Nível ${p.alvoNivel}`}</td></tr>`).join("") || '<tr><td colspan="5" class="helptext">Ainda sem pedidos de investimento.</td></tr>'}
      </tbody></table>`;
    if(typeof presLigarEventos==="function") presLigarEventos(box, team, ()=>renderDirectionPanel());
    const btnTreino=document.getElementById("direcaoPedirTreinoBtn");
    if(btnTreino)btnTreino.addEventListener("click",()=>{const r=requestDirectionInvestment(team,"treino",state.currentDate);if(r.outcome==="recusa")alert(r.reason);renderDirectionPanel();});
    const btnPavilhao=document.getElementById("direcaoPedirPavilhaoBtn");
    if(btnPavilhao)btnPavilhao.addEventListener("click",()=>{const r=requestDirectionInvestment(team,"pavilhao",state.currentDate);if(r.outcome==="recusa")alert(r.reason);renderDirectionPanel();});
    const btnScouting=document.getElementById("direcaoPedirScoutingBtn");
    if(btnScouting)btnScouting.addEventListener("click",()=>{const r=requestDirectionInvestment(team,"scouting",state.currentDate);if(r.outcome==="recusa")alert(r.reason);renderDirectionPanel();});
    const btnMedico=document.getElementById("direcaoPedirMedicoBtn");
    if(btnMedico)btnMedico.addEventListener("click",()=>{const r=requestDirectionInvestment(team,"medico",state.currentDate);if(r.outcome==="recusa")alert(r.reason);renderDirectionPanel();});
  }

  // ============================= Carreira do treinador (separador próprio) =============================
  // Pedido do utilizador (2026-09-05): os dados pessoais do treinador (reputação, situação,
  // currículo, hall da fama, propostas/candidaturas, historial de clubes) estavam dentro do
  // painel da Direção, misturados com a saúde financeira e os objetivos do CLUBE — mas são dados
  // do TREINADOR, não do clube. Passam a ter separador próprio, substituindo o antigo separador
  // de Diagnóstico (ver setView e o botão/vista em index.html; os testes de regressão já invocam
  // runDiagnostics() diretamente via window.__HM2027_TEST__, sem depender daquele painel).
  function renderManagerCareerPanel(){
    const box=document.getElementById("managerCareerContent");
    if(!box) return;
    const gestor=ensureManagerCareer();
    const ofertasPendentes=gestor.ofertas.filter(o=>o.estado==="pendente");
    // Mercado de treinadores (2026-09-23): a candidatura por iniciativa do utilizador só pode
    // visar clubes sem treinador (managerVacantEligibleClubs) — managerEligibleClubs() continua a
    // servir só as propostas RECEBIDAS (ofertasPendentes, acima), que não dependem de vaga.
    const eligiveis=managerVacantEligibleClubs().sort((a,b)=>a.name.localeCompare(b.name));
    const estadoCandidaturaLabel={pendente:"Pendente",aceite:"Aceite",recusado:"Recusado",cancelada:"Cancelada"};
    // Selecção Nacional — Acumulação de Cargo (2026-10-03): convites pendentes para o novo bloco
    // "Carreira na selecção nacional", mesmo padrão de ofertasPendentes acima.
    const convitesSelecaoPendentes=gestor.convitesSelecao.filter(c=>c.estado==="pendente");
    const cv=managerCareerTotals();
    grafRenderCarreira();
    const todosTitulosOrdenados=cv.todosTitulos.slice().sort((a,b)=>(seasonNumberFromEpocaLabel(b.epoca)||0)-(seasonNumberFromEpocaLabel(a.epoca)||0));
    box.innerHTML = `
      <div class="eyebrow" style="margin-bottom:8px;">Carreira do treinador</div>
      <button class="btn btn-ghost" id="gestorVerFichaBtn" style="margin-bottom:12px;">Ver a minha ficha (stats, nacionalidade)</button>
      <div class="pm-postmatch-grid" style="margin-bottom:12px;">
        <div><b>Reputação pessoal</b><br>${gestor.reputacao}/99</div>
        <div><b>Situação</b><br>${gestor.empregado?"Empregado":"Fim de vínculo — à procura de novo clube"}</div>
      </div>
      <div class="eyebrow" style="margin-bottom:8px;">Currículo — carreira completa</div>
      <div class="pm-postmatch-grid" style="margin-bottom:16px;">
        <div><b>Clubes treinados</b><br>${cv.clubesTreinados}</div>
        <div><b>Épocas como treinador</b><br>${cv.epocasComoTreinador}</div>
        <div><b>Títulos conquistados</b><br>${cv.titulosConquistados}</div>
        <div><b>Vezes campeão</b><br>${cv.vezesCampeao}</div>
        <div><b>Descidas de divisão</b><br>${cv.descidas}</div>
        <div><b>Melhor posição final</b><br>${cv.melhorPosicaoFinal||'—'}</div>
        <div><b>Reputação máxima atingida</b><br>${cv.reputacaoMaxima}/99</div>
      </div>
      <div class="eyebrow" style="margin-bottom:8px;">Hall da fama — títulos conquistados</div>
      <table class="stat-list"><thead><tr><th>Título</th><th>Clube</th><th>Época</th></tr></thead><tbody>
        ${todosTitulosOrdenados.map(t=>`<tr><td>${escapeHtml(t.nome)}</td><td>${escapeHtml(t.clubName)}${t.emCurso?' (atual)':''}</td><td>${escapeHtml(t.epoca)}</td></tr>`).join("") || '<tr><td colspan="3" class="helptext">Ainda sem títulos conquistados nesta carreira.</td></tr>'}
      </tbody></table>
      ${ofertasPendentes.length?`<div class="eyebrow" style="margin-bottom:8px;">Propostas recebidas</div>
      <table class="stat-list"><thead><tr><th>Clube</th><th>Recebida em</th><th>Expira em</th><th></th></tr></thead><tbody>
        ${ofertasPendentes.map(o=>{const t=state.teams[o.clubId];return `<tr><td>${escapeHtml(o.clubName)}${t?foreignClubLabelSuffix(t.divisaoAtual):""}</td><td>${o.dataOferta}</td><td>${o.expiraEm}</td><td><button class="btn btn-ghost gestorAceitarOfertaBtn" data-offer-id="${o.id}">Aceitar</button> <button class="btn btn-ghost gestorRecusarOfertaBtn" data-offer-id="${o.id}">Recusar</button></td></tr>`;}).join("")}
      </tbody></table>`:''}
      <div class="eyebrow" style="margin:12px 0 8px;">Candidatar-me a um clube sem treinador</div>
      <p class="helptext" style="margin-bottom:8px;">Só é possível candidatar-te a clubes que estejam atualmente sem treinador (vaga em aberto).</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;">
        <select id="gestorCandidaturaSelect">
          <option value="">${eligiveis.length?"Escolhe um clube...":"Nenhum clube com vaga em aberto de momento"}</option>
          ${eligiveis.map(t=>`<option value="${t.id}">${escapeHtml(t.name)}${foreignClubLabelSuffix(t.divisaoAtual)}</option>`).join("")}
        </select>
        <button class="btn btn-ghost" id="gestorCandidatarBtn">Candidatar-me</button>
      </div>
      <table class="stat-list"><thead><tr><th>Clube</th><th>Pedido em</th><th>Resposta</th><th>Estado</th><th>Motivo</th></tr></thead><tbody>
        ${gestor.candidaturas.slice(0,10).map(c=>`<tr><td>${escapeHtml(c.clubName)}</td><td>${c.dataPedido}</td><td>${c.dataResposta}</td><td>${estadoCandidaturaLabel[c.estado]||c.estado}</td><td>${escapeHtml(c.motivoRecusa||"")}</td></tr>`).join("") || '<tr><td colspan="5" class="helptext">Ainda sem candidaturas.</td></tr>'}
      </tbody></table>
      <div class="eyebrow" style="margin:12px 0 8px;">Historial de clubes</div>
      <table class="stat-list"><thead><tr><th>Clube</th><th>Saída</th><th class="num">Jogos</th><th class="num">V-E-D</th><th>Títulos</th><th>Motivo</th></tr></thead><tbody>
        ${gestor.historico.slice(0,10).map(h=>`<tr><td>${escapeHtml(h.clubName)}</td><td>${escapeHtml(h.epocaSaida)}</td><td class="num">${h.jogos}</td><td class="num">${h.vitorias}-${h.empates}-${h.derrotas}</td><td>${(h.titulos||[]).length?escapeHtml((h.titulos||[]).map(t=>t.nome).join("; ")):'—'}</td><td>${h.motivoSaida==="despedido"?"Despedido":"Saída voluntária"}</td></tr>`).join("") || '<tr><td colspan="6" class="helptext">Ainda sem clubes anteriores.</td></tr>'}
      </tbody></table>
      <div class="eyebrow" style="margin:16px 0 8px;">Carreira na selecção nacional</div>
      ${gestor.selecaoAtual ? `
      <div class="pm-postmatch-grid" style="margin-bottom:12px;">
        <div><b>Cargo actual</b><br>Seleccionador de ${escapeHtml(selecaoNomeDaNacao(gestor.selecaoAtual.code))}</div>
        <div><b>Confiança da federação</b><br>${Math.round(gestor.selecaoAtual.confiancaFederacao)}/100</div>
      </div>
      <button class="btn btn-ghost" id="gestorDemitirSelecaoBtn" style="margin-bottom:12px;">Demitir-me da selecção</button>
      ` : `<p class="helptext" style="margin-bottom:8px;">Não estás actualmente à frente de nenhuma selecção nacional — um convite pode chegar por e-mail se a tua reputação for suficiente.</p>`}
      ${convitesSelecaoPendentes.length?`<div class="eyebrow" style="margin-bottom:8px;">Convites recebidos</div>
      <table class="stat-list"><thead><tr><th>Selecção</th><th>Recebido em</th><th>Expira em</th><th></th></tr></thead><tbody>
        ${convitesSelecaoPendentes.map(c=>`<tr><td>${escapeHtml(c.nome)}</td><td>${c.dataOferta}</td><td>${c.expiraEm}</td><td><button class="btn btn-ghost gestorAceitarConviteSelecaoBtn" data-invite-id="${c.id}">Aceitar</button> <button class="btn btn-ghost gestorRecusarConviteSelecaoBtn" data-invite-id="${c.id}">Recusar</button></td></tr>`).join("")}
      </tbody></table>`:''}
      <div class="eyebrow" style="margin:12px 0 8px;">Historial de selecções</div>
      <table class="stat-list"><thead><tr><th>Selecção</th><th>Desde</th><th>Até</th><th>Motivo</th></tr></thead><tbody>
        ${(gestor.selecaoHistorico||[]).slice(0,10).map(h=>`<tr><td>${escapeHtml(h.nome)}</td><td>${h.desde}</td><td>${h.ate}</td><td>${h.motivoSaida==="despedido"?"Despedido pela federação":"Demissão voluntária"}</td></tr>`).join("") || '<tr><td colspan="4" class="helptext">Ainda sem passagens por selecções nacionais.</td></tr>'}
      </tbody></table>`;
    const gestorVerFichaBtn=document.getElementById("gestorVerFichaBtn");
    if(gestorVerFichaBtn)gestorVerFichaBtn.addEventListener("click",()=>openTreinadorModal("gestor",state.userTeamId));
    document.querySelectorAll(".gestorAceitarOfertaBtn").forEach(btn=>btn.addEventListener("click",()=>{
      const r=respondToManagerJobOffer(btn.dataset.offerId,true,state.currentDate);
      if(r.outcome==="recusa"){alert(r.reason);renderManagerCareerPanel();}
    }));
    document.querySelectorAll(".gestorRecusarOfertaBtn").forEach(btn=>btn.addEventListener("click",()=>{
      respondToManagerJobOffer(btn.dataset.offerId,false,state.currentDate);renderManagerCareerPanel();
    }));
    const candidatarBtn=document.getElementById("gestorCandidatarBtn");
    if(candidatarBtn)candidatarBtn.addEventListener("click",()=>{
      const sel=document.getElementById("gestorCandidaturaSelect"),teamId=sel&&sel.value;
      if(!teamId){alert("Escolhe um clube.");return;}
      const r=applyForManagerJob(teamId,state.currentDate);
      if(r.outcome==="recusa")alert(r.reason);
      renderManagerCareerPanel();
    });
    // Selecção Nacional — Acumulação de Cargo (2026-10-03): listeners do novo bloco, mesmo padrão
    // dos de clube acima.
    const demitirSelecaoBtn=document.getElementById("gestorDemitirSelecaoBtn");
    if(demitirSelecaoBtn)demitirSelecaoBtn.addEventListener("click",()=>{
      if(confirm("Tens a certeza que queres demitir-te da selecção nacional? O teu cargo no clube não é afectado.")){
        resignFromSelecao(state.currentDate);renderManagerCareerPanel();
      }
    });
    document.querySelectorAll(".gestorAceitarConviteSelecaoBtn").forEach(btn=>btn.addEventListener("click",()=>{
      const r=respondToSelecaoInvite(btn.dataset.inviteId,true,state.currentDate);
      if(r.outcome==="recusa")alert(r.reason);
      renderManagerCareerPanel();
    }));
    document.querySelectorAll(".gestorRecusarConviteSelecaoBtn").forEach(btn=>btn.addEventListener("click",()=>{
      respondToSelecaoInvite(btn.dataset.inviteId,false,state.currentDate);renderManagerCareerPanel();
    }));
  }

  // ============================= Painel de scouting (atributos ocultos) =============================
  // Pedido do utilizador (2026-09-05): a ficha de um jogador que não é nosso mostrava sempre os
  // atributos técnicos/físicos exatos, sem qualquer incerteza — informação perfeita em qualquer
  // mercado de transferências. Generaliza-se aqui o mecanismo que já existia só para o potencial
  // (stablePotentialNoise, em 05-ui-navegacao.js) a todos os atributos: uma estimativa com ruído
  // determinístico, cuja confiança sobe com jogos vistos, profundidade de histórico, e agora
  // também com a distância à nossa divisão/zona — e que pode ser resolvida de forma fiável ao
  // pagar um relatório de scouting a um olheiro. As atribuições monetárias da negociação (valor de
  // mercado, salário pedido, etc.) continuam a usar sempre os atributos reais — o nevoeiro é só
  // uma camada de apresentação ao utilizador humano, nunca uma restrição à lógica do jogo.

  // Atributos físicos são muito mais fáceis de avaliar à primeira vista (correr, disputar bolas)
  // do que os técnicos/mentais (criatividade, posicionamento) — por isso partem de uma confiança-
  // base mais alta, mesmo sem nenhum relatório pago.
  const SCOUTING_PHYSICAL_ATTRS = new Set(["velocidade","aceleracao","forca","resistencia","agilidade","reflexos","agressividade"]);
  function attrIsPhysical(key){ return SCOUTING_PHYSICAL_ATTRS.has(key); }

  // Distância ao alvo: divisão diferente pesa mais do que zona diferente dentro da mesma divisão
  // (2ª/3ª Divisão têm Zona Norte/Sul) — usa o mesmo DIVISION_TIER já usado noutras regras.
  const SCOUTING_DISTANCE_PROFILE = Object.freeze({
    // Correção (pedido do utilizador: "1.400€ é imenso"): o custo variável por distância estava
    // demasiado alto, sobretudo no topo (distante). Cortado e a curva achatada — a diferença
    // entre observar um clube da própria zona e um de divisão distante continua clara, mas deixa
    // de ser desproporcionada face ao resto do custo do relatório (a parte fixa, ligada ao
    // plantel e ao departamento).
    propria:     { confidencePenalty:0,   custoVariavel:60,   prazoDias:2  },
    "outra-zona":{ confidencePenalty:8,   custoVariavel:140,  prazoDias:4  },
    adjacente:   { confidencePenalty:18,  custoVariavel:280,  prazoDias:6  },
    distante:    { confidencePenalty:30,  custoVariavel:500,  prazoDias:10 },
  });
  function scoutingDistanceTier(targetTeam){
    const my = myTeam();
    if(!my || !targetTeam) return "propria";
    const a = DIVISION_TIER[my.divisaoAtual], b = DIVISION_TIER[targetTeam.divisaoAtual];
    if(a==null || b==null) return "propria";
    const gap = Math.abs(a-b);
    if(gap>=2) return "distante";
    if(gap===1) return "adjacente";
    if(my.zona && targetTeam.zona && my.zona!==targetTeam.zona) return "outra-zona";
    return "propria";
  }

  function avgMonthlySalary(team){
    const paid = (team.players||[]).filter(p=>p.contrato);
    if(!paid.length) return 0;
    return paid.reduce((s,p)=>s+(p.contrato.salarioMensal||0),0)/paid.length;
  }
  // Departamento de scouting, por níveis (2026-09-05): discutido com o utilizador — o nevoeiro
  // sozinho tornava impraticável montar um plantel logo no arranque de uma carreira nova (custo e
  // prazo de um relatório por jogador, sem limite de pedidos simultâneos). Cada clube tem um
  // "departamento de scouting" com um nível (0 a 3), que decide: quantos pedidos pode ter em curso
  // ao mesmo tempo (nível 0/1: 1; nível 2: 3; nível 3: 5), se já tem acesso ao relatório completo
  // (nível 0, amador — só a 3ª Divisão arranca aqui — só consegue o "olhar rápido"), e o custo por
  // relatório (desce com o nível: departamento mais eficiente) e o encargo mensal de manutenção
  // (sobe com o nível: mais recursos ao serviço, mais caro manter todos os meses). Subir de nível
  // é um pedido à direção (ver requestDirectionInvestment/resolvePendingDirectionInvestments),
  // exatamente como condições de treino/pavilhão — um compromisso financeiro continuado (o
  // encargo mensal sobe) justifica a mesma aprovação formal.
  const SCOUTING_DEPARTMENT_LEVELS = Object.freeze({
    0:{ capacidade:1, fixedMult:.5, monthlyMult:.12, completoDisponivel:false },
    1:{ capacidade:1, fixedMult:.5, monthlyMult:.12, completoDisponivel:true },
    2:{ capacidade:3, fixedMult:.4, monthlyMult:.20, completoDisponivel:true },
    3:{ capacidade:5, fixedMult:.3, monthlyMult:.30, completoDisponivel:true },
  });
  const SCOUTING_MAX_LEVEL = 3;
  // Nível inicial por clube: a 3ª Divisão nunca é diretamente gerível pelo utilizador hoje, mas
  // fica já preparada para o dia em que passar a ser (amador — só relatórios rápidos). Os
  // "grandes" (reputação de clube ≥85) arrancam num departamento já mais desenvolvido — o mesmo
  // limiar que já distingue "Classe Mundial/Internacional" no fundo de solidariedade.
  function defaultScoutingLevel(team){
    if(team.divisaoAtual==="3div") return 0;
    if((team.reputacaoClube||0)>=85) return 2;
    return 1;
  }
  function scoutingLevelConfig(team){
    const nivel=ensureTeamScouting(team).departamento.nivel;
    return SCOUTING_DEPARTMENT_LEVELS[nivel]||SCOUTING_DEPARTMENT_LEVELS[1];
  }
  // Custo fixo do relatório (o nosso próprio olheiro, independentemente do alvo): fração do
  // salário médio do NOSSO plantel, decrescente com o nível do departamento — pedido explícito do
  // utilizador. Reflete a escala do próprio clube: um clube da Placard paga um "departamento de
  // scouting" caro, um clube da 3ª Divisão (com salário médio hoje muito baixo, ver recalibração
  // salarial) paga muito pouco. O relatório "rápido" (2026-09-05) é uma alternativa mais barata e
  // mais rápida a esta mesma escala, mas menos precisa — cobre mais alvos com o mesmo orçamento.
  function scoutingFixedCost(team,tipo){
    const mult=scoutingLevelConfig(team).fixedMult*(tipo==="rapido"?.4:1);
    return Math.round(avgMonthlySalary(team)*mult/10)*10;
  }
  function scoutingReportCost(targetTeam,tipo){
    const my = myTeam();
    const tier = scoutingDistanceTier(targetTeam);
    const profile = SCOUTING_DISTANCE_PROFILE[tier];
    const rapido = tipo==="rapido";
    const fixo = scoutingFixedCost(my,tipo);
    const variavel = rapido ? Math.round(profile.custoVariavel*.5/10)*10 : profile.custoVariavel;
    const prazoDias = rapido ? Math.max(1,Math.round(profile.prazoDias/2)) : profile.prazoDias;
    return { tier, tipo: rapido?"rapido":"completo", fixo, variavel, total: fixo+variavel, prazoDias };
  }
  // Encargo recorrente de scouting (mensal, TODOS os clubes — humano e IA): ao contrário do
  // relatório pontual, isto não dá nenhuma informação nova — é só o custo realista de manter um
  // olheiro/rede de scouting básica, simetricamente para todos os clubes (pedido explícito: "a IA
  // também ia de recorrer a scouters e ter estes custos"). A IA não precisa de nevoeiro nenhum — a
  // sua lógica de recrutamento já usa sempre os atributos reais — só precisa de pagar por isto,
  // tal como o utilizador. Sobe com o nível do departamento (2026-09-05) — a IA nunca pede
  // upgrades sozinha (não tem incerteza nenhuma para resolver, só pagaria mais sem benefício), só
  // sobe se o utilizador vier a gerir esse clube via troca de carreira e pedir por si.
  function monthlyScoutingCost(team){ return Math.round(avgMonthlySalary(team)*scoutingLevelConfig(team).monthlyMult/10)*10; }

  function ensureTeamScouting(team){
    const isNovo = !team.scouting;
    if(!team.scouting) team.scouting = { pedidos:[], relatorios:{} };
    if(!Array.isArray(team.scouting.pedidos)) team.scouting.pedidos=[];
    if(!team.scouting.relatorios || typeof team.scouting.relatorios!=="object") team.scouting.relatorios={};
    if(!team.scouting.departamento || typeof team.scouting.departamento!=="object") team.scouting.departamento={ nivel:defaultScoutingLevel(team) };
    if(!Number.isFinite(team.scouting.departamento.nivel)) team.scouting.departamento.nivel=defaultScoutingLevel(team);
    team.scouting.departamento.nivel=clamp(Math.round(team.scouting.departamento.nivel),0,SCOUTING_MAX_LEVEL);
    // 3 relatórios completos grátis ("dossiês herdados do estafe técnico anterior") só na
    // primeira vez que este clube ganha um objeto de scouting — nunca retroativo para saves já
    // em curso que já tinham scouting (Nível 1/2 desta funcionalidade) sem este campo.
    if(!Number.isFinite(team.scouting.valesCompletos)) team.scouting.valesCompletos=isNovo?3:0;
    return team.scouting;
  }
  function scoutingReportFor(playerId){
    const my = myTeam(); if(!my) return null;
    const rel = ensureTeamScouting(my).relatorios[playerId];
    if(rel) return rel;
    // talentos descobertos em missões internacionais (08z): observados pelo nosso olheiro
    if(my.scoutingInternacional && my.scoutingInternacional.observados && my.scoutingInternacional.observados[playerId]) return { tipo:"rapido", tier:"propria", internacional:true };
    return null;
  }

  // ============================= Fase 18: boletim do relatório de scouting =============================
  // Pedido do utilizador: um separador dentro do Mercado onde se possa CONSULTAR os relatórios de
  // scouting já concluídos, com texto a sério (um "boletim"), não só a ficha do jogador com menos
  // nevoeiro. O dossiê é gerado uma única vez, quando o relatório é concluído
  // (resolvePendingScoutingReports), e fica guardado tal e qual — não muda mais depois disso,
  // mesmo que o jogador evolua ou mude de clube (é um retrato do que se sabia naquele momento).
  const SCOUTING_TIER_LABELS = { propria:"zona própria", "outra-zona":"outra zona", adjacente:"divisão adjacente", distante:"divisão distante" };
  const SCOUTING_POSITION_LABELS = { GR:"Guarda-Redes", Avancado:"Avançado", DefesaMedio:"Defesa/Médio" };
  function scoutingPositionLabel(player){
    return player.pos==="GR" ? SCOUTING_POSITION_LABELS.GR : (SCOUTING_POSITION_LABELS[player.linha]||"jogador de linha");
  }
  function scoutingDivisionLabel(divisaoAtual){
    return divisaoAtual==="placard" ? "1.ª Divisão" : divisaoAtual==="ok-liga" ? "OK Liga" : divisaoAtual==="serie-a1" ? "Serie A1" : divisaoAtual==="2div" ? "2.ª Divisão" : divisaoAtual==="ok-liga-plata" ? "OK Liga Plata" : "3.ª Divisão";
  }
  // Sufixo de identificação de país para clubes estrangeiros (OK Liga/Espanha, Serie A1/Itália)
  // em listas onde aparecem lado a lado com clubes portugueses (candidaturas do treinador,
  // propostas recebidas) — usado em vez de repetir a mesma condição em cada sítio.
  function foreignClubLabelSuffix(divisaoAtual){
    return divisaoAtual==="ok-liga" ? " (OK Liga — Espanha)" : divisaoAtual==="ok-liga-plata" ? " (OK Liga Plata — Espanha)" : divisaoAtual==="serie-a1" ? " (Serie A1 — Itália)" : "";
  }
  // Mesmos atributos (e mesma ordem) que pesam no cálculo do OVR (overallFromAttrs, 01-nucleo.js)
  // — o dossiê comenta exatamente aquilo que decide a qualidade do jogador, nunca atributos
  // irrelevantes para a posição.
  const SCOUTING_ATTR_LABELS = {
    GR: [["reflexos","reflexos"],["umParaUm","1 para 1"],["agilidade","agilidade"],["concentracao","concentração"],["meiaDistancia","passe de meia-distância"],["forca","força física"],["determinacao","determinação"],["lideranca","liderança"]],
    J:  [["habilidade","habilidade técnica"],["finalizacao","finalização"],["criatividade","criatividade"],["posicionamento","posicionamento"],["desarme","desarme"],["drible","drible"],["meiaDistancia","passe de meia-distância"],["velocidade","velocidade"],["forca","força física"],["determinacao","determinação"],["lideranca","liderança"],["agressividade","agressividade"]],
  };
  function scoutingAttrQualLabel(v){
    if(v>=17) return "excecional";
    if(v>=14) return "muito acima da média";
    if(v>=11) return "sólido, acima da média";
    if(v>=8) return "na média, sem se destacar";
    if(v>=5) return "abaixo da média";
    return "claramente deficitário";
  }
  // Grupo de comparação: jogadores da mesma posição/linha, na mesma divisão do clube observado —
  // usa os atributos REAIS (é o conhecimento coletivo da liga, não a estimativa com nevoeiro deste
  // jogador em particular) só para calcular uma média de referência.
  function scoutingPositionalAverageOverall(pos, linha, divisaoAtual){
    const peers=[];
    Object.values(state.teams).forEach(t=>{
      if(t.equipaPrincipalId || t.divisaoAtual!==divisaoAtual) return;
      (t.players||[]).forEach(p=>{ if(p.pos===pos && (pos!=="J"||p.linha===linha)) peers.push(p); });
    });
    if(!peers.length) return null;
    return Math.round(peers.reduce((a,p)=>a+overall(p),0)/peers.length);
  }
  // Pedido do utilizador: a recomendação final tem de ser relativa ao CLUBE que pede o relatório
  // — o mesmo jogador pode ser um reforço claro para o HC Turquel e dispensável para o Barcelos.
  // Usa o plantel REAL do clube que pede o relatório (é o nosso próprio plantel, sem nevoeiro
  // nenhum) na mesma posição/linha, para comparar o jogador observado com o que já temos, não com
  // uma média teórica da divisão.
  function scoutingClubPositionalContext(team, pos, linha){
    if(!team) return null;
    const peers=(team.players||[]).filter(p=>p.pos===pos && (pos!=="J"||p.linha===linha));
    if(!peers.length) return null;
    const ovrs=peers.map(p=>overall(p)).sort((a,b)=>b-a);
    return { count:peers.length, media:Math.round(ovrs.reduce((a,b)=>a+b,0)/ovrs.length), melhor:ovrs[0], pior:ovrs[ovrs.length-1] };
  }
  function buildScoutingDossier(player, target, tier, tipo){
    const isRapido = tipo==="rapido";
    const posLabel = scoutingPositionLabel(player);
    const nome = escapeHtml(player.name), clube = escapeHtml(target.name);
    const idade = player.age;
    const faixaEtaria = idade<=20 ? "muito jovem, com o essencial do seu desenvolvimento ainda por fazer"
      : idade<=23 ? "jovem, ainda a construir a margem de progressão"
      : idade<=29 ? "em plena maturidade competitiva"
      : "veterano, já com o essencial do seu potencial realizado";

    const keys = SCOUTING_ATTR_LABELS[player.pos] || SCOUTING_ATTR_LABELS.J;
    const evaluated = keys.map(([key,label])=>{
      const noise = stableAttrNoise(player, target, key);
      return { label, value: Math.round(noise.estimate), resolved: noise.resolved };
    });
    const sorted = evaluated.slice().sort((a,b)=>b.value-a.value);
    const fortes = sorted.slice(0,2), fracos = sorted.slice(-2).reverse();
    const descreveAttr = a => `${a.label} (${scoutingAttrQualLabel(a.value)})`;

    const abertura = isRapido
      ? `Observação rápida de ${nome} (${posLabel}, ${idade} anos, ${clube}) — ${faixaEtaria}. Esta é uma primeira impressão, recolhida em pouco tempo: alguns aspetos técnicos e mentais ainda carecem de confirmação com mais jogos observados.`
      : `Relatório completo sobre ${nome} (${posLabel}, ${idade} anos, ${clube}) — ${faixaEtaria}. A nossa equipa de scouting acompanhou o jogador com atenção antes de fechar esta avaliação.`;

    const algumaPorConfirmar = [...fortes,...fracos].some(a=>!a.resolved);
    const analise = `Do que foi possível observar, os pontos mais fortes são ${descreveAttr(fortes[0])} e ${descreveAttr(fortes[1])}. Do lado oposto, ${descreveAttr(fracos[0])} e ${descreveAttr(fracos[1])} ficam claramente atrás do resto do perfil — são, para já, a maior limitação a apontar.${algumaPorConfirmar?' Nem todos estes valores estão ainda confirmados com segurança — a margem de erro só desaparece de vez com mais jogos observados ou um relatório mais aprofundado.':''}`;

    const visOvr = visibleOverall(player, target);
    const media = scoutingPositionalAverageOverall(player.pos, player.linha, target.divisaoAtual);
    const divLabel = scoutingDivisionLabel(target.divisaoAtual);
    let comparacao;
    if(media==null){
      comparacao = `Não há, de momento, uma amostra suficiente de jogadores na mesma posição e divisão para uma comparação direta com o resto da ${divLabel}.`;
    } else {
      const diff = visOvr - media;
      const veredito = diff>=4 ? "claramente acima" : diff>=1 ? "ligeiramente acima" : diff>=-1 ? "muito perto" : diff>=-4 ? "ligeiramente abaixo" : "claramente abaixo";
      comparacao = `Em comparação com os restantes ${posLabel==="Guarda-Redes"?"guarda-redes":"jogadores na mesma posição"} da ${divLabel}, o nível global fica ${veredito} da média do escalão.`;
    }

    // Pedido do utilizador: "espera-se que evolua muito?" — ponto próprio sobre o potencial de
    // evolução, separado da recomendação de contratação (uma coisa é o que o jogador já vale hoje,
    // outra é a margem de progressão à frente). Reaproveita a mesma estimativa com nevoeiro já
    // usada no separador "Pessoal" da ficha do jogador (visiblePotentialLabel/potentialConfidenceLabel,
    // 05-ui-navegacao.js), para nunca contradizer o que lá se vê.
    const potLabel = visiblePotentialLabel(player, target);
    const potConf = potentialConfidenceLabel(player, target).toLowerCase();
    let potencial;
    if(potLabel==="Incerta"){
      potencial = `Potencial de evolução: ainda por confirmar — a nossa equipa de scouting não tem observação suficiente sobre este jogador para arriscar uma estimativa fiável.`;
    } else if(idade>=29){
      potencial = `Potencial de evolução: aos ${idade} anos, o essencial do seu potencial já deve estar realizado — o que se vê hoje é, na prática, o que se pode esperar no futuro, independentemente da margem teórica ainda em aberto.`;
    } else {
      const potFrase = {
        Limitada: "não é expectável uma evolução significativa a partir daqui — o que se vê hoje é, grosso modo, o que se pode esperar no futuro",
        Regular: "deverá evoluir de forma moderada nos próximos anos, sem um salto grande de qualidade",
        Interessante: "há uma margem de progressão a ter em conta — pode subir de patamar com continuidade e bom enquadramento",
        Elevada: "o potencial de evolução é claramente acima da média — um investimento a prazo com boas probabilidades de valorizar",
        Excecional: "o potencial é excecional — poderá tornar-se um jogador de referência bem acima do que é hoje, se a progressão se confirmar",
      }[potLabel] || "a margem de progressão ainda está por confirmar";
      potencial = `Potencial de evolução: ${potFrase} (confiança da avaliação: ${potConf}).`;
    }

    const my = myTeam();
    // Pedido do utilizador: "um jogador pode ser fortemente recomendado para o Turquel e não ser
    // recomendado para o PC Barcelos" — mas também o problema inverso, encontrado por ele mesmo: um
    // jogador de um clube claramente fora do nosso alcance (ex.: Benfica visto por um clube da 2ª
    // Divisão) aparecia sempre como "reforço claro", só porque é melhor do que o nosso plantel —
    // ignorando por completo que essa transferência nunca vai acontecer. purchaseGapBlocked já é o
    // mesmo sinal que bloqueia de facto uma negociação de compra por diferença de dimensão entre
    // clubes (negotiateWithClub, 04-financas.js) — reaproveita-se aqui para a recomendação nunca
    // contradizer o que vai acontecer se o utilizador tentar mesmo negociar.
    const foraDeAlcance = (my && my.id!==target.id) ? purchaseGapBlocked(target, my) : false;
    const myCtx = (my && my.id!==target.id) ? scoutingClubPositionalContext(my, player.pos, player.linha) : null;
    // Aposta de futuro (0.2.29): um jovem com margem de evolução grande pode estar hoje abaixo do
    // nosso melhor e ainda assim ser uma boa contratação — a recomendação só olhava para o OVR
    // atual, por isso um miúdo de 16 anos com potencial altíssimo saía como "não traria mais valia".
    const aposta = idade<=21 && (potLabel==="Elevada" || potLabel==="Excecional" || potLabel==="Interessante");
    let recomendacao;
    if(foraDeAlcance){
      const nomeClube = escapeHtml(my.name);
      recomendacao = visOvr>=15
        ? `Recomendação: nível claramente acima do que o ${nomeClube} consegue realisticamente contratar — um jogador de outro patamar, fora de alcance nas condições atuais do clube.`
        : `Recomendação: a diferença de dimensão entre o ${escapeHtml(clube)} e o ${nomeClube} é grande demais para esta transferência fazer sentido, independentemente do nível exato do jogador.`;
    } else if(myCtx){
      const diffMelhor = visOvr - myCtx.melhor, diffMedia = visOvr - myCtx.media;
      const nomeClube = escapeHtml(my.name);
      if(diffMelhor>=2) recomendacao = `Recomendação: reforço claro para o ${nomeClube} — fica acima do nosso melhor jogador atual nesta posição.`;
      else if(aposta && (potLabel!=="Interessante" || diffMedia>=-2)) recomendacao = potLabel==="Interessante"
        ? `Recomendação: aposta a prazo para o ${nomeClube} — hoje é sobretudo rotação, mas tem margem de progressão que justifica acompanhar e, se o preço for baixo, contratar.`
        : `Recomendação: aposta de futuro para o ${nomeClube} — hoje ${diffMedia>=2?"já é um reforço":"ainda não é titular"} nesta posição, mas a margem de evolução é grande e justifica a contratação a pensar nas próximas épocas.`;
      else if(diffMedia>=2) recomendacao = `Recomendação: reforço a considerar para o ${nomeClube} — claramente acima da média do que já temos nesta posição.`;
      else if(diffMedia>=-2) recomendacao = `Recomendação: nível muito parecido ao que já temos no ${nomeClube} nesta posição — reforço de rotação, não uma evolução clara para o plantel.`;
      else recomendacao = `Recomendação: abaixo do que já temos no ${nomeClube} nesta posição — não traria mais valia para o nosso plantel atual.`;
    } else {
      // Sem plantel próprio para comparar (posição vazia, ou a observar um jogador do próprio
      // clube por engano) — mantém uma leitura absoluta como recurso.
      if(visOvr>=15) recomendacao = "Recomendação: nível já pronto para reforçar de imediato um onze competitivo, sem necessidade de adaptação prolongada.";
      else if(visOvr>=11) recomendacao = "Recomendação: jogador de rotação sólido, capaz de somar minutos sem ser um ponto fraco evidente.";
      else recomendacao = "Recomendação: perfil limitado para a generalidade dos plantéis — só faria sentido como opção de recurso ou a um preço muito reduzido.";
    }
    if(isRapido) recomendacao += " Conclusão preliminar — um relatório completo traria mais segurança antes de qualquer decisão final.";

    return [abertura, analise, comparacao, potencial, persParagrafoScouting(player), recomendacao];
  }
  function scoutingDossierParagraphs(report){
    if(Array.isArray(report.dossie) && report.dossie.length) return report.dossie;
    // Migração: relatórios concluídos antes desta funcionalidade não têm dossiê guardado — gera-se
    // agora, se o jogador e o clube-alvo ainda existirem; caso contrário, mostra-se um resumo
    // simples com a informação que já tínhamos guardada.
    const target = report.targetTeamId ? state.teams[report.targetTeamId] : null;
    const player = target ? (target.players||[]).find(p=>p.id===report.playerId) : null;
    if(player && target){
      report.dossie = buildScoutingDossier(player, target, report.tier, report.tipo);
    } else {
      report.dossie = [`Relatório ${report.tipo==="rapido"?"rápido":"completo"} sobre ${escapeHtml(report.playerName||"este jogador")}, concluído a ${fmtDateShort(new Date(report.resolvedDate))}. O texto detalhado não ficou guardado na altura (relatório anterior a esta funcionalidade) e o jogador já não está disponível para uma nova análise.`];
    }
    return report.dossie;
  }
  // Pedido do utilizador: "o nome do jogador deve estar clicável" — o clube-alvo guardado no
  // relatório pode já não ter o jogador (vendido, emprestado, reformado...) desde que o relatório
  // foi concluído, por isso procura-se primeiro nesse clube e, falhando, em todo o resto da liga,
  // antes de decidir se ainda há para onde abrir a ficha.
  function locateScoutedPlayerTeamId(playerId, fallbackTeamId){
    const fallback = fallbackTeamId ? state.teams[fallbackTeamId] : null;
    if(fallback && (fallback.players||[]).some(p=>p.id===playerId)) return fallback.id;
    const found = Object.values(state.teams).find(t=>(t.players||[]).some(p=>p.id===playerId));
    return found ? found.id : null;
  }
  function renderScoutingReportsSection(team){
    const box = document.getElementById("scoutingReportsSection");
    if(!box) return;
    const scouting = ensureTeamScouting(team);
    const entries = Object.keys(scouting.relatorios).map(pid=>({ playerId:pid, ...scouting.relatorios[pid] }))
      .sort((a,b)=> new Date(b.resolvedDate) - new Date(a.resolvedDate));
    if(!entries.length){
      box.innerHTML = '<p class="helptext">Ainda não há relatórios de scouting concluídos — pede um a partir da ficha de um jogador de outro clube.</p>';
      return;
    }
    box.innerHTML = entries.map(r=>{
      const paragrafos = scoutingDossierParagraphs(r);
      const tipoLabel = r.tipo==="rapido" ? "Relatório rápido" : "Relatório completo";
      const tierLabel = SCOUTING_TIER_LABELS[r.tier] || r.tier || "";
      const liveTeamId = locateScoutedPlayerTeamId(r.playerId, r.targetTeamId);
      const nomeHtml = liveTeamId
        ? `<button class="playername-btn scouting-player-btn" data-team="${liveTeamId}" data-id="${r.playerId}">${escapeHtml(r.playerName||"Jogador")}</button>`
        : escapeHtml(r.playerName||"Jogador");
      const titulo = `${nomeHtml}${r.targetTeamName?` · ${escapeHtml(r.targetTeamName)}`:""}`;
      return `<details class="news-item news-scouting">
        <summary class="news-summary"><span class="news-date">${fmtDateShort(new Date(r.resolvedDate))}</span><span class="news-title">${titulo}</span></summary>
        <div class="news-text">
          <p class="helptext" style="margin:0 0 10px;">${tipoLabel} · ${tierLabel}</p>
          ${repScoutingDoc(r, paragrafos)}
        </div>
      </details>`;
    }).join("");
    box.querySelectorAll(".scouting-player-btn").forEach(btn=>{
      btn.addEventListener("click", (e)=>{ e.preventDefault(); e.stopPropagation(); openPlayerModal(btn.getAttribute("data-team"), btn.getAttribute("data-id")); });
    });
  }
  function scoutingPendingRequestFor(playerId){
    const my = myTeam(); if(!my) return null;
    return ensureTeamScouting(my).pedidos.find(p=>p.playerId===playerId) || null;
  }
  // Pede um relatório de scouting sobre um jogador de outro clube. Não é resolvido na hora — o
  // olheiro "vai lá" e o relatório chega como notícia, dias depois (ver resolvePendingScoutingReports).
  // tipo: "completo" (default) ou "rapido". O departamento de scouting limita quantos pedidos
  // podem estar em curso ao mesmo tempo (qualquer tipo), e o nível 0 (amador) só permite "rapido".
  function requestScoutingReport(playerId, targetTeamId, tipo){
    const my = myTeam(), target = state.teams[targetTeamId];
    if(!my || !target) return { ok:false, reason:"Clube inválido." };
    if(target.id===my.id || target.id===my.equipaBId) return { ok:false, reason:"É um jogador do nosso plantel." };
    const scouting = ensureTeamScouting(my), cfg = scoutingLevelConfig(my);
    const tipoFinal = tipo==="rapido" ? "rapido" : "completo";
    if(tipoFinal==="completo" && !cfg.completoDisponivel) return { ok:false, reason:"O departamento de scouting deste clube ainda só consegue fazer observações rápidas (nível amador)." };
    if(scouting.relatorios[playerId]) return { ok:false, reason:"Já existe um relatório de scouting para este jogador." };
    if(scouting.pedidos.some(p=>p.playerId===playerId)) return { ok:false, reason:"Já há um pedido de scouting em curso para este jogador." };
    if(scouting.pedidos.length+(typeof scintEnsure==="function"?scintEnsure(my).missoes.length:0)>=cfg.capacidade) return { ok:false, reason:`O departamento de scouting está no limite de pedidos em curso (nível ${scouting.departamento.nivel}: máximo ${cfg.capacidade} em simultâneo).` };
    const cost = scoutingReportCost(target,tipoFinal);
    const usaVale = tipoFinal==="completo" && scouting.valesCompletos>0;
    if(usaVale) scouting.valesCompletos--;
    else addFinanceMovement(my,"despesa","Scouting",`Relatório ${tipoFinal==="rapido"?"rápido":"completo"} de scouting encomendado sobre um jogador de ${target.name}`,cost.total,state.currentDate);
    scouting.pedidos.push({ playerId, targetTeamId, tier:cost.tier, tipo:tipoFinal, gratuito:usaVale, requestDate:(state.currentDate||new Date()).toISOString(), readyDate:addDays(state.currentDate||new Date(),cost.prazoDias).toISOString() });
    return { ok:true, cost, usaVale };
  }
  // Corrido uma vez por dia (dailyConditionRecovery, 09-fluxo-epoca.js) — resolve os pedidos cujo
  // prazo já chegou, e entrega o resultado como notícia do "Nosso Olheiro".
  function resolvePendingScoutingReports(date){
    const my = myTeam(); if(!my) return;
    const scouting = ensureTeamScouting(my);
    if(!scouting.pedidos.length) return;
    const today = new Date(date);
    const stillPending = [];
    scouting.pedidos.forEach(pedido=>{
      if(new Date(pedido.readyDate) > today){ stillPending.push(pedido); return; }
      const target = state.teams[pedido.targetTeamId];
      const player = target ? target.players.find(p=>p.id===pedido.playerId) : null;
      const tipo = pedido.tipo==="rapido"?"rapido":"completo";
      // Correção (0.2.29, "pedi relatório do Lucas Figueira e a recomendação foi não contratar"): o
      // dossiê e a ficha eram calculados ANTES de o relatório existir em scouting.relatorios, por
      // isso o nevoeiro (stableAttrNoise/stablePotentialNoise → scoutingReportFor) ignorava o
      // próprio relatório que se estava a produzir — o OVR e o potencial do boletim saíam com a
      // mesma margem de erro de quem nunca foi observado. Regista-se primeiro a entrada, e só
      // depois se calcula o conteúdo com o relatório já "em vigor".
      const entrada = scouting.relatorios[pedido.playerId] = {
        resolvedDate:today.toISOString(), tier:pedido.tier, tipo,
        targetTeamId: pedido.targetTeamId, targetTeamName: target ? target.name : null,
        playerName: player ? player.name : null,
        dossie: null, ficha: null,
      };
      if(player && target){
        entrada.dossie = buildScoutingDossier(player, target, pedido.tier, tipo);
        entrada.ficha = { idade: player.age, pos: scoutingPositionLabel(player), ovr: Math.round(visibleOverall(player, target)), pot: visiblePotentialLabel(player, target), divisao: scoutingDivisionLabel(target.divisaoAtual) };
      }
      if(player && target){
        // Correção (2026-09-17, apontada pelo utilizador): o email só dizia que o relatório
        // estava disponível, obrigando a ir à ficha do clube ver o dossiê — o texto completo
        // (as mesmas frases de scouting.relatorios[...].dossie/scoutingDossierParagraphs, usadas
        // na secção "Relatórios de scouting") passa a vir já no corpo do próprio email.
        const dossie = scouting.relatorios[pedido.playerId].dossie || [];
        const corpo = repScoutingDoc(Object.assign({ playerId: pedido.playerId }, scouting.relatorios[pedido.playerId]), dossie);
        pushNews(today, corpo, "scouting", "Relatório do Nosso Olheiro", {autoAdvanceStop:true});
      }
    });
    scouting.pedidos = stillPending;
  }
  function nextScoutingLevel(team){
    const nivel=ensureTeamScouting(team).departamento.nivel;
    return nivel<SCOUTING_MAX_LEVEL ? nivel+1 : null;
  }
  // Custo de subida de nível: meses do agravamento do encargo mensal entre o nível atual e o
  // seguinte, tal como trainingUpgradeCost já faz para as condições de treino — o mesmo padrão de
  // cálculo, com um piso (o salto 0→1 não muda o encargo mensal, só desbloqueia o relatório
  // completo, por isso ficaria a custo zero sem este piso).
  function scoutingLevelUpgradeCost(team){
    const next=nextScoutingLevel(team); if(next==null) return null;
    const atual=SCOUTING_DEPARTMENT_LEVELS[ensureTeamScouting(team).departamento.nivel].monthlyMult;
    const seguinte=SCOUTING_DEPARTMENT_LEVELS[next].monthlyMult;
    const delta=avgMonthlySalary(team)*(seguinte-atual);
    return Math.max(2000,Math.round(delta*DIRECAO_INVESTIMENTO_CONFIG.scoutingMesesCusto*clubFinancialStructureFactor(team)));
  }

  // Departamento médico, por níveis (2026-10-08, pedido do utilizador: "ideia 4"): até aqui as
  // condições de treino faziam de proxy da qualidade médica (injuryChance/applyInjuryOutcome).
  // Agora cada clube tem um departamento médico próprio (nível 0 a 4, médico + fisioterapia +
  // preparação física) que decide: o risco de lesão por jogo, a duração das lesões graves, a
  // demora do diagnóstico, a recuperação diária de condição física e a perda de condição nas
  // lesões ligeiras. Custo mensal sobe com o nível (todos os clubes pagam, IA incluída); subir de
  // nível é um pedido à direção, tal como o scouting. Os clubes de IA têm nível ligado à sua
  // dimensão (reputação) e reajustam-se todos os meses, a não ser que tenham sido geridos pelo
  // utilizador (team.medico.gerido).
  const MEDICAL_DEPARTMENT_LEVELS = Object.freeze({
    0:{ label:"Básico", monthlyMult:.06, injuryMult:1.25, durationMult:1.20, diagDias:[3,5], recoveryMult:.90, lightLossMult:1.20 },
    1:{ label:"Reduzido", monthlyMult:.12, injuryMult:1.10, durationMult:1.10, diagDias:[2,4], recoveryMult:.95, lightLossMult:1.10 },
    2:{ label:"Profissional", monthlyMult:.20, injuryMult:1.00, durationMult:1.00, diagDias:[1,3], recoveryMult:1.00, lightLossMult:1.00 },
    3:{ label:"Avançado", monthlyMult:.32, injuryMult:.88, durationMult:.88, diagDias:[1,2], recoveryMult:1.06, lightLossMult:.90 },
    4:{ label:"Elite", monthlyMult:.46, injuryMult:.78, durationMult:.78, diagDias:[1,1], recoveryMult:1.12, lightLossMult:.80 },
  });
  const MEDICAL_MAX_LEVEL = 4;
  function medicalOwnerTeam(team){ return team && team.equipaPrincipalId && state.teams[team.equipaPrincipalId] ? state.teams[team.equipaPrincipalId] : team; }
  function defaultMedicalLevel(team){
    const rep = team.reputacaoClube!=null ? team.reputacaoClube : (team.reputacao!=null ? team.reputacao : 50);
    let nivel = rep>=92?4 : rep>=85?3 : rep>=60?2 : rep>=35?1 : 0;
    if(team.divisaoAtual==="3div") nivel = Math.min(nivel,0);
    else if(isSecondTierDivision(team.divisaoAtual)) nivel = Math.min(nivel,2);
    return nivel;
  }
  function ensureTeamMedico(team){
    if(!team) return { nivel:2 };
    if(!team.medico || typeof team.medico!=="object") team.medico = { nivel:defaultMedicalLevel(team), gerido:false };
    if(!Number.isFinite(team.medico.nivel)) team.medico.nivel = defaultMedicalLevel(team);
    team.medico.nivel = clamp(Math.round(team.medico.nivel),0,MEDICAL_MAX_LEVEL);
    return team.medico;
  }
  // Equipas B partilham o departamento médico do clube principal.
  function medicalLevelConfig(team){
    const owner = medicalOwnerTeam(team);
    return MEDICAL_DEPARTMENT_LEVELS[ensureTeamMedico(owner).nivel] || MEDICAL_DEPARTMENT_LEVELS[2];
  }
  function medicalInjuryMult(team){ return medicalLevelConfig(team).injuryMult; }
  function medicalDurationMult(team){ return medicalLevelConfig(team).durationMult; }
  function medicalRecoveryMult(team){ return medicalLevelConfig(team).recoveryMult; }
  function medicalLightLossMult(team){ return medicalLevelConfig(team).lightLossMult; }
  function medicalDiagnosisDelayDays(team){
    const [a,b] = medicalLevelConfig(team).diagDias;
    return a + Math.floor(Math.random()*(b-a+1));
  }
  function monthlyMedicalCost(team){ return Math.round(avgMonthlySalary(team)*medicalLevelConfig(team).monthlyMult/10)*10; }
  // Reajuste mensal do nível dos clubes que o utilizador nunca geriu (IA, e o próprio clube do
  // utilizador enquanto não pedir melhorias: o nível só muda por pedido à direção).
  function syncAiMedicalLevel(team){
    if(!team || team.equipaPrincipalId || isUserControlledTeam(team)) return;
    const m = ensureTeamMedico(team);
    if(!m.gerido) m.nivel = defaultMedicalLevel(team);
  }
  function nextMedicalLevel(team){
    const nivel = ensureTeamMedico(medicalOwnerTeam(team)).nivel;
    return nivel<MEDICAL_MAX_LEVEL ? nivel+1 : null;
  }
  function medicalLevelUpgradeCost(team){
    const next = nextMedicalLevel(team); if(next==null) return null;
    const atual = MEDICAL_DEPARTMENT_LEVELS[ensureTeamMedico(team).nivel].monthlyMult;
    const seguinte = MEDICAL_DEPARTMENT_LEVELS[next].monthlyMult;
    const delta = avgMonthlySalary(team)*(seguinte-atual);
    return Math.max(2500,Math.round(delta*DIRECAO_INVESTIMENTO_CONFIG.medicoMesesCusto*clubFinancialStructureFactor(team)));
  }
  // =================================================================
